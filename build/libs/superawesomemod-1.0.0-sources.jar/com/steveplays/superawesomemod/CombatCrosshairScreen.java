package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class CombatCrosshairScreen extends GabeOptionScreen {

    public CombatCrosshairScreen(class_437 parent) {
        super(parent, "Combat Crosshair");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", CombatCrosshairData::isEnabled, CombatCrosshairData::setEnabled);
        cycle("In range", CombatCrosshairData::getInRangeColorName,
            () -> CombatCrosshairData.setInRangeColor(
                (CombatCrosshairData.getInRangeColor() + 1) % CombatHitboxData.COLOR_NAMES.length));
        cycle("Out of range", CombatCrosshairData::getOutOfRangeColorName,
            () -> CombatCrosshairData.setOutOfRangeColor(
                (CombatCrosshairData.getOutOfRangeColor() + 1) % CombatHitboxData.COLOR_NAMES.length));
        info("Tints the crosshair by attack range");
    }
}
