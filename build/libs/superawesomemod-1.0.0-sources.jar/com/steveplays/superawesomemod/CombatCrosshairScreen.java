package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class CombatCrosshairScreen extends class_437 {

    private final class_437 parent;

    public CombatCrosshairScreen(class_437 parent) {
        super(class_2561.method_43470("Combat Crosshair"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789 / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        int y = cy - 55;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                CombatCrosshairData.setEnabled(!CombatCrosshairData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += 25;

        // In-range color cycle
        this.method_37063(class_4185.method_46430(
            inRangeColorLabel(),
            btn -> {
                int next = (CombatCrosshairData.getInRangeColor() + 1) % CombatHitboxData.COLOR_NAMES.length;
                CombatCrosshairData.setInRangeColor(next);
                btn.method_25355(inRangeColorLabel());
            }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += 25;

        // Out-of-range color cycle
        this.method_37063(class_4185.method_46430(
            outOfRangeColorLabel(),
            btn -> {
                int next = (CombatCrosshairData.getOutOfRangeColor() + 1) % CombatHitboxData.COLOR_NAMES.length;
                CombatCrosshairData.setOutOfRangeColor(next);
                btn.method_25355(outOfRangeColorLabel());
            }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += 25;

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, y, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(CombatCrosshairData.isEnabled()
            ? "Combat Crosshair: Enabled"
            : "Combat Crosshair: Disabled");
    }

    private class_2561 inRangeColorLabel() {
        return class_2561.method_43470("In Range: " + CombatCrosshairData.getInRangeColorName());
    }

    private class_2561 outOfRangeColorLabel() {
        return class_2561.method_43470("Out of Range: " + CombatCrosshairData.getOutOfRangeColorName());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 75, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Crosshair color changes when aiming at a target"),
            cx, cy - 61, 0xAAAAAA);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
