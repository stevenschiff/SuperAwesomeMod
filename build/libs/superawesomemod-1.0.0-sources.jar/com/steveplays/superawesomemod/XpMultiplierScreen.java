package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class XpMultiplierScreen extends class_437 {

    private final class_437 parent;

    public XpMultiplierScreen(class_437 parent) {
        super(class_2561.method_43470("XP Multiplier"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        // Toggle on/off
        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                XpMultiplierData.setEnabled(!XpMultiplierData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        // Multiplier slider (0.1x - 100x)
        this.method_37063(new MultiplierSlider(cx - btnW / 2, cy - 10, btnW, btnH,
                XpMultiplierData.getMultiplier()));

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(XpMultiplierData.isEnabled()
            ? "Disable XP Multiplier"
            : "Enable XP Multiplier");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);

        boolean on = XpMultiplierData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 58, on ? 0x55FF55 : 0xFF5555);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Multiplies XP orbs, furnace XP and mob kills"),
            cx, cy + 46, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Worlds you host only - servers award their own XP"),
            cx, cy + 58, 0xFFAA00);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // ── Multiplier slider (0.1x - 100x) ─────────────────────────────────
    //
    // Mapped by powers of ten rather than evenly, so 0.1x / 1x / 10x / 100x sit at
    // even spacing along the track. A linear 0.1-100 slider would spend its first
    // pixel on everything below 1x and make 1x itself unpickable.

    private static final class MultiplierSlider extends class_357 {
        private static final double LOG_MIN = Math.log10(XpMultiplierData.MIN_MULTIPLIER);
        private static final double LOG_MAX = Math.log10(XpMultiplierData.MAX_MULTIPLIER);

        MultiplierSlider(int x, int y, int w, int h, float initial) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.method_25346();
        }

        private static double normalize(float v) {
            return (Math.log10(v) - LOG_MIN) / (LOG_MAX - LOG_MIN);
        }

        /** Snaps to 0.1 steps below 10x and whole numbers above, so the label stays readable. */
        private float denormalize() {
            float v = (float) Math.pow(10.0, LOG_MIN + this.field_22753 * (LOG_MAX - LOG_MIN));
            v = v < 10f ? Math.round(v * 10f) / 10f : Math.round(v);
            return Math.clamp(v, XpMultiplierData.MIN_MULTIPLIER, XpMultiplierData.MAX_MULTIPLIER);
        }

        @Override
        protected void method_25346() {
            float v = denormalize();
            String text = v < 10f
                ? String.format("%.1f", v)
                : String.valueOf((int) v);
            this.method_25355(class_2561.method_43470("Multiplier: " + text + "x"));
        }

        @Override
        protected void method_25344() {
            XpMultiplierData.setMultiplier(denormalize());
        }
    }
}
