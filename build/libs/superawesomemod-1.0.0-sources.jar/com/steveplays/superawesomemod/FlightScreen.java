package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class FlightScreen extends class_437 {

    private final class_437 parent;
    private class_342 speedField;

    public FlightScreen(class_437 parent) {
        super(class_2561.method_43470("Flight"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        // Toggle on/off — picks up whatever is typed in the speed box
        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                applySpeed();
                FlightData.setEnabled(!FlightData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 44, btnW, btnH).method_46431());

        // Speed input box (1-10000 blocks/second)
        speedField = new class_342(this.field_22793, cx - 40, cy - 6, 80, btnH,
                class_2561.method_43470("Speed"));
        speedField.method_1880(5);
        speedField.method_1852(String.valueOf(FlightData.getBlocksPerSecond()));
        speedField.method_1863(text -> applySpeed());
        this.method_37063(speedField);

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> {
                applySpeed();
                this.field_22787.method_1507(this.parent);
            }
        ).method_46434(cx - 50, cy + 22, 100, btnH).method_46431());
    }

    /**
     * Reads the speed box and stores it. Empty or non-numeric text is ignored so
     * half-typed values don't wipe the current speed.
     */
    private void applySpeed() {
        if (speedField == null) return;
        String text = speedField.method_1882().trim();
        if (text.isEmpty()) return;
        try {
            FlightData.setBlocksPerSecond(Integer.parseInt(text));
        } catch (NumberFormatException ignored) {
            // keep the previous speed
        }
    }

    @Override
    public void method_25419() {
        applySpeed();
        super.method_25419();
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(FlightData.isEnabled() ? "Disable Flight" : "Enable Flight");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);

        boolean on = FlightData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 58, on ? 0x55FF55 : 0xFF5555);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Speed (blocks/sec)"),
            cx, cy - 18, 0xFFFFFF);

        int speed = FlightData.getBlocksPerSecond();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Using " + speed + " blocks/sec  |  "
                + FlightData.MIN_BLOCKS_PER_SECOND + "-" + FlightData.MAX_BLOCKS_PER_SECOND),
            cx, cy + 48, speed > 1000 ? 0xFFAA00 : 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("WASD/Space/Shift to fly  |  Works in survival"),
            cx, cy + 60, 0xAAAAAA);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
