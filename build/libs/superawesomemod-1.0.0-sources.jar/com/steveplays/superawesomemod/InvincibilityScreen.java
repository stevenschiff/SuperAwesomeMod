package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class InvincibilityScreen extends class_437 {

    private final class_437 parent;

    public InvincibilityScreen(class_437 parent) {
        super(class_2561.method_43470("Invincibility"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                InvincibilityData.setEnabled(!InvincibilityData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(InvincibilityData.isEnabled()
            ? "Disable Invincibility" : "Enable Invincibility");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);

        boolean on = InvincibilityData.isEnabled();
        boolean host = this.field_22787.method_1496();
        boolean inWorld = this.field_22787.field_1687 != null;

        // Deliberately blunt. Believing this is on when it isn't is the worst failure
        // this mod can hand you, so an enabled-but-powerless state never reads green.
        String status;
        int color;
        if (!on) {
            status = "Disabled";
            color = 0xFF5555;
        } else if (inWorld && !host) {
            status = "Enabled - NOT PROTECTING YOU HERE";
            color = 0xFF5555;
        } else {
            status = "Enabled";
            color = 0x55FF55;
        }
        graphics.method_27534(this.field_22793, class_2561.method_43470("Status: " + status),
            cx, cy - 58, color);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Cancels all damage aimed at you"),
            cx, cy + 46, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Worlds you host only - a server decides its own damage"),
            cx, cy + 58, 0xFFAA00);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("On a server you will still take damage and still die"),
            cx, cy + 70, 0xFF5555);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
