package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix4f;

/**
 * Renders the schematic ghost overlay or verifier overlay in world space.
 * Follows the same pattern as {@link XrayRenderer}.
 */
public final class SchematicRenderer {

    private SchematicRenderer() {}

    private static final int RENDER_RADIUS = 32;

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(SchematicRenderer::onAfterEntities);
    }

    private static void onAfterEntities(WorldRenderContext ctx) {
        if (!SchematicData.isEnabled()) return;

        SchematicPlacement placement = SchematicData.getCurrentPlacement();
        if (placement == null) return;

        class_4597 consumers = ctx.consumers();
        if (consumers == null) return;

        class_4184 camera = ctx.gameRenderer().method_19418();
        class_243 camPos = camera.method_71156();
        class_4587.class_4665 pose = ctx.matrices().method_23760();
        Matrix4f matrix = pose.method_23761();

        int renderMode = SchematicData.getRenderMode();

        if (renderMode == 0) {
            renderGhost(consumers, matrix, camPos, placement);
        } else {
            renderVerifier(consumers, matrix, pose, camPos, placement);
        }
    }

    /**
     * Renders translucent colored cubes for each non-air block in the schematic.
     */
    private static void renderGhost(class_4597 consumers, Matrix4f matrix,
                                     class_243 camPos, SchematicPlacement placement) {
        class_4588 buf = consumers.method_73477(SchematicRenderType.SCHEMATIC_GHOST);
        float alpha = SchematicData.getGhostAlpha();

        class_2338 min = placement.getMin();
        class_2338 max = placement.getMax();

        int camX = (int) Math.floor(camPos.field_1352);
        int camY = (int) Math.floor(camPos.field_1351);
        int camZ = (int) Math.floor(camPos.field_1350);

        int startX = Math.max(min.method_10263(), camX - RENDER_RADIUS);
        int startY = Math.max(min.method_10264(), camY - RENDER_RADIUS);
        int startZ = Math.max(min.method_10260(), camZ - RENDER_RADIUS);
        int endX = Math.min(max.method_10263(), camX + RENDER_RADIUS);
        int endY = Math.min(max.method_10264(), camY + RENDER_RADIUS);
        int endZ = Math.min(max.method_10260(), camZ + RENDER_RADIUS);

        // Layer mode: restrict Y range
        if (SchematicData.isLayerMode()) {
            int layerY = min.method_10264() + SchematicData.getCurrentLayer();
            startY = layerY;
            endY = layerY + 1;
        }

        class_2338.class_2339 mutable = new class_2338.class_2339();

        for (int y = startY; y < endY; y++) {
            for (int z = startZ; z < endZ; z++) {
                for (int x = startX; x < endX; x++) {
                    mutable.method_10103(x, y, z);
                    class_2680 state = placement.getBlockStateAt(mutable);
                    if (state.method_26215()) continue;

                    int color = getBlockColor(state);
                    float r = ((color >> 16) & 0xFF) / 255f;
                    float g = ((color >> 8) & 0xFF) / 255f;
                    float b = (color & 0xFF) / 255f;

                    float x0 = (float) (x - camPos.field_1352);
                    float y0 = (float) (y - camPos.field_1351);
                    float z0 = (float) (z - camPos.field_1350);
                    float x1 = x0 + 1f;
                    float y1 = y0 + 1f;
                    float z1 = z0 + 1f;

                    renderFilledBox(buf, matrix, x0, y0, z0, x1, y1, z1, r, g, b, alpha);
                }
            }
        }
    }

    /**
     * Renders wireframe boxes colored by verification status.
     */
    private static void renderVerifier(class_4597 consumers, Matrix4f matrix,
                                        class_4587.class_4665 pose, class_243 camPos,
                                        SchematicPlacement placement) {
        class_4588 buf = consumers.method_73477(SchematicRenderType.SCHEMATIC_OUTLINE);

        class_2338 min = placement.getMin();
        class_2338 max = placement.getMax();

        int camX = (int) Math.floor(camPos.field_1352);
        int camY = (int) Math.floor(camPos.field_1351);
        int camZ = (int) Math.floor(camPos.field_1350);

        int startX = Math.max(min.method_10263(), camX - RENDER_RADIUS);
        int startY = Math.max(min.method_10264(), camY - RENDER_RADIUS);
        int startZ = Math.max(min.method_10260(), camZ - RENDER_RADIUS);
        int endX = Math.min(max.method_10263(), camX + RENDER_RADIUS);
        int endY = Math.min(max.method_10264(), camY + RENDER_RADIUS);
        int endZ = Math.min(max.method_10260(), camZ + RENDER_RADIUS);

        if (SchematicData.isLayerMode()) {
            int layerY = min.method_10264() + SchematicData.getCurrentLayer();
            startY = layerY;
            endY = layerY + 1;
        }

        class_2338.class_2339 mutable = new class_2338.class_2339();

        for (int y = startY; y < endY; y++) {
            for (int z = startZ; z < endZ; z++) {
                for (int x = startX; x < endX; x++) {
                    mutable.method_10103(x, y, z);
                    SchematicVerifier.Status status = SchematicVerifier.getStatus(mutable);
                    if (status == null || status == SchematicVerifier.Status.CORRECT) continue;

                    float r, g, b;
                    switch (status) {
                        case WRONG_BLOCK -> { r = 1.0f; g = 0.0f; b = 0.0f; }  // red
                        case MISSING     -> { r = 1.0f; g = 1.0f; b = 0.0f; }  // yellow
                        case EXTRA       -> { r = 1.0f; g = 0.0f; b = 1.0f; }  // magenta
                        default          -> { r = 1.0f; g = 1.0f; b = 1.0f; }
                    }

                    float x0 = (float) (x - camPos.field_1352);
                    float y0 = (float) (y - camPos.field_1351);
                    float z0 = (float) (z - camPos.field_1350);
                    float x1 = x0 + 1f;
                    float y1 = y0 + 1f;
                    float z1 = z0 + 1f;

                    renderBoxLines(buf, matrix, pose, x0, y0, z0, x1, y1, z1, r, g, b, 1.0f);
                }
            }
        }
    }

    /**
     * Returns a color for a block state based on its material category.
     */
    private static int getBlockColor(class_2680 state) {
        String name = state.method_26204().method_9518().getString().toLowerCase();

        // Stone / mineral
        if (name.contains("stone") || name.contains("cobble") || name.contains("brick")
            || name.contains("concrete") || name.contains("deepslate") || name.contains("andesite")
            || name.contains("diorite") || name.contains("granite") || name.contains("tuff")) {
            return 0x888888;
        }
        // Wood / organic
        if (name.contains("log") || name.contains("plank") || name.contains("wood")
            || name.contains("stripped") || name.contains("bamboo")) {
            return 0x8B6914;
        }
        // Glass / transparent
        if (name.contains("glass") || name.contains("ice")) {
            return 0x88CCEE;
        }
        // Redstone
        if (name.contains("redstone") || name.contains("piston") || name.contains("repeater")
            || name.contains("comparator") || name.contains("observer") || name.contains("hopper")) {
            return 0xCC3333;
        }
        // Water / fluid
        if (name.contains("water") || name.contains("kelp") || name.contains("seagrass")) {
            return 0x3366CC;
        }
        // Leaves / vegetation
        if (name.contains("leaves") || name.contains("grass") || name.contains("fern")
            || name.contains("vine") || name.contains("moss")) {
            return 0x44AA44;
        }
        // Sand / gravel
        if (name.contains("sand") || name.contains("gravel")) {
            return 0xDDCC88;
        }
        // Ore
        if (name.contains("ore")) {
            return 0xFFAA33;
        }
        // Wool / terracotta
        if (name.contains("wool") || name.contains("terracotta") || name.contains("carpet")) {
            return 0xCC8866;
        }
        // Default
        return 0xAAAAAA;
    }

    // --- Geometry helpers ---

    private static void renderFilledBox(class_4588 buf, Matrix4f mat,
                                         float x0, float y0, float z0,
                                         float x1, float y1, float z1,
                                         float r, float g, float b, float a) {
        // Bottom face (y0)
        buf.method_22918(mat, x0, y0, z0).method_22915(r, g, b, a);
        buf.method_22918(mat, x0, y0, z1).method_22915(r, g, b, a);
        buf.method_22918(mat, x1, y0, z1).method_22915(r, g, b, a);
        buf.method_22918(mat, x1, y0, z0).method_22915(r, g, b, a);

        // Top face (y1)
        buf.method_22918(mat, x0, y1, z0).method_22915(r, g, b, a);
        buf.method_22918(mat, x1, y1, z0).method_22915(r, g, b, a);
        buf.method_22918(mat, x1, y1, z1).method_22915(r, g, b, a);
        buf.method_22918(mat, x0, y1, z1).method_22915(r, g, b, a);

        // North face (z0)
        buf.method_22918(mat, x0, y0, z0).method_22915(r, g, b, a);
        buf.method_22918(mat, x1, y0, z0).method_22915(r, g, b, a);
        buf.method_22918(mat, x1, y1, z0).method_22915(r, g, b, a);
        buf.method_22918(mat, x0, y1, z0).method_22915(r, g, b, a);

        // South face (z1)
        buf.method_22918(mat, x0, y0, z1).method_22915(r, g, b, a);
        buf.method_22918(mat, x0, y1, z1).method_22915(r, g, b, a);
        buf.method_22918(mat, x1, y1, z1).method_22915(r, g, b, a);
        buf.method_22918(mat, x1, y0, z1).method_22915(r, g, b, a);

        // West face (x0)
        buf.method_22918(mat, x0, y0, z0).method_22915(r, g, b, a);
        buf.method_22918(mat, x0, y1, z0).method_22915(r, g, b, a);
        buf.method_22918(mat, x0, y1, z1).method_22915(r, g, b, a);
        buf.method_22918(mat, x0, y0, z1).method_22915(r, g, b, a);

        // East face (x1)
        buf.method_22918(mat, x1, y0, z0).method_22915(r, g, b, a);
        buf.method_22918(mat, x1, y0, z1).method_22915(r, g, b, a);
        buf.method_22918(mat, x1, y1, z1).method_22915(r, g, b, a);
        buf.method_22918(mat, x1, y1, z0).method_22915(r, g, b, a);
    }

    private static void renderBoxLines(class_4588 buf, Matrix4f mat, class_4587.class_4665 pose,
                                        float x0, float y0, float z0,
                                        float x1, float y1, float z1,
                                        float r, float g, float b, float a) {
        // Bottom
        edge(buf, mat, pose, x0, y0, z0, x1, y0, z0, r, g, b, a, 1, 0, 0);
        edge(buf, mat, pose, x1, y0, z0, x1, y0, z1, r, g, b, a, 0, 0, 1);
        edge(buf, mat, pose, x1, y0, z1, x0, y0, z1, r, g, b, a, -1, 0, 0);
        edge(buf, mat, pose, x0, y0, z1, x0, y0, z0, r, g, b, a, 0, 0, -1);
        // Top
        edge(buf, mat, pose, x0, y1, z0, x1, y1, z0, r, g, b, a, 1, 0, 0);
        edge(buf, mat, pose, x1, y1, z0, x1, y1, z1, r, g, b, a, 0, 0, 1);
        edge(buf, mat, pose, x1, y1, z1, x0, y1, z1, r, g, b, a, -1, 0, 0);
        edge(buf, mat, pose, x0, y1, z1, x0, y1, z0, r, g, b, a, 0, 0, -1);
        // Verticals
        edge(buf, mat, pose, x0, y0, z0, x0, y1, z0, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x1, y0, z0, x1, y1, z0, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x1, y0, z1, x1, y1, z1, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x0, y0, z1, x0, y1, z1, r, g, b, a, 0, 1, 0);
    }

    private static void edge(class_4588 buf, Matrix4f mat, class_4587.class_4665 pose,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float r, float g, float b, float a,
                              float nx, float ny, float nz) {
        buf.method_22918(mat, x1, y1, z1).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz).method_75298(2.0f);
        buf.method_22918(mat, x2, y2, z2).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz).method_75298(2.0f);
    }
}
