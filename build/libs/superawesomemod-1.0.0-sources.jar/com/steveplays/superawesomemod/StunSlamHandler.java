package com.steveplays.superawesomemod;

import com.steveplays.superawesomemod.mixin.MinecraftAutoclickerInvoker;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_3489;

/**
 * Stun Slam: fires the combo's clicks so only the weapon swaps are manual.
 *
 * <p>Swap assist watches for the two <em>transitions</em> in the combo — spear to axe,
 * and axe to mace — rather than simply "an axe is now held". Triggering on the item
 * alone would fire on every unrelated hotbar swap; requiring the previous weapon means
 * reaching for an axe to chop wood stays silent.
 *
 * <p>Queued clicks drain one per tick. That is what "as fast as possible" means in
 * practice: the server processes one attack per tick, so same-tick duplicates are
 * thrown away. The cost is that the second mace click lands on a nearly empty attack
 * cooldown — it supplies knockback and the stun, not damage.
 */
public final class StunSlamHandler {

    /** Which weapon the combo is currently on. */
    private enum Weapon { NONE, SPEAR, AXE, MACE }

    private static Weapon lastHeld = Weapon.NONE;
    private static int pendingClicks = 0;

    // Macro state: -1 when idle, otherwise the step index.
    private static int macroStep = -1;
    private static int macroSpearSlot, macroAxeSlot, macroMaceSlot;

    private StunSlamHandler() {}

    public static void tick(class_310 client) {
        class_1657 player = client.field_1724;
        if (!StunSlamData.isEnabled() || player == null || client.field_1755 != null) {
            reset();
            return;
        }

        if (StunSlamData.getMode() == StunSlamData.Mode.SWAP_ASSIST) {
            tickSwapAssist(player);
        } else {
            tickMacro(client, player);
        }

        drainClicks(client);
    }

    /** Called when the macro keybind is pressed. */
    public static void startMacro(class_310 client) {
        class_1657 player = client.field_1724;
        if (!StunSlamData.isEnabled() || player == null) return;
        if (StunSlamData.getMode() != StunSlamData.Mode.MACRO) return;
        if (macroStep >= 0) return; // already running

        class_1661 inventory = player.method_31548();
        macroSpearSlot = findHotbarSlot(inventory, Weapon.SPEAR);
        macroAxeSlot   = findHotbarSlot(inventory, Weapon.AXE);
        macroMaceSlot  = findHotbarSlot(inventory, Weapon.MACE);

        // Nothing to run without the full set — a partial combo would just swing
        // whatever happened to be selected.
        if (macroSpearSlot < 0 || macroAxeSlot < 0 || macroMaceSlot < 0) return;

        macroStep = 0;
    }

    private static void tickSwapAssist(class_1657 player) {
        Weapon held = classify(player.method_6047());
        if (held == lastHeld) return;

        if (lastHeld == Weapon.SPEAR && held == Weapon.AXE) {
            pendingClicks += StunSlamData.getAxeClicks();
        } else if (lastHeld == Weapon.AXE && held == Weapon.MACE) {
            pendingClicks += StunSlamData.getMaceClicks();
        }

        lastHeld = held;
    }

    private static void tickMacro(class_310 client, class_1657 player) {
        if (macroStep < 0) return;

        class_1661 inventory = player.method_31548();
        switch (macroStep) {
            case 0 -> { inventory.method_61496(macroSpearSlot); pendingClicks += 1; }
            case 1 -> { inventory.method_61496(macroAxeSlot);   pendingClicks += StunSlamData.getAxeClicks(); }
            case 2 -> { inventory.method_61496(macroMaceSlot);  pendingClicks += StunSlamData.getMaceClicks(); }
            default -> { macroStep = -1; return; }
        }
        macroStep++;

        // Keep swap assist from double-firing on the slots the macro just changed.
        lastHeld = classify(player.method_6047());
    }

    private static void drainClicks(class_310 client) {
        if (pendingClicks <= 0) return;
        pendingClicks--;
        ((MinecraftAutoclickerInvoker) (Object) client).superawesomemod$startAttack();
    }

    private static void reset() {
        lastHeld = Weapon.NONE;
        pendingClicks = 0;
        macroStep = -1;
    }

    private static Weapon classify(class_1799 stack) {
        if (stack.method_7960()) return Weapon.NONE;
        if (stack.method_31574(class_1802.field_49814)) return Weapon.MACE;
        if (stack.method_31573(class_3489.field_63257)) return Weapon.SPEAR;
        if (stack.method_31573(class_3489.field_42612)) return Weapon.AXE;
        return Weapon.NONE;
    }

    private static int findHotbarSlot(class_1661 inventory, Weapon weapon) {
        for (int i = 0; i < class_1661.method_7368(); i++) {
            if (classify(inventory.method_5438(i)) == weapon) return i;
        }
        return -1;
    }
}
