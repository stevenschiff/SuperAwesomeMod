package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class KeystrokesScreen extends class_437 {

    private final class_437 parent;

    public KeystrokesScreen(class_437 parent) {
        super(class_2561.method_43470("Keystrokes"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789 / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;
        int gap  = 26;

        int topY = cy - 50;

        // Toggle
        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                KeystrokesData.setEnabled(!KeystrokesData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, topY, btnW, btnH).method_46431());

        // Size slider (1-10)
        this.method_37063(new ScaleSlider(
            cx - btnW / 2, topY + gap, btnW, btnH,
            KeystrokesData.getScale()
        ));

        // Corner cycle button
        this.method_37063(class_4185.method_46430(
            cornerLabel(),
            btn -> {
                KeystrokesData.setCorner((KeystrokesData.getCorner() + 1) % 4);
                btn.method_25355(cornerLabel());
            }
        ).method_46434(cx - btnW / 2, topY + gap * 2, btnW, btnH).method_46431());

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, topY + gap * 3, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(KeystrokesData.isEnabled()
            ? "Keystrokes: Enabled" : "Keystrokes: Disabled");
    }

    private class_2561 cornerLabel() {
        return class_2561.method_43470("Corner: " + KeystrokesData.getCornerName());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 76, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Shows WASD + Space key presses on screen"),
            cx, cy - 64, 0xAAAAAA);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class ScaleSlider extends class_357 {
        ScaleSlider(int x, int y, int w, int h, int initialScale) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initialScale));
            this.method_25346();
        }

        private static double normalize(int scale) {
            return (double) (scale - 1) / 9.0;
        }

        @Override
        protected void method_25346() {
            int s = (int) Math.round(this.field_22753 * 9.0 + 1.0);
            this.method_25355(class_2561.method_43470("Size: " + s));
        }

        @Override
        protected void method_25344() {
            int s = (int) Math.round(this.field_22753 * 9.0 + 1.0);
            KeystrokesData.setScale(s);
        }
    }
}
