package com.steveplays.superawesomemod;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class MiniMapWaypointListScreen extends class_437 {

    private final class_437 parent;
    private int scrollOffset = 0;

    private static final int BTN_W = 200;
    private static final int BTN_H = 20;
    private static final int ROW_HEIGHT = 24;
    private static final int VISIBLE_ROWS = 6;

    public MiniMapWaypointListScreen(class_437 parent) {
        super(class_2561.method_43470("Waypoints"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 80;

        List<MiniMapWaypoint> waypoints = MiniMapData.getWaypoints();

        int end = Math.min(scrollOffset + VISIBLE_ROWS, waypoints.size());
        for (int i = scrollOffset; i < end; i++) {
            MiniMapWaypoint wp = waypoints.get(i);
            int rowY = topY + (i - scrollOffset) * ROW_HEIGHT;
            final int index = i;

            // Waypoint name + coords button (display only)
            String label = wp.name() + " (" + wp.x() + ", " + wp.z() + ")";
            this.method_37063(class_4185.method_46430(
                class_2561.method_43470(label),
                btn -> {} // no action, just display
            ).method_46434(cx - BTN_W / 2, rowY, BTN_W - 50, BTN_H).method_46431());

            // Delete button
            this.method_37063(class_4185.method_46430(
                class_2561.method_43470("Del"),
                btn -> {
                    MiniMapData.removeWaypoint(index);
                    MiniMapPersistence.markDirty();
                    this.method_41843();
                }
            ).method_46434(cx + BTN_W / 2 - 46, rowY, 46, BTN_H).method_46431());
        }

        // Add new waypoint button
        int btnY = topY + VISIBLE_ROWS * ROW_HEIGHT + 8;
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Add Waypoint"),
            btn -> this.field_22787.method_1507(new MiniMapWaypointScreen(this))
        ).method_46434(cx - BTN_W / 2, btnY, BTN_W, BTN_H).method_46431());

        // Back button
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, btnY + 28, 100, BTN_H).method_46431());
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        int maxOffset = Math.max(0, MiniMapData.getWaypoints().size() - VISIBLE_ROWS);
        scrollOffset = (int) Math.max(0, Math.min(maxOffset, scrollOffset - scrollY));
        this.method_41843();
        return true;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 80;

        graphics.method_27534(this.field_22793, this.field_22785, cx, topY - 16, 0xFFFFFF);

        // Draw color indicators next to each visible waypoint
        List<MiniMapWaypoint> waypoints = MiniMapData.getWaypoints();
        int end = Math.min(scrollOffset + VISIBLE_ROWS, waypoints.size());
        for (int i = scrollOffset; i < end; i++) {
            MiniMapWaypoint wp = waypoints.get(i);
            int rowY = topY + (i - scrollOffset) * ROW_HEIGHT;
            int indicatorX = cx - BTN_W / 2 - 18;
            int color = 0xFF000000 | wp.color();
            graphics.method_25294(indicatorX, rowY + 2, indicatorX + 14, rowY + 18, color);
        }

        // Scroll indicator
        if (waypoints.size() > VISIBLE_ROWS) {
            String scrollText = (scrollOffset + 1) + "-"
                + Math.min(scrollOffset + VISIBLE_ROWS, waypoints.size())
                + " of " + waypoints.size();
            graphics.method_25300(this.field_22793, scrollText,
                cx, topY + VISIBLE_ROWS * ROW_HEIGHT - 4, 0x888888);
        }

        if (waypoints.isEmpty()) {
            graphics.method_25300(this.field_22793, "No waypoints yet",
                cx, topY + 40, 0x888888);
        }

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
