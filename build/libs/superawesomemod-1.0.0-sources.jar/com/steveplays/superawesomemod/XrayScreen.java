package com.steveplays.superawesomemod;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class XrayScreen extends class_437 {

    private final class_437 parent;
    private class_342 searchBox;
    private String searchText = "";
    private int scrollOffset = 0;
    private List<XrayOreEntry> filteredOres = new ArrayList<>();

    private static final int BTN_W = 200;
    private static final int BTN_H = 20;
    private static final int ROW_HEIGHT = 24;
    private static final int VISIBLE_ROWS = 6;

    public XrayScreen(class_437 parent) {
        super(class_2561.method_43470("X-Ray"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 90;

        // Master toggle
        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                XrayData.setEnabled(!XrayData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - BTN_W / 2, topY, BTN_W, BTN_H).method_46431());

        // Search box
        searchBox = new class_342(this.field_22793, cx - BTN_W / 2, topY + 28, BTN_W, BTN_H,
            class_2561.method_43470("Search"));
        searchBox.method_47404(class_2561.method_43470("Search ores..."));
        searchBox.method_1852(searchText);
        searchBox.method_1863(text -> {
            searchText = text;
            scrollOffset = 0;
            rebuildOreList();
            this.method_41843();
        });
        this.method_37063(searchBox);

        // Filter ores based on current search
        rebuildOreList();

        // Ore toggle buttons (scrollable region)
        int listStartY = topY + 56;
        int end = Math.min(scrollOffset + VISIBLE_ROWS, filteredOres.size());
        for (int i = scrollOffset; i < end; i++) {
            XrayOreEntry ore = filteredOres.get(i);
            int rowY = listStartY + (i - scrollOffset) * ROW_HEIGHT;

            this.method_37063(class_4185.method_46430(
                oreLabel(ore),
                btn -> {
                    XrayData.toggleOre(ore.name());
                    btn.method_25355(oreLabel(ore));
                }
            ).method_46434(cx - BTN_W / 2, rowY, BTN_W, BTN_H).method_46431());
        }

        // Back button (fixed position below scroll area)
        int backY = listStartY + VISIBLE_ROWS * ROW_HEIGHT + 8;
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, backY, 100, BTN_H).method_46431());
    }

    private void rebuildOreList() {
        String query = searchText.toLowerCase().trim();
        filteredOres.clear();
        for (XrayOreEntry ore : XrayOreEntry.ALL) {
            if (query.isEmpty() || ore.name().toLowerCase().contains(query)) {
                filteredOres.add(ore);
            }
        }
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(XrayData.isEnabled()
            ? "X-Ray: Enabled" : "X-Ray: Disabled");
    }

    private class_2561 oreLabel(XrayOreEntry ore) {
        boolean on = XrayData.isOreEnabled(ore.name());
        String prefix = on ? "[x] " : "[ ] ";
        String query = searchText.toLowerCase().trim();
        if (!query.isEmpty()) {
            return class_2561.method_43470(prefix + ore.name()).method_27694(s -> s.method_36139(0xFFFF55));
        }
        return class_2561.method_43470(prefix + ore.name());
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY,
                                  double scrollX, double scrollY) {
        int maxOffset = Math.max(0, filteredOres.size() - VISIBLE_ROWS);
        scrollOffset = Math.clamp((long) (scrollOffset - (int) scrollY), 0, maxOffset);
        this.method_41843();
        return true;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 90;

        // Title and subtitle
        graphics.method_27534(this.field_22793, this.field_22785, cx, topY - 20, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Highlight ores through walls"),
            cx, topY - 8, 0xAAAAAA);

        // Draw color indicators next to each visible ore button
        int listStartY = topY + 56;
        int end = Math.min(scrollOffset + VISIBLE_ROWS, filteredOres.size());
        for (int i = scrollOffset; i < end; i++) {
            XrayOreEntry ore = filteredOres.get(i);
            int rowY = listStartY + (i - scrollOffset) * ROW_HEIGHT;
            int indicatorX = cx + BTN_W / 2 + 4;
            graphics.method_25294(indicatorX, rowY + 2, indicatorX + 16, rowY + 18,
                0xFF000000 | ore.color());
        }

        // Scroll indicator
        if (filteredOres.size() > VISIBLE_ROWS) {
            String scrollText = (scrollOffset + 1) + "-"
                + Math.min(scrollOffset + VISIBLE_ROWS, filteredOres.size())
                + " of " + filteredOres.size();
            graphics.method_27534(this.field_22793,
                class_2561.method_43470(scrollText),
                cx, listStartY + VISIBLE_ROWS * ROW_HEIGHT - 6, 0x888888);
        }

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
