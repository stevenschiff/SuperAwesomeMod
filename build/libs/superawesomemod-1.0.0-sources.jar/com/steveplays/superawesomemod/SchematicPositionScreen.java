package com.steveplays.superawesomemod;

import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Screen for editing the schematic placement position, rotation, and mirror.
 */
public class SchematicPositionScreen extends class_437 {

    private final class_437 parent;
    private class_342 xBox, yBox, zBox;

    private static final int BTN_W = 200;
    private static final int BTN_H = 20;
    private static final int FIELD_W = 60;

    public SchematicPositionScreen(class_437 parent) {
        super(class_2561.method_43470("Schematic Position"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 70;
        int gap = 24;

        SchematicPlacement placement = SchematicData.getCurrentPlacement();
        class_2338 origin = placement != null ? placement.getOrigin() : class_2338.field_10980;

        // X / Y / Z edit boxes in a row
        int fieldsY = topY;
        int totalW = FIELD_W * 3 + 8 * 2; // 3 fields + 2 gaps
        int startX = cx - totalW / 2;

        xBox = new class_342(this.field_22793, startX, fieldsY, FIELD_W, BTN_H, class_2561.method_43470("X"));
        xBox.method_1852(String.valueOf(origin.method_10263()));
        this.method_37063(xBox);

        yBox = new class_342(this.field_22793, startX + FIELD_W + 8, fieldsY, FIELD_W, BTN_H, class_2561.method_43470("Y"));
        yBox.method_1852(String.valueOf(origin.method_10264()));
        this.method_37063(yBox);

        zBox = new class_342(this.field_22793, startX + (FIELD_W + 8) * 2, fieldsY, FIELD_W, BTN_H, class_2561.method_43470("Z"));
        zBox.method_1852(String.valueOf(origin.method_10260()));
        this.method_37063(zBox);

        // Apply position button
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Apply Position"),
            btn -> applyPosition()
        ).method_46434(cx - BTN_W / 2, topY + gap, BTN_W, BTN_H).method_46431());

        // Set to Player Position
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Set to Player Position"),
            btn -> {
                class_310 mc = class_310.method_1551();
                if (mc.field_1724 != null) {
                    class_2338 pos = mc.field_1724.method_24515();
                    xBox.method_1852(String.valueOf(pos.method_10263()));
                    yBox.method_1852(String.valueOf(pos.method_10264()));
                    zBox.method_1852(String.valueOf(pos.method_10260()));
                    applyPosition();
                }
            }
        ).method_46434(cx - BTN_W / 2, topY + gap * 2, BTN_W, BTN_H).method_46431());

        // Nudge buttons row
        int nudgeY = topY + gap * 3;
        int smallBtn = 30;
        int nudgeStart = cx - (smallBtn * 6 + 4 * 5) / 2;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("X-"), btn -> nudge(-1, 0, 0))
            .method_46434(nudgeStart, nudgeY, smallBtn, BTN_H).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("X+"), btn -> nudge(1, 0, 0))
            .method_46434(nudgeStart + smallBtn + 4, nudgeY, smallBtn, BTN_H).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Y-"), btn -> nudge(0, -1, 0))
            .method_46434(nudgeStart + (smallBtn + 4) * 2, nudgeY, smallBtn, BTN_H).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Y+"), btn -> nudge(0, 1, 0))
            .method_46434(nudgeStart + (smallBtn + 4) * 3, nudgeY, smallBtn, BTN_H).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Z-"), btn -> nudge(0, 0, -1))
            .method_46434(nudgeStart + (smallBtn + 4) * 4, nudgeY, smallBtn, BTN_H).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Z+"), btn -> nudge(0, 0, 1))
            .method_46434(nudgeStart + (smallBtn + 4) * 5, nudgeY, smallBtn, BTN_H).method_46431());

        // Rotation cycle
        this.method_37063(class_4185.method_46430(
            rotationLabel(),
            btn -> {
                if (placement != null) {
                    placement.cycleRotation();
                    SchematicVerifier.clearCache();
                    btn.method_25355(rotationLabel());
                }
            }
        ).method_46434(cx - BTN_W / 2, topY + gap * 4, BTN_W, BTN_H).method_46431());

        // Mirror toggle
        this.method_37063(class_4185.method_46430(
            mirrorLabel(),
            btn -> {
                if (placement != null) {
                    placement.toggleMirror();
                    SchematicVerifier.clearCache();
                    btn.method_25355(mirrorLabel());
                }
            }
        ).method_46434(cx - BTN_W / 2, topY + gap * 5, BTN_W, BTN_H).method_46431());

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, topY + gap * 6 + 8, 100, BTN_H).method_46431());
    }

    private void applyPosition() {
        SchematicPlacement placement = SchematicData.getCurrentPlacement();
        if (placement == null) return;

        try {
            int x = Integer.parseInt(xBox.method_1882().trim());
            int y = Integer.parseInt(yBox.method_1882().trim());
            int z = Integer.parseInt(zBox.method_1882().trim());
            placement.setOrigin(new class_2338(x, y, z));
            SchematicVerifier.clearCache();
        } catch (NumberFormatException ignored) {
            // Invalid input, do nothing
        }
    }

    private void nudge(int dx, int dy, int dz) {
        SchematicPlacement placement = SchematicData.getCurrentPlacement();
        if (placement == null) return;

        class_2338 origin = placement.getOrigin();
        class_2338 newOrigin = origin.method_10069(dx, dy, dz);
        placement.setOrigin(newOrigin);
        SchematicVerifier.clearCache();

        xBox.method_1852(String.valueOf(newOrigin.method_10263()));
        yBox.method_1852(String.valueOf(newOrigin.method_10264()));
        zBox.method_1852(String.valueOf(newOrigin.method_10260()));
    }

    private class_2561 rotationLabel() {
        SchematicPlacement placement = SchematicData.getCurrentPlacement();
        String rot = placement != null ? placement.getRotationName() : "0°";
        return class_2561.method_43470("Rotation: " + rot);
    }

    private class_2561 mirrorLabel() {
        SchematicPlacement placement = SchematicData.getCurrentPlacement();
        boolean m = placement != null && placement.isMirror();
        return class_2561.method_43470(m ? "Mirror: On" : "Mirror: Off");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 70;

        graphics.method_27534(this.field_22793, this.field_22785, cx, topY - 16, 0xFFFFFF);

        // Field labels
        int totalW = FIELD_W * 3 + 8 * 2;
        int startX = cx - totalW / 2;
        graphics.method_25303(this.field_22793, "X", startX, topY - 10, 0xAAAAAA);
        graphics.method_25303(this.field_22793, "Y", startX + FIELD_W + 8, topY - 10, 0xAAAAAA);
        graphics.method_25303(this.field_22793, "Z", startX + (FIELD_W + 8) * 2, topY - 10, 0xAAAAAA);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
