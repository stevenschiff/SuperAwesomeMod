package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class AppleSkinScreen extends GabeOptionScreen {

    public AppleSkinScreen(class_437 parent) {
        super(parent, "AppleSkin");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", AppleSkinData::isEnabled, AppleSkinData::setEnabled);
        info("Shows saturation and food values");
    }
}
