package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;

@SuppressWarnings("deprecation")
public final class ArmorHudOverlay {

    // Helmet, chestplate, leggings, boots — left to right.
    private static final class_1304[] SLOTS = {
        class_1304.field_6169,
        class_1304.field_6174,
        class_1304.field_6172,
        class_1304.field_6166
    };

    private static final int BASE_ICON_SIZE = 16;
    private static final int SHIELD_GAP = 32;

    private ArmorHudOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(ArmorHudOverlay::onHudRender);
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter) {
        if (!ArmorHudData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;

        class_746 player = mc.field_1724;
        if (player == null) return;

        int width  = graphics.method_51421();
        int height = graphics.method_51443();
        float scale = ArmorHudData.getScale();
        float iconSize = BASE_ICON_SIZE * scale;
        float gap = 2 * scale;

        // Calculate total row width and position it left of the hotbar
        float rowWidth = SLOTS.length * iconSize + (SLOTS.length - 1) * gap;
        float xLeft    = width / 2.0f - 91 - SHIELD_GAP - rowWidth;
        float yTop     = height - 19 - (iconSize - BASE_ICON_SIZE); // align bottom with hotbar

        int durabilityHeight = ArmorHudData.getDurabilityHeight();

        for (int i = 0; i < SLOTS.length; i++) {
            class_1799 stack = player.method_6118(SLOTS[i]);
            if (stack.method_7960()) continue;

            float x = xLeft + i * (iconSize + gap);

            // Render the item icon scaled
            graphics.method_51448().pushMatrix();
            graphics.method_51448().translate(x, yTop);
            graphics.method_51448().scale(scale, scale);
            graphics.method_51427(stack, 0, 0);
            graphics.method_51431(mc.field_1772, stack, 0, 0);
            graphics.method_51448().popMatrix();

            // Draw durability number above the icon
            if (stack.method_7963()) {
                int durability = stack.method_7936() - stack.method_7919();
                int maxDurability = stack.method_7936();
                float ratio = (float) durability / maxDurability;

                // Color: green >60%, yellow 30-60%, red <=30%
                int color;
                if (ratio > 0.6f) {
                    color = 0xFF55FF55; // green
                } else if (ratio > 0.3f) {
                    color = 0xFFFFFF55; // yellow
                } else {
                    color = 0xFFFF5555; // red
                }

                String text = durability + "/" + maxDurability;
                int textWidth = mc.field_1772.method_1727(text);
                int textX = (int) (x + iconSize / 2) - textWidth / 2;
                int textY = (int) yTop - durabilityHeight;
                graphics.method_51433(mc.field_1772, text, textX, textY, color, true);
            }
        }
    }
}
