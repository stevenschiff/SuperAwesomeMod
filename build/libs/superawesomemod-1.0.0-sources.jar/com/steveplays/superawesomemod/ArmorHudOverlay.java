package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.class_10799;
import net.minecraft.class_1657;
import net.minecraft.class_1934;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;

public final class ArmorHudOverlay {

    private static final class_2960 ARMOR_FULL_SPRITE  = class_2960.method_60656("hud/armor_full");
    private static final class_2960 ARMOR_HALF_SPRITE  = class_2960.method_60656("hud/armor_half");
    private static final class_2960 ARMOR_EMPTY_SPRITE = class_2960.method_60656("hud/armor_empty");

    private static final class_2960 ID = class_2960.method_60655("superawesomemod", "armor_hud");

    private ArmorHudOverlay() {}

    public static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.ARMOR_BAR, ID, (graphics, tickCounter) -> {
            if (!ArmorHudData.isEnabled()) return;

            class_310 mc = class_310.method_1551();
            if (mc.field_1690.field_1842) return;

            class_746 player = mc.field_1724;
            if (player == null) return;

            // Match vanilla: armor bar is hidden in spectator/creative.
            if (mc.field_1761 != null) {
                class_1934 type = mc.field_1761.method_2920();
                if (type == class_1934.field_9219 || type == class_1934.field_9220) return;
            }

            int armor = player.method_6096();
            if (armor <= 0) return;

            renderArmor(graphics, player, armor);
        });
    }

    private static void renderArmor(class_332 graphics, class_1657 player, int armor) {
        int width  = graphics.method_51421();
        int height = graphics.method_51443();
        int leftSide = width / 2 - 91;
        // Vanilla stacks status bars in 10px rows above the hotbar; armor sits one row above health.
        int y = height - 39 - 10;

        for (int i = 0; i < 10; i++) {
            int x = leftSide + i * 8;
            class_2960 sprite;
            if (i * 2 + 1 < armor) {
                sprite = ARMOR_FULL_SPRITE;
            } else if (i * 2 + 1 == armor) {
                sprite = ARMOR_HALF_SPRITE;
            } else {
                sprite = ARMOR_EMPTY_SPRITE;
            }
            graphics.method_52706(class_10799.field_56883, sprite, x, y, 9, 9);
        }
    }
}
