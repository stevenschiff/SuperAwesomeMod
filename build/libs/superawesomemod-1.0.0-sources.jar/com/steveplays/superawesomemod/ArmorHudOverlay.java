package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;

@SuppressWarnings("deprecation")
public final class ArmorHudOverlay {

    // Helmet, chestplate, leggings, boots — left to right.
    private static final class_1304[] SLOTS = {
        class_1304.field_6169,
        class_1304.field_6174,
        class_1304.field_6172,
        class_1304.field_6166
    };

    private static final int ICON_SIZE = 16;
    // Pixels of empty space to leave between the armor row and the hotbar/offhand for the shield slot.
    private static final int SHIELD_GAP = 32;

    private ArmorHudOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(ArmorHudOverlay::onHudRender);
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter) {
        if (!ArmorHudData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;

        class_746 player = mc.field_1724;
        if (player == null) return;

        int width  = graphics.method_51421();
        int height = graphics.method_51443();

        // Hotbar's left edge is at width/2 - 91. Place the armor row to the left of that,
        // leaving SHIELD_GAP pixels free for the offhand/shield slot.
        int rowWidth = SLOTS.length * ICON_SIZE;
        int xLeft    = width / 2 - 91 - SHIELD_GAP - rowWidth;
        int yTop     = height - 19; // matches the y of hotbar items

        for (int i = 0; i < SLOTS.length; i++) {
            class_1799 stack = player.method_6118(SLOTS[i]);
            if (stack.method_7960()) continue;

            int x = xLeft + i * ICON_SIZE;
            graphics.method_51427(stack, x, yTop);
            // Draws the vanilla durability bar (green/yellow/red) at the bottom of the icon.
            graphics.method_51431(mc.field_1772, stack, x, yTop);
        }
    }
}
