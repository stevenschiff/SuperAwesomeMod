package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class ItemPhysicsScreen extends GabeOptionScreen {

    public ItemPhysicsScreen(class_437 parent) {
        super(parent, "Item Physics");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", ItemPhysicsData::isEnabled, ItemPhysicsData::setEnabled);
        info("Dropped items lie flat on the ground");
    }
}
