package com.steveplays.superawesomemod.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client-to-server packet that carries a new jump height multiplier.
 * Sent by the GUI; handled server-side to update PlayerJumpData.
 * Uses Fabric networking — not subject to command permission checks.
 */
public record JumpHeightPayload(float multiplier) implements class_8710 {

    public static final class_8710.class_9154<JumpHeightPayload> TYPE =
        new class_8710.class_9154<>(class_2960.method_60655("superawesomemod", "jump_height"));

    public static final class_9139<ByteBuf, JumpHeightPayload> CODEC =
        class_9135.field_48552.method_56432(JumpHeightPayload::new, JumpHeightPayload::multiplier);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
