package com.steveplays.superawesomemod.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client-to-server packet that explicitly sets the player's fly ability state.
 * Carries the intended enabled/disabled state to avoid toggle-race issues.
 */
public record ToggleFlyPayload(boolean enabled) implements class_8710 {

    public static final class_8710.class_9154<ToggleFlyPayload> TYPE =
        new class_8710.class_9154<>(class_2960.method_60655("superawesomemod", "toggle_fly"));

    public static final class_9139<ByteBuf, ToggleFlyPayload> CODEC =
        class_9135.field_48547.method_56432(ToggleFlyPayload::new, ToggleFlyPayload::enabled);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
