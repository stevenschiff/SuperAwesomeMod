package com.steveplays.superawesomemod.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client-to-server packet that sets the player's flying speed.
 */
public record FlySpeedPayload(float speed) implements class_8710 {

    // Creative default is 0.05f. Values are intentionally small — the engine
    // multiplies this internally so even 0.2f feels very fast.
    public static final float SLOW      = 0.02f;
    public static final float NORMAL    = 0.05f;  // creative default
    public static final float FAST      = 0.1f;
    public static final float VERY_FAST = 0.2f;

    public static final class_8710.class_9154<FlySpeedPayload> TYPE =
        new class_8710.class_9154<>(class_2960.method_60655("superawesomemod", "fly_speed"));

    public static final class_9139<ByteBuf, FlySpeedPayload> CODEC =
        class_9135.field_48552.method_56432(FlySpeedPayload::new, FlySpeedPayload::speed);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
