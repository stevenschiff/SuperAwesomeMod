package com.steveplays.superawesomemod.network;

import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * Client-to-server packet that sets the player's entity interaction (attack) range.
 */
public record AttackRangePayload(float range) implements class_8710 {

    public static final float DEFAULT = 3.0f;  // vanilla survival default
    public static final float MIN     = 1.0f;
    public static final float MAX     = 64.0f;

    public static final class_8710.class_9154<AttackRangePayload> TYPE =
        new class_8710.class_9154<>(class_2960.method_60655("superawesomemod", "attack_range"));

    public static final class_9139<ByteBuf, AttackRangePayload> CODEC =
        class_9135.field_48552.method_56432(AttackRangePayload::new, AttackRangePayload::range);

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}
