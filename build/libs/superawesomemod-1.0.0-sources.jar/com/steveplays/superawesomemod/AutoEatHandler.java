package com.steveplays.superawesomemod;

import com.steveplays.superawesomemod.mixin.MinecraftAutoclickerInvoker;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4174;
import net.minecraft.class_746;
import net.minecraft.class_9334;

/**
 * Eats for you when hunger drops, then puts you back on the slot you were holding.
 *
 * <p>Hunger itself is server state we cannot write — but the server <em>tells</em> us
 * our food level in {@code ClientboundSetHealthPacket}, and reading it is all that is
 * needed to decide. Eating is then an ordinary item use, which every server accepts,
 * so this reaches the goal on servers where cancelling exhaustion cannot.
 *
 * <p>Only eats while standing still and not otherwise using an item, so it can't
 * interrupt a bow draw or fire mid-fight when you meant to swing.
 */
public final class AutoEatHandler {

    private static boolean eating = false;
    private static int previousSlot = -1;

    private AutoEatHandler() {}

    public static void tick(class_310 client) {
        class_746 player = client.field_1724;
        if (!AutoEatData.isEnabled() || player == null || client.field_1755 != null) {
            stop(client);
            return;
        }

        class_1661 inventory = player.method_31548();

        if (eating) {
            // Keep holding use until the bite completes or the food leaves our hand.
            if (player.method_6115() && isFood(player.method_6047())
                && player.method_7344().method_7586() < 20) {
                ((MinecraftAutoclickerInvoker) (Object) client).superawesomemod$startUseItem();
                return;
            }
            stop(client);
            return;
        }

        if (player.method_7344().method_7586() > AutoEatData.getThreshold()) return;
        // Don't hijack a bow draw, a shield, or anything else already in progress.
        if (player.method_6115()) return;

        int slot = bestFoodSlot(inventory);
        if (slot < 0) return;

        previousSlot = inventory.method_67532();
        inventory.method_61496(slot);
        eating = true;
        ((MinecraftAutoclickerInvoker) (Object) client).superawesomemod$startUseItem();
    }

    private static void stop(class_310 client) {
        if (!eating) return;
        eating = false;

        class_746 player = client.field_1724;
        if (player != null && previousSlot >= 0) {
            player.method_31548().method_61496(previousSlot);
        }
        previousSlot = -1;
    }

    /** Highest-nutrition food in the hotbar, or -1. */
    private static int bestFoodSlot(class_1661 inventory) {
        int best = -1;
        int bestNutrition = -1;

        for (int i = 0; i < class_1661.method_7368(); i++) {
            class_1799 stack = inventory.method_5438(i);
            class_4174 food = stack.method_58694(class_9334.field_50075);
            if (food == null) continue;

            if (food.comp_2491() > bestNutrition) {
                bestNutrition = food.comp_2491();
                best = i;
            }
        }
        return best;
    }

    private static boolean isFood(class_1799 stack) {
        return !stack.method_7960() && stack.method_58694(class_9334.field_50075) != null;
    }
}
