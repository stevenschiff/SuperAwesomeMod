package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Toggles plus the review surface: session stats and a histogram of hit distances.
 * Hit-to-hit feedback lives on the HUD; this is where a practice run's progress shows.
 */
public class SpacingScreen extends class_437 {

    private final class_437 parent;

    public SpacingScreen(class_437 parent) {
        super(class_2561.method_43470("Spacing Trainer"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;
        int left = cx - btnW - 6;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                SpacingData.setEnabled(!SpacingData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(left, cy - 60, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            sub("Live meter", SpacingData.isShowMeter()),
            btn -> {
                SpacingData.setShowMeter(!SpacingData.isShowMeter());
                btn.method_25355(sub("Live meter", SpacingData.isShowMeter()));
            }
        ).method_46434(left, cy - 36, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            sub("Hit flash", SpacingData.isShowFlash()),
            btn -> {
                SpacingData.setShowFlash(!SpacingData.isShowFlash());
                btn.method_25355(sub("Hit flash", SpacingData.isShowFlash()));
            }
        ).method_46434(left, cy - 12, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            sub("Graded crosshair", SpacingData.isGradedCrosshair()),
            btn -> {
                SpacingData.setGradedCrosshair(!SpacingData.isGradedCrosshair());
                btn.method_25355(sub("Graded crosshair", SpacingData.isGradedCrosshair()));
            }
        ).method_46434(left, cy + 12, btnW, btnH).method_46431());

        this.method_37063(new ScaleSlider(left, cy + 36, btnW, btnH, SpacingData.getScale()));

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Reset session"),
            btn -> SpacingTracker.reset()
        ).method_46434(left, cy + 60, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(left, cy + 84, btnW, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(SpacingData.isEnabled()
            ? "Disable Spacing Trainer" : "Enable Spacing Trainer");
    }

    private static class_2561 sub(String name, boolean on) {
        return class_2561.method_43470(name + ": " + (on ? "On" : "Off"));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 84, 0xFFFFFF);

        boolean on = SpacingData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 72, on ? 0x55FF55 : 0xFF5555);

        drawStats(graphics, cx + 12, cy - 60);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    private void drawStats(class_332 graphics, int x, int y) {
        int swings = SpacingTracker.getSwings();

        graphics.method_51433(this.field_22793, "Session", x, y, 0xFFFFFF, false);
        y += 12;

        if (swings == 0) {
            graphics.method_51433(this.field_22793, "No swings yet.", x, y, 0xAAAAAA, false);
            graphics.method_51433(this.field_22793, "Hit something to start.", x, y + 10, 0xAAAAAA, false);
            return;
        }

        graphics.method_51433(this.field_22793,
            String.format("Mean gap: %.2f", SpacingTracker.getMeanGap()), x, y, 0xFFFFFF, false);
        y += 10;
        graphics.method_51433(this.field_22793,
            String.format("Range: %.2f - %.2f", SpacingTracker.getMinGap(), SpacingTracker.getMaxGap()),
            x, y, 0xAAAAAA, false);
        y += 10;
        graphics.method_51433(this.field_22793,
            String.format("In good band: %.0f%%", SpacingTracker.getInBandPercent()),
            x, y, 0xFF55FF55, false);
        y += 10;
        graphics.method_51433(this.field_22793,
            String.format("Confirmed: %.0f%% of %d", SpacingTracker.getConfirmedPercent(), swings),
            x, y, 0xAAAAAA, false);
        y += 10;
        // Stated plainly: an unconfirmed swing is not proof of a reach failure.
        graphics.method_51433(this.field_22793, "(i-frames and shields also hide hits)",
            x, y, 0xFF888888, false);
        y += 16;

        drawHistogram(graphics, x, y);
    }

    private void drawHistogram(class_332 graphics, int x, int y) {
        int[] buckets = SpacingTracker.getBuckets();
        int peak = 1;
        for (int c : buckets) peak = Math.max(peak, c);

        graphics.method_51433(this.field_22793, "Hit distances", x, y, 0xFFFFFF, false);
        y += 12;

        int rowH = 7;
        int maxBarW = 90;
        double reach = 3.0;

        for (int i = 0; i < buckets.length; i++) {
            double low = i * SpacingTracker.BUCKET_SIZE;
            if (low > reach + SpacingTracker.BUCKET_SIZE) break;

            int barW = (int) Math.round((double) buckets[i] / peak * maxBarW);
            int color = SpacingData.zoneOf(low + SpacingTracker.BUCKET_SIZE / 2, reach).argb;

            String tag = String.format("%.2f", low);
            graphics.method_51433(this.field_22793, tag, x, y, 0xFF777777, false);

            int barX = x + 26;
            graphics.method_25294(barX, y, barX + maxBarW, y + rowH - 2, 0x40000000);
            if (barW > 0) graphics.method_25294(barX, y, barX + barW, y + rowH - 2, color);
            if (buckets[i] > 0) {
                graphics.method_51433(this.field_22793, String.valueOf(buckets[i]),
                    barX + maxBarW + 4, y, 0xFFAAAAAA, false);
            }
            y += rowH;
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class ScaleSlider extends class_357 {
        ScaleSlider(int x, int y, int w, int h, int initial) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.method_25346();
        }

        private static double normalize(int v) {
            return (double) (v - SpacingData.MIN_SCALE)
                 / (SpacingData.MAX_SCALE - SpacingData.MIN_SCALE);
        }

        private int denormalize() {
            return (int) Math.round(this.field_22753
                * (SpacingData.MAX_SCALE - SpacingData.MIN_SCALE) + SpacingData.MIN_SCALE);
        }

        @Override
        protected void method_25346() {
            this.method_25355(class_2561.method_43470("HUD size: " + denormalize()));
        }

        @Override
        protected void method_25344() {
            SpacingData.setScale(denormalize());
        }
    }
}
