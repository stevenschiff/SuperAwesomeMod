package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class CombatHitboxScreen extends class_437 {

    private final class_437 parent;

    public CombatHitboxScreen(class_437 parent) {
        super(class_2561.method_43470("Combat Hitboxes"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789 / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        int y = cy - 92;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                CombatHitboxData.setEnabled(!CombatHitboxData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += 25;

        this.method_37063(class_4185.method_46430(
            xrayLabel(),
            btn -> {
                CombatHitboxData.setSeeThroughWalls(!CombatHitboxData.isSeeThroughWalls());
                btn.method_25355(xrayLabel());
            }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += 25;

        this.method_37063(class_4185.method_46430(
            scopeLabel(),
            btn -> {
                CombatHitboxData.setPlayersOnly(!CombatHitboxData.isPlayersOnly());
                btn.method_25355(scopeLabel());
            }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += 25;

        this.method_37063(class_4185.method_46430(
            invisibleLabel(),
            btn -> {
                CombatHitboxData.setShowInvisible(!CombatHitboxData.isShowInvisible());
                btn.method_25355(invisibleLabel());
            }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += 25;

        this.method_37063(class_4185.method_46430(
            fullColorLabel(),
            btn -> {
                CombatHitboxData.setFullColor(!CombatHitboxData.isFullColor());
                btn.method_25355(fullColorLabel());
            }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += 25;

        // In-range color cycle
        this.method_37063(class_4185.method_46430(
            inRangeColorLabel(),
            btn -> {
                int next = (CombatHitboxData.getInRangeColor() + 1) % CombatHitboxData.COLOR_NAMES.length;
                CombatHitboxData.setInRangeColor(next);
                btn.method_25355(inRangeColorLabel());
            }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += 25;

        // Out-of-range color cycle
        this.method_37063(class_4185.method_46430(
            outOfRangeColorLabel(),
            btn -> {
                int next = (CombatHitboxData.getOutOfRangeColor() + 1) % CombatHitboxData.COLOR_NAMES.length;
                CombatHitboxData.setOutOfRangeColor(next);
                btn.method_25355(outOfRangeColorLabel());
            }
        ).method_46434(cx - btnW / 2, y, btnW, btnH).method_46431());
        y += 25;

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, y, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(CombatHitboxData.isEnabled()
            ? "Combat Hitboxes: Enabled"
            : "Combat Hitboxes: Disabled");
    }

    private class_2561 xrayLabel() {
        return class_2561.method_43470(CombatHitboxData.isSeeThroughWalls()
            ? "See Through Walls: Enabled"
            : "See Through Walls: Disabled");
    }

    private class_2561 scopeLabel() {
        return class_2561.method_43470(CombatHitboxData.isPlayersOnly()
            ? "Show: Players Only"
            : "Show: All Entities");
    }

    private class_2561 invisibleLabel() {
        return class_2561.method_43470(CombatHitboxData.isShowInvisible()
            ? "Show Invisible: Enabled"
            : "Show Invisible: Disabled");
    }

    private class_2561 fullColorLabel() {
        return class_2561.method_43470(CombatHitboxData.isFullColor()
            ? "Full Color: On"
            : "Full Color: Off");
    }

    private class_2561 inRangeColorLabel() {
        return class_2561.method_43470("In Range: " + CombatHitboxData.getInRangeColorName());
    }

    private class_2561 outOfRangeColorLabel() {
        return class_2561.method_43470("Out of Range: " + CombatHitboxData.getOutOfRangeColorName());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 100, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Customizable hitbox colors for in/out of attack range"),
            cx, cy - 100 + 14, 0xAAAAAA);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
