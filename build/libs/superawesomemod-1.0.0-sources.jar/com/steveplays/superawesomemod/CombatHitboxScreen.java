package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class CombatHitboxScreen extends GabeOptionScreen {

    public CombatHitboxScreen(class_437 parent) {
        super(parent, "Combat Hitboxes");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", CombatHitboxData::isEnabled, CombatHitboxData::setEnabled);
        toggle("Players only", CombatHitboxData::isPlayersOnly, CombatHitboxData::setPlayersOnly);
        toggle("Full color", CombatHitboxData::isFullColor, CombatHitboxData::setFullColor);
        cycle("In range", CombatHitboxData::getInRangeColorName,
            () -> CombatHitboxData.setInRangeColor(
                (CombatHitboxData.getInRangeColor() + 1) % CombatHitboxData.COLOR_NAMES.length));
        cycle("Out of range", CombatHitboxData::getOutOfRangeColorName,
            () -> CombatHitboxData.setOutOfRangeColor(
                (CombatHitboxData.getOutOfRangeColor() + 1) % CombatHitboxData.COLOR_NAMES.length));
        info("Outlines obey line of sight");
    }
}
