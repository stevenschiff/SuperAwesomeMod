package com.steveplays.superawesomemod;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.systems.RenderSystem;
import com.steveplays.superawesomemod.mixin.PostChainAccessor;
import com.steveplays.superawesomemod.mixin.PostPassAccessor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_279;
import net.minecraft.class_283;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_9920;

/**
 * Applies motion blur by blending the current frame with the previous frame.
 * Uses Minecraft's built-in PostChain system instead of Satin.
 */
public final class MotionBlurRenderer {

    private MotionBlurRenderer() {}

    private static final class_2960 POST_EFFECT_ID =
            class_2960.method_60655("superawesomemod", "motion_blur");

    private static class_279 postChain;
    private static float currentBlur = -1;

    public static void register() {
        // Rendering is handled via GameRendererMotionBlurMixin — nothing to register here.
    }

    /**
     * Called from {@code GameRendererMotionBlurMixin} after entity outlines,
     * right before vanilla post-effects and GUI rendering.
     */
    public static void onRenderPost(class_9920 resourcePool) {
        if (!MotionBlurData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        // Load (or re-acquire after shader reload) the PostChain.
        class_279 chain = mc.method_62887().method_62941(
                POST_EFFECT_ID,
                Set.of(class_279.field_53104)
        );
        if (chain == null) return;

        // Detect shader reload: ShaderManager returns a new instance after F3+T.
        if (chain != postChain) {
            postChain = chain;
            currentBlur = -1; // force uniform update
        }

        // Update the BlendFactor uniform when the strength changes.
        float alpha = MotionBlurData.getAlpha();
        if (alpha != currentBlur) {
            updateBlendFactor(alpha);
            currentBlur = alpha;
        }

        postChain.method_1258(mc.method_1522(), resourcePool);
    }

    private static void updateBlendFactor(float alpha) {
        List<class_283> passes = ((PostChainAccessor) postChain).superawesomemod$getPasses();
        if (passes.isEmpty()) return;

        // The first pass is the motion-blur blend pass that owns MotionBlurConfig.
        class_283 blendPass = passes.get(0);
        Map<String, GpuBuffer> uniforms =
                ((PostPassAccessor) blendPass).superawesomemod$getCustomUniforms();

        GpuBuffer old = uniforms.get("MotionBlurConfig");
        if (old != null && !old.isClosed()) {
            old.close();
        }

        // Pack a single float into a 16-byte buffer (std140 alignment).
        ByteBuffer buf = ByteBuffer.allocateDirect(16).order(ByteOrder.nativeOrder());
        buf.putFloat(0, alpha);

        GpuBuffer replacement = RenderSystem.getDevice().createBuffer(
                () -> "MotionBlurConfig",
                GpuBuffer.USAGE_UNIFORM,
                buf
        );
        uniforms.put("MotionBlurConfig", replacement);
    }
}
