package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_9779;
import java.util.ArrayList;
import java.util.List;

public final class MiniMapOverlay {

    private MiniMapOverlay() {}

    private static final int BORDER_COLOR = 0xFF333333;

    // Texture-based rendering for performance
    private static class_1043 mapTexture;
    private static class_1011 mapImage;
    private static class_2960 mapTextureId;
    private static int currentTextureSize = 0;

    // Update throttling: only regenerate terrain every N ticks
    private static int tickCounter = 0;
    private static final int UPDATE_INTERVAL = 5; // ~4 times per second
    private static double lastPlayerX = Double.NaN;
    private static double lastPlayerZ = Double.NaN;
    private static boolean needsUpdate = true;

    // Cached entity positions to avoid iterating all entities every frame
    private record EntityPos(double x, double z, int color) {}
    private static List<EntityPos> cachedPlayers = List.of();
    private static List<EntityPos> cachedEntities = List.of();

    public static void register() {
        HudRenderCallback.EVENT.register(MiniMapOverlay::onHudRender);
    }

    private static void ensureTexture(int size) {
        if (mapImage != null && currentTextureSize == size) return;

        // Clean up old texture
        if (mapTexture != null) {
            mapTexture.close();
        }
        if (mapTextureId != null) {
            class_310.method_1551().method_1531().method_4615(mapTextureId);
            mapTextureId = null;
        }

        // Create new — use size constructor so getPixels() returns the internal image
        mapTexture = new class_1043(() -> "superawesomemod_minimap_hud", size, size, false);
        mapImage = mapTexture.method_4525();
        mapTextureId = class_2960.method_60655("superawesomemod", "minimap_hud");
        class_310.method_1551().method_1531().method_4616(mapTextureId, mapTexture);
        currentTextureSize = size;
        needsUpdate = true;
    }

    private static void regenerateImage(class_310 mc, int size) {
        class_746 player = mc.field_1724;
        if (player == null) return;

        double playerX = player.method_23317();
        double playerZ = player.method_23321();
        int halfSize = size / 2;
        int startBX = (int) Math.floor(playerX) - halfSize;
        int startBZ = (int) Math.floor(playerZ) - halfSize;

        for (int px = 0; px < size; px++) {
            int bx = startBX + px;
            int chunkX = bx >> 4;
            int lx = bx & 15;

            // Cache chunk lookup per column — only changes when chunkZ changes
            int lastChunkZ = Integer.MIN_VALUE;
            int[] colors = null;

            for (int py = 0; py < size; py++) {
                int bz = startBZ + py;
                int cz = bz >> 4;

                if (cz != lastChunkZ) {
                    colors = MiniMapChunkCache.get(chunkX, cz);
                    lastChunkZ = cz;
                }

                int color;
                if (colors != null) {
                    color = colors[lx * 16 + (bz & 15)];
                } else {
                    color = 0xFF000000;
                }
                mapImage.method_4305(px, py, argbToAbgr(color));
            }
        }

        lastPlayerX = playerX;
        lastPlayerZ = playerZ;
    }

    private static int argbToAbgr(int argb) {
        int a = (argb >> 24) & 0xFF;
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;
        return (a << 24) | (b << 16) | (g << 8) | r;
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter_) {
        if (!MiniMapData.isEnabled()) return;
        if (!MiniMapData.isHudVisible()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 instanceof MiniMapFullScreen) return;

        int size = MiniMapData.getMinimapSize();
        ensureTexture(size);

        int guiW = graphics.method_51421();
        int guiH = graphics.method_51443();

        // Calculate origin based on corner setting
        int ox, oy;
        int margin = 4;
        switch (MiniMapData.getCorner()) {
            case 0 -> { ox = margin; oy = margin; }
            case 1 -> { ox = guiW - size - margin; oy = margin; }
            case 2 -> { ox = margin; oy = guiH - size - margin; }
            case 3 -> { ox = guiW - size - margin; oy = guiH - size - margin; }
            default -> { ox = guiW - size - margin; oy = margin; }
        }

        // Check if terrain texture needs regenerating
        tickCounter++;
        double playerX = mc.field_1724.method_23317();
        double playerZ = mc.field_1724.method_23321();
        boolean playerMoved = Double.isNaN(lastPlayerX)
            || Math.abs(playerX - lastPlayerX) > 1
            || Math.abs(playerZ - lastPlayerZ) > 1;

        if (needsUpdate || (tickCounter >= UPDATE_INTERVAL && playerMoved)) {
            regenerateImage(mc, size);
            mapTexture.method_4524();
            tickCounter = 0;
            needsUpdate = false;

            // Refresh entity cache at the same interval as terrain
            refreshEntityCache(mc);
        }

        // Render terrain as single texture blit
        graphics.method_25290(class_10799.field_56883, mapTextureId, ox, oy, 0.0f, 0.0f, size, size, size, size);

        // Draw waypoint markers
        class_746 player = mc.field_1724;
        int halfSize = size / 2;

        for (MiniMapWaypoint wp : MiniMapData.getVisibleWaypoints()) {
            int wpPx = halfSize + (int) (wp.x() - playerX);
            int wpPy = halfSize + (int) (wp.z() - playerZ);
            if (wpPx >= 0 && wpPx < size && wpPy >= 0 && wpPy < size) {
                int c = wp.color() | 0xFF000000;
                // Diamond shape
                graphics.method_25294(ox + wpPx - 2, oy + wpPy, ox + wpPx + 3, oy + wpPy + 1, c);
                graphics.method_25294(ox + wpPx - 1, oy + wpPy - 1, ox + wpPx + 2, oy + wpPy + 2, c);
                graphics.method_25294(ox + wpPx, oy + wpPy - 2, ox + wpPx + 1, oy + wpPy + 3, c);
            }
        }

        // Draw entities from cache (refreshed at UPDATE_INTERVAL, not every frame)
        int entityMode = MiniMapData.getEntityMode();

        if (entityMode >= 1) {
            // Draw players (cyan diamond shape)
            for (EntityPos ep : cachedPlayers) {
                int pPx = halfSize + (int) (ep.x - playerX);
                int pPy = halfSize + (int) (ep.z - playerZ);
                if (pPx >= 2 && pPx < size - 2 && pPy >= 2 && pPy < size - 2) {
                    graphics.method_25294(ox + pPx - 1, oy + pPy, ox + pPx + 2, oy + pPy + 1, 0xFF00FFFF);
                    graphics.method_25294(ox + pPx, oy + pPy - 1, ox + pPx + 1, oy + pPy + 2, 0xFF00FFFF);
                    graphics.method_25294(ox + pPx - 2, oy + pPy, ox + pPx - 1, oy + pPy + 1, 0xFFFFFFFF);
                    graphics.method_25294(ox + pPx + 2, oy + pPy, ox + pPx + 3, oy + pPy + 1, 0xFFFFFFFF);
                    graphics.method_25294(ox + pPx, oy + pPy - 2, ox + pPx + 1, oy + pPy - 1, 0xFFFFFFFF);
                    graphics.method_25294(ox + pPx, oy + pPy + 2, ox + pPx + 1, oy + pPy + 3, 0xFFFFFFFF);
                }
            }
        }

        if (entityMode >= 2) {
            // Draw other living entities (small orange dot)
            for (EntityPos ep : cachedEntities) {
                int ePx = halfSize + (int) (ep.x - playerX);
                int ePy = halfSize + (int) (ep.z - playerZ);
                if (ePx >= 0 && ePx < size && ePy >= 0 && ePy < size) {
                    graphics.method_25294(ox + ePx, oy + ePy, ox + ePx + 1, oy + ePy + 1, 0xFFFF8800);
                }
            }
        }

        // Self marker (center green dot with direction arrow)
        int cx = ox + halfSize;
        int cy = oy + halfSize;
        graphics.method_25294(cx - 1, cy - 1, cx + 2, cy + 2, 0xFF00FF00);

        // Direction arrow
        float yawRad = (float) Math.toRadians(player.method_36454());
        int arrowLen = 4;
        int ax = (int) (-Math.sin(yawRad) * arrowLen);
        int ay = (int) (Math.cos(yawRad) * arrowLen);
        drawLine(graphics, cx, cy, cx + ax, cy + ay, 0xFF00FF00);

        // Border
        graphics.method_25294(ox, oy, ox + size, oy + 1, BORDER_COLOR);
        graphics.method_25294(ox, oy + size - 1, ox + size, oy + size, BORDER_COLOR);
        graphics.method_25294(ox, oy, ox + 1, oy + size, BORDER_COLOR);
        graphics.method_25294(ox + size - 1, oy, ox + size, oy + size, BORDER_COLOR);

        // Cardinal labels
        graphics.method_51433(mc.field_1772, "N", cx - 2, oy + 2, 0xFFFFFF, false);
        graphics.method_51433(mc.field_1772, "S", cx - 2, oy + size - 10, 0xFFFFFF, false);
        graphics.method_51433(mc.field_1772, "W", ox + 2, cy - 4, 0xFFFFFF, false);
        graphics.method_51433(mc.field_1772, "E", ox + size - 8, cy - 4, 0xFFFFFF, false);

        // Player coordinates below the minimap
        String coordText = String.format("X: %d  Z: %d", (int) playerX, (int) playerZ);
        int textX = ox + size / 2 - mc.field_1772.method_1727(coordText) / 2;
        int textY = oy + size + 2;
        graphics.method_51433(mc.field_1772, coordText, textX, textY, 0xDDDDDD, false);
    }

    private static void refreshEntityCache(class_310 mc) {
        class_638 level = mc.field_1687;
        class_746 player = mc.field_1724;
        if (level == null || player == null) return;

        int entityMode = MiniMapData.getEntityMode();

        if (entityMode >= 1) {
            List<EntityPos> players = new ArrayList<>();
            for (class_1657 p : level.method_18456()) {
                if (p == player) continue;
                players.add(new EntityPos(p.method_23317(), p.method_23321(), 0xFF00FFFF));
            }
            cachedPlayers = players;
        }

        if (entityMode >= 2) {
            List<EntityPos> entities = new ArrayList<>();
            for (class_1297 entity : level.method_18112()) {
                if (entity instanceof class_1657) continue;
                if (!(entity instanceof class_1309)) continue;
                entities.add(new EntityPos(entity.method_23317(), entity.method_23321(), 0xFFFF8800));
            }
            cachedEntities = entities;
        }
    }

    private static void drawLine(class_332 graphics, int x0, int y0, int x1, int y1, int color) {
        int dx = Math.abs(x1 - x0);
        int dy = Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;
        int err = dx - dy;

        while (true) {
            graphics.method_25294(x0, y0, x0 + 1, y0 + 1, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 < dx) { err += dx; y0 += sy; }
        }
    }
}
