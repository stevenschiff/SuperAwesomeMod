package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_9779;

public final class MiniMapOverlay {

    private MiniMapOverlay() {}

    private static final int BORDER_COLOR = 0xFF333333;

    // Texture-based rendering for performance
    private static class_1043 mapTexture;
    private static class_1011 mapImage;
    private static class_2960 mapTextureId;
    private static int currentTextureSize = 0;

    // Update throttling: only regenerate terrain every N ticks
    private static int tickCounter = 0;
    private static final int UPDATE_INTERVAL = 5; // ~4 times per second
    private static double lastPlayerX = Double.NaN;
    private static double lastPlayerZ = Double.NaN;
    private static boolean needsUpdate = true;

    public static void register() {
        HudRenderCallback.EVENT.register(MiniMapOverlay::onHudRender);
    }

    private static void ensureTexture(int size) {
        if (mapImage != null && currentTextureSize == size) return;

        // Clean up old texture
        if (mapTexture != null) {
            mapTexture.close();
        }
        if (mapTextureId != null) {
            class_310.method_1551().method_1531().method_4615(mapTextureId);
            mapTextureId = null;
        }

        // Create new — use size constructor so getPixels() returns the internal image
        mapTexture = new class_1043(() -> "superawesomemod_minimap_hud", size, size, false);
        mapImage = mapTexture.method_4525();
        mapTextureId = class_2960.method_60655("superawesomemod", "minimap_hud");
        class_310.method_1551().method_1531().method_4616(mapTextureId, mapTexture);
        currentTextureSize = size;
        needsUpdate = true;
    }

    private static void regenerateImage(class_310 mc, int size) {
        class_746 player = mc.field_1724;
        if (player == null) return;

        double playerX = player.method_23317();
        double playerZ = player.method_23321();
        int halfSize = size / 2;

        for (int px = 0; px < size; px++) {
            for (int py = 0; py < size; py++) {
                double worldX = playerX + (px - halfSize);
                double worldZ = playerZ + (py - halfSize);

                int chunkX = (int) Math.floor(worldX) >> 4;
                int chunkZ = (int) Math.floor(worldZ) >> 4;

                int[] colors = MiniMapChunkCache.get(chunkX, chunkZ);
                int color = 0xFF000000; // black = unexplored
                if (colors != null) {
                    int lx = ((int) Math.floor(worldX)) & 15;
                    int lz = ((int) Math.floor(worldZ)) & 15;
                    color = colors[lx * 16 + lz];
                }
                // NativeImage uses ABGR format, convert from ARGB
                mapImage.method_4305(px, py, argbToAbgr(color));
            }
        }

        lastPlayerX = playerX;
        lastPlayerZ = playerZ;
    }

    private static int argbToAbgr(int argb) {
        int a = (argb >> 24) & 0xFF;
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;
        return (a << 24) | (b << 16) | (g << 8) | r;
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter_) {
        if (!MiniMapData.isEnabled()) return;
        if (!MiniMapData.isHudVisible()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (mc.field_1755 instanceof MiniMapFullScreen) return;

        int size = MiniMapData.getMinimapSize();
        ensureTexture(size);

        int guiW = graphics.method_51421();
        int guiH = graphics.method_51443();

        // Calculate origin based on corner setting
        int ox, oy;
        int margin = 4;
        switch (MiniMapData.getCorner()) {
            case 0 -> { ox = margin; oy = margin; }
            case 1 -> { ox = guiW - size - margin; oy = margin; }
            case 2 -> { ox = margin; oy = guiH - size - margin; }
            case 3 -> { ox = guiW - size - margin; oy = guiH - size - margin; }
            default -> { ox = guiW - size - margin; oy = margin; }
        }

        // Check if terrain texture needs regenerating
        tickCounter++;
        double playerX = mc.field_1724.method_23317();
        double playerZ = mc.field_1724.method_23321();
        boolean playerMoved = Double.isNaN(lastPlayerX)
            || Math.abs(playerX - lastPlayerX) > 1
            || Math.abs(playerZ - lastPlayerZ) > 1;

        if (needsUpdate || (tickCounter >= UPDATE_INTERVAL && playerMoved)) {
            regenerateImage(mc, size);
            mapTexture.method_4524();
            tickCounter = 0;
            needsUpdate = false;
        }

        // Render terrain as single texture blit
        graphics.method_70845(mapTextureId, ox, oy, 0, 0, size, size, size, size);

        // Draw waypoint markers (few fill calls, no performance issue)
        class_746 player = mc.field_1724;
        int halfSize = size / 2;

        for (MiniMapWaypoint wp : MiniMapData.getWaypoints()) {
            int wpPx = halfSize + (int) (wp.x() - playerX);
            int wpPy = halfSize + (int) (wp.z() - playerZ);
            if (wpPx >= 0 && wpPx < size && wpPy >= 0 && wpPy < size) {
                int c = wp.color() | 0xFF000000;
                graphics.method_25294(ox + wpPx - 1, oy + wpPy, ox + wpPx + 2, oy + wpPy + 1, c);
                graphics.method_25294(ox + wpPx, oy + wpPy - 1, ox + wpPx + 1, oy + wpPy + 2, c);
            }
        }

        // Draw other players as white dots
        class_638 level = mc.field_1687;
        for (class_1657 p : level.method_18456()) {
            if (p == player) continue;
            int pPx = halfSize + (int) (p.method_23317() - playerX);
            int pPy = halfSize + (int) (p.method_23321() - playerZ);
            if (pPx >= 1 && pPx < size - 1 && pPy >= 1 && pPy < size - 1) {
                graphics.method_25294(ox + pPx - 1, oy + pPy - 1, ox + pPx + 2, oy + pPy + 2, 0xFFFFFFFF);
            }
        }

        // Self marker (center green dot)
        int cx = ox + halfSize;
        int cy = oy + halfSize;
        graphics.method_25294(cx - 1, cy - 1, cx + 2, cy + 2, 0xFF00FF00);

        // Direction arrow
        float yawRad = (float) Math.toRadians(player.method_36454());
        int arrowLen = 4;
        int ax = (int) (-Math.sin(yawRad) * arrowLen);
        int ay = (int) (Math.cos(yawRad) * arrowLen);
        drawLine(graphics, cx, cy, cx + ax, cy + ay, 0xFF00FF00);

        // Border
        graphics.method_25294(ox, oy, ox + size, oy + 1, BORDER_COLOR);
        graphics.method_25294(ox, oy + size - 1, ox + size, oy + size, BORDER_COLOR);
        graphics.method_25294(ox, oy, ox + 1, oy + size, BORDER_COLOR);
        graphics.method_25294(ox + size - 1, oy, ox + size, oy + size, BORDER_COLOR);

        // Cardinal labels
        graphics.method_51433(mc.field_1772, "N", cx - 2, oy + 2, 0xFFFFFF, false);
        graphics.method_51433(mc.field_1772, "S", cx - 2, oy + size - 10, 0xFFFFFF, false);
        graphics.method_51433(mc.field_1772, "W", ox + 2, cy - 4, 0xFFFFFF, false);
        graphics.method_51433(mc.field_1772, "E", ox + size - 8, cy - 4, 0xFFFFFF, false);
    }

    private static void drawLine(class_332 graphics, int x0, int y0, int x1, int y1, int color) {
        int dx = Math.abs(x1 - x0);
        int dy = Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;
        int err = dx - dy;

        while (true) {
            graphics.method_25294(x0, y0, x0 + 1, y0 + 1, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 < dx) { err += dx; y0 += sy; }
        }
    }
}
