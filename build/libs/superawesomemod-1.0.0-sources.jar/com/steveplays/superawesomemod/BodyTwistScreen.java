package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class BodyTwistScreen extends class_437 {

    private final class_437 parent;

    public BodyTwistScreen(class_437 parent) {
        super(class_2561.method_43470("Body Twist"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                BodyTwistData.setEnabled(!BodyTwistData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        this.method_37063(new TwistSlider(cx - btnW / 2, cy - 10, btnW, btnH,
                BodyTwistData.getTwistLimit()));

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(BodyTwistData.isEnabled() ? "Disable Body Twist" : "Enable Body Twist");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);

        boolean on = BodyTwistData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 58, on ? 0x55FF55 : 0xFF5555);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Legs follow movement, torso follows aim"),
            cx, cy + 46, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Applies to every player you see  |  vanilla limit is 50"),
            cx, cy + 58, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Visual only - hitboxes and crosshair are unchanged"),
            cx, cy + 70, 0xFFAA00);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class TwistSlider extends class_357 {
        TwistSlider(int x, int y, int w, int h, int initial) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.method_25346();
        }

        private static double normalize(int v) {
            return (double) (v - BodyTwistData.MIN_LIMIT)
                 / (BodyTwistData.MAX_LIMIT - BodyTwistData.MIN_LIMIT);
        }

        private int denormalize() {
            return (int) Math.round(this.field_22753
                * (BodyTwistData.MAX_LIMIT - BodyTwistData.MIN_LIMIT) + BodyTwistData.MIN_LIMIT);
        }

        @Override
        protected void method_25346() {
            int v = denormalize();
            String suffix = v >= BodyTwistData.MAX_LIMIT ? " (unlimited)"
                          : v <= BodyTwistData.VANILLA_LIMIT ? " (vanilla)" : "";
            this.method_25355(class_2561.method_43470("Twist limit: " + v + suffix));
        }

        @Override
        protected void method_25344() {
            BodyTwistData.setTwistLimit(denormalize());
        }
    }
}
