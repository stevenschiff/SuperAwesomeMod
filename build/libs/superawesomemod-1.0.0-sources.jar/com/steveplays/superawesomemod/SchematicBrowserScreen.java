package com.steveplays.superawesomemod;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Scrollable file browser listing {@code .litematic} files.
 * Follows the same pattern as {@link XrayScreen}.
 */
public class SchematicBrowserScreen extends class_437 {

    private final class_437 parent;
    private class_342 searchBox;
    private String searchText = "";
    private int scrollOffset = 0;
    private List<Path> filteredFiles = new ArrayList<>();
    private List<Path> allFiles = new ArrayList<>();

    private static final int BTN_W = 200;
    private static final int BTN_H = 20;
    private static final int ROW_HEIGHT = 24;
    private static final int VISIBLE_ROWS = 6;

    public SchematicBrowserScreen(class_437 parent) {
        super(class_2561.method_43470("Browse Schematics"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 90;

        // Scan for files
        scanFiles();

        // Search box
        searchBox = new class_342(this.field_22793, cx - BTN_W / 2, topY, BTN_W, BTN_H,
            class_2561.method_43470("Search"));
        searchBox.method_47404(class_2561.method_43470("Search schematics..."));
        searchBox.method_1852(searchText);
        searchBox.method_1863(text -> {
            searchText = text;
            scrollOffset = 0;
            rebuildFileList();
            this.method_41843();
        });
        this.method_37063(searchBox);

        // Filter based on search
        rebuildFileList();

        // File buttons (scrollable)
        int listStartY = topY + 28;
        int end = Math.min(scrollOffset + VISIBLE_ROWS, filteredFiles.size());
        for (int i = scrollOffset; i < end; i++) {
            Path file = filteredFiles.get(i);
            String fileName = file.getFileName().toString();
            String displayName = fileName.length() > 30
                ? fileName.substring(0, 27) + "..."
                : fileName;
            int rowY = listStartY + (i - scrollOffset) * ROW_HEIGHT;

            this.method_37063(class_4185.method_46430(
                class_2561.method_43470(displayName),
                btn -> loadSchematic(file)
            ).method_46434(cx - BTN_W / 2, rowY, BTN_W, BTN_H).method_46431());
        }

        // Back button
        int backY = listStartY + VISIBLE_ROWS * ROW_HEIGHT + 8;
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, backY, 100, BTN_H).method_46431());
    }

    private void scanFiles() {
        allFiles.clear();
        Path dir = getSchematicsDir();
        if (!Files.exists(dir)) {
            try {
                Files.createDirectories(dir);
            } catch (IOException e) {
                SuperAwesomeMod.LOGGER.warn("[Schematic] Failed to create schematics directory", e);
                return;
            }
        }

        try (Stream<Path> stream = Files.list(dir)) {
            stream.filter(p -> p.toString().endsWith(".litematic"))
                  .sorted()
                  .forEach(allFiles::add);
        } catch (IOException e) {
            SuperAwesomeMod.LOGGER.warn("[Schematic] Failed to list schematics", e);
        }
    }

    private void rebuildFileList() {
        String query = searchText.toLowerCase().trim();
        filteredFiles.clear();
        for (Path file : allFiles) {
            String name = file.getFileName().toString().toLowerCase();
            if (query.isEmpty() || name.contains(query)) {
                filteredFiles.add(file);
            }
        }
    }

    private void loadSchematic(Path file) {
        try {
            Schematic schematic = SchematicFormat.load(file);
            class_310 mc = class_310.method_1551();
            class_2338 origin = mc.field_1724 != null
                ? mc.field_1724.method_24515()
                : class_2338.field_10980;
            SchematicData.setCurrentPlacement(new SchematicPlacement(schematic, origin));
            SchematicData.setEnabled(true);
            SchematicData.setCurrentLayer(0);
            SchematicVerifier.clearCache();
            SuperAwesomeMod.LOGGER.info("[Schematic] Loaded '{}' ({} blocks)",
                schematic.getName(), schematic.getTotalBlocks());
            this.field_22787.method_1507(this.parent);
        } catch (IOException e) {
            SuperAwesomeMod.LOGGER.error("[Schematic] Failed to load: {}", file, e);
        }
    }

    private static Path getSchematicsDir() {
        return class_310.method_1551().field_1697.toPath()
            .resolve("superawesomemod")
            .resolve("schematics");
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY,
                                  double scrollX, double scrollY) {
        int maxOffset = Math.max(0, filteredFiles.size() - VISIBLE_ROWS);
        scrollOffset = Math.clamp((long) (scrollOffset - (int) scrollY), 0, maxOffset);
        this.method_41843();
        return true;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 90;

        graphics.method_27534(this.field_22793, this.field_22785, cx, topY - 20, 0xFFFFFF);

        String dirHint = "Place .litematic files in /superawesomemod/schematics/";
        graphics.method_27534(this.field_22793, class_2561.method_43470(dirHint), cx, topY - 8, 0xAAAAAA);

        // Scroll indicator
        if (filteredFiles.size() > VISIBLE_ROWS) {
            int listStartY = topY + 28;
            String scrollText = (scrollOffset + 1) + "-"
                + Math.min(scrollOffset + VISIBLE_ROWS, filteredFiles.size())
                + " of " + filteredFiles.size();
            graphics.method_27534(this.field_22793,
                class_2561.method_43470(scrollText),
                cx, listStartY + VISIBLE_ROWS * ROW_HEIGHT - 6, 0x888888);
        }

        if (filteredFiles.isEmpty()) {
            int listStartY = topY + 28;
            graphics.method_27534(this.field_22793,
                class_2561.method_43470("No schematics found"),
                cx, listStartY + 40, 0xFF5555);
        }

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
