package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class RenderDistanceScreen extends class_437 {

    private final class_437 parent;

    public RenderDistanceScreen(class_437 parent) {
        super(class_2561.method_43470("Render Distance"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        // Toggle on/off
        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                RenderDistanceData.setEnabled(!RenderDistanceData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        // Distance slider 32..128
        this.method_37063(new DistanceSlider(
            cx - btnW / 2, cy - 14, btnW, btnH,
            RenderDistanceData.getDistance()
        ));

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 16, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(RenderDistanceData.isEnabled()
            ? "Render Distance: Enabled"
            : "Render Distance: Disabled");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 68, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Extends chunk render distance (32-128 chunks)"),
            cx, cy - 56, 0xAAAAAA);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class DistanceSlider extends class_357 {
        DistanceSlider(int x, int y, int w, int h, int initialDistance) {
            super(x, y, w, h, class_2561.method_43473(),
                normalize(initialDistance));
            this.method_25346();
        }

        private static double normalize(int distance) {
            return (double) (distance - RenderDistanceData.MIN_DISTANCE)
                 / (double) (RenderDistanceData.MAX_DISTANCE - RenderDistanceData.MIN_DISTANCE);
        }

        @Override
        protected void method_25346() {
            int dist = (int) Math.round(this.field_22753
                * (RenderDistanceData.MAX_DISTANCE - RenderDistanceData.MIN_DISTANCE)
                + RenderDistanceData.MIN_DISTANCE);
            this.method_25355(class_2561.method_43470("Distance: " + dist + " chunks"));
        }

        @Override
        protected void method_25344() {
            int dist = (int) Math.round(this.field_22753
                * (RenderDistanceData.MAX_DISTANCE - RenderDistanceData.MIN_DISTANCE)
                + RenderDistanceData.MIN_DISTANCE);
            RenderDistanceData.setDistance(dist);
        }
    }
}
