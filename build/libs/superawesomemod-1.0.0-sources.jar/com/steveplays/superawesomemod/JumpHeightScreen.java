package com.steveplays.superawesomemod;

import com.steveplays.superawesomemod.network.JumpHeightPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class JumpHeightScreen extends class_437 {

    private final class_437 parent;
    private class_342 valueField;
    private class_2561 errorMessage = class_2561.method_43473();

    public JumpHeightScreen(class_437 parent) {
        super(class_2561.method_43470("Jump Height"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        // Pre-fill with the player's current multiplier
        class_310 mc = class_310.method_1551();
        float current = (mc.field_1724 != null)
            ? PlayerJumpData.getMultiplier(mc.field_1724.method_5667())
            : PlayerJumpData.DEFAULT;

        this.valueField = new class_342(this.field_22793,
            cx - 50, cy - 10, 100, 20,
            class_2561.method_43470("Multiplier"));
        this.valueField.method_1852(String.valueOf(current));
        this.valueField.method_1863(value -> this.errorMessage = class_2561.method_43473());
        this.method_37063(this.valueField);

        // Apply
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Apply"),
            btn -> this.apply()
        ).method_46434(cx - 102, cy + 16, 98, 20).method_46431());

        // Reset to 1.0
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Reset (1.0)"),
            btn -> {
                this.sendJumpPacket(1.0f);
                this.field_22787.method_1507(this.parent);
            }
        ).method_46434(cx + 4, cy + 16, 98, 20).method_46431());

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 42, 100, 20).method_46431());
    }

    private void apply() {
        String raw = this.valueField.method_1882().trim();
        try {
            float value = Float.parseFloat(raw);
            if (value < PlayerJumpData.MIN || value > PlayerJumpData.MAX) {
                this.errorMessage = class_2561.method_43470(
                    "Value must be " + PlayerJumpData.MIN + " – " + PlayerJumpData.MAX);
                return;
            }
            this.sendJumpPacket(value);
            this.field_22787.method_1507(this.parent);
        } catch (NumberFormatException e) {
            this.errorMessage = class_2561.method_43470("Enter a valid number");
        }
    }

    private void sendJumpPacket(float value) {
        // Apply immediately on the client so JumpMixin sees it on the very next jump,
        // without waiting for a server round-trip. This also works when cheats are off.
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            PlayerJumpData.setMultiplier(mc.field_1724.method_5667(), value);
        }
        // Also tell the server so server-side physics (and multiplayer) stay in sync.
        ClientPlayNetworking.send(new JumpHeightPayload(value));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 60, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Multiplier  (" + PlayerJumpData.MIN + " – " + PlayerJumpData.MAX + ")"),
            cx, cy - 25, 0xAAAAAA);

        // Error message in red
        if (!this.errorMessage.getString().isEmpty()) {
            graphics.method_27534(this.field_22793, this.errorMessage, cx, cy + 70, 0xFF5555);
        }

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
