package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class AutoEatScreen extends class_437 {

    private final class_437 parent;

    public AutoEatScreen(class_437 parent) {
        super(class_2561.method_43470("Auto Eat"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                AutoEatData.setEnabled(!AutoEatData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        this.method_37063(new ThresholdSlider(cx - btnW / 2, cy - 10, btnW, btnH,
                AutoEatData.getThreshold()));

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(AutoEatData.isEnabled() ? "Disable Auto Eat" : "Enable Auto Eat");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);

        boolean on = AutoEatData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 58, on ? 0x55FF55 : 0xFF5555);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Eats your best hotbar food, then restores your slot"),
            cx, cy + 46, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Waits if you're already using an item  |  any server"),
            cx, cy + 58, 0xAAAAAA);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class ThresholdSlider extends class_357 {
        ThresholdSlider(int x, int y, int w, int h, int initial) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.method_25346();
        }

        private static double normalize(int v) {
            return (double) (v - AutoEatData.MIN_THRESHOLD)
                 / (AutoEatData.MAX_THRESHOLD - AutoEatData.MIN_THRESHOLD);
        }

        private int denormalize() {
            return (int) Math.round(this.field_22753
                * (AutoEatData.MAX_THRESHOLD - AutoEatData.MIN_THRESHOLD) + AutoEatData.MIN_THRESHOLD);
        }

        @Override
        protected void method_25346() {
            int t = denormalize();
            this.method_25355(class_2561.method_43470(
                "Eat at or below: " + t + " (" + String.format("%.1f", t / 2.0) + " drumsticks)"));
        }

        @Override
        protected void method_25344() {
            AutoEatData.setThreshold(denormalize());
        }
    }
}
