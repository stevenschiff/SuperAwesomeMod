package com.steveplays.superawesomemod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_5498;

public class SuperAwesomeModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        SuperAwesomeMod.LOGGER.info("[SuperAwesomeMod] Client initialized!");

        ModKeybindings.register();
        ArmorHudOverlay.register();

        final class_5498[] lastCameraType = { class_5498.field_26664 };

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Open menu on keybind press.
            while (ModKeybindings.openMenu.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new ModMenuScreen());
                }
            }

            // Maintain mod flight client-side every tick.
            if (client.field_1724 != null && PlayerFlyData.isEnabled(client.field_1724.method_5667())) {
                client.field_1724.method_31549().field_7478 = true;
            }

            // Free look: active only when enabled AND in third-person.
            // Reset offsets whenever the player switches perspective (F5).
            class_5498 currentCamera = client.field_1690.method_31044();
            if (currentCamera != lastCameraType[0]) {
                lastCameraType[0] = currentCamera;
                FreeLookData.reset();
            }
            boolean thirdPerson = currentCamera != class_5498.field_26664;
            FreeLookData.setActive(FreeLookData.isEnabled() && thirdPerson);
        });
    }
}
