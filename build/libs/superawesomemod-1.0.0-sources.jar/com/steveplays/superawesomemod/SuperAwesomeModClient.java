package com.steveplays.superawesomemod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class SuperAwesomeModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        SuperAwesomeMod.LOGGER.info("[SuperAwesomeMod] Client initialized!");

        ModKeybindings.register();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Open menu on keybind press.
            while (ModKeybindings.openMenu.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new ModMenuScreen());
                }
            }

            // Maintain mod flight client-side every tick.
            // The vanilla server sends mayfly=false once at join for survival
            // players. Re-setting mayfly=true here overrides that every tick so
            // the client always permits flight — regardless of whether the server
            // has the mod installed.
            if (client.field_1724 != null && PlayerFlyData.isEnabled(client.field_1724.method_5667())) {
                client.field_1724.method_31549().field_7478 = true;
            }
        });
    }
}
