package com.steveplays.superawesomemod;

import com.steveplays.superawesomemod.mixin.MinecraftAutoclickerInvoker;
import com.steveplays.superawesomemod.mixin.OptionInstanceAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3489;
import net.minecraft.class_5498;

public class SuperAwesomeModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        SuperAwesomeMod.LOGGER.info("[SuperAwesomeMod] Client initialized!");

        ModKeybindings.register();
        ArmorHudOverlay.register();
        CombatHitboxRenderer.register();
        CombatCrosshairOverlay.register();
        CombatPotionEffectsOverlay.register();
        PvpDetectorOverlay.register();
        AppleSkinOverlay.register();
        LODTerrainRenderer.register();
        XrayRenderer.register();
        XrayLineRenderType.touch();
        MiniMapOverlay.register();
        MiniMapChunkScanner.register();
        MiniMapWaypointRenderer.register();

        // Mini Map: world join/leave persistence hooks
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            MiniMapPersistence.onWorldJoin(class_310.method_1551());
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            MiniMapPersistence.onWorldLeave();
        });

        final class_5498[] lastCameraType = { class_5498.field_26664 };

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Open menu on keybind press.
            while (ModKeybindings.openMenu.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new ModMenuScreen());
                }
            }

            // Mini Map: C key toggles full-screen map
            while (ModKeybindings.miniMapToggle.method_1436()) {
                if (MiniMapData.isEnabled() && client.field_1755 == null) {
                    client.method_1507(new MiniMapFullScreen());
                } else if (client.field_1755 instanceof MiniMapFullScreen) {
                    client.method_1507(null);
                }
            }

            // Mini Map persistence auto-save tick
            if (MiniMapData.isEnabled()) {
                MiniMapPersistence.tick();
            }

            // Zoom: hold-to-zoom. Drain queued click events so they don't pile up,
            // then sample the live held state — only active in-game (no screen open).
            while (ModKeybindings.zoom.method_1436()) { /* drain */ }
            ZoomData.setKeyHeld(client.field_1755 == null && ModKeybindings.zoom.method_1434());
            ZoomData.tick();

            // Maintain mod flight client-side every tick.
            if (client.field_1724 != null && PlayerFlyData.isEnabled(client.field_1724.method_5667())) {
                client.field_1724.method_31549().field_7478 = true;
            }

            // Free look: active only when enabled AND in third-person.
            // Reset offsets whenever the player switches perspective (F5).
            class_5498 currentCamera = client.field_1690.method_31044();
            if (currentCamera != lastCameraType[0]) {
                lastCameraType[0] = currentCamera;
                FreeLookData.reset();
            }
            boolean thirdPerson = currentCamera != class_5498.field_26664;
            FreeLookData.setActive(FreeLookData.isEnabled() && thirdPerson);

            // Freecam movement: WASD/Space/Shift translates the freecam position.
            // Snapshot prev BEFORE applying input so the camera mixin can lerp from
            // last tick's position across the frames between ticks.
            if (FreecamData.isEnabled() && client.field_1755 == null && client.field_1724 != null) {
                FreecamData.beginTick();
                class_315 o = client.field_1690;
                float forward = (o.field_1894.method_1434()    ? 1f : 0f) - (o.field_1881.method_1434()  ? 1f : 0f);
                float strafeR = (o.field_1849.method_1434() ? 1f : 0f) - (o.field_1913.method_1434()  ? 1f : 0f);
                float vert    = (o.field_1903.method_1434()  ? 1f : 0f) - (o.field_1832.method_1434() ? 1f : 0f);
                float yawRad = (float) Math.toRadians(FreecamData.getYaw());
                double sinY = Math.sin(yawRad);
                double cosY = Math.cos(yawRad);
                double dx = -forward * sinY - strafeR * cosY;
                double dz =  forward * cosY - strafeR * sinY;
                double horiz = Math.sqrt(dx * dx + dz * dz);
                if (horiz > 1.0) { dx /= horiz; dz /= horiz; }
                float speed = FreecamData.getSpeed();
                FreecamData.smoothMove(dx * speed, vert * speed, dz * speed);
            }

            // Render distance override: force the client's render distance value
            // beyond vanilla limits using the accessor mixin.
            if (RenderDistanceData.isEnabled() && client.field_1724 != null) {
                int dist = RenderDistanceData.getDistance();
                boolean singleplayer = client.method_1576() != null;
                int current = client.field_1690.method_42503().method_41753();
                if (current != dist) {
                    @SuppressWarnings("unchecked")
                    OptionInstanceAccessor<Integer> accessor =
                        (OptionInstanceAccessor<Integer>)(Object) client.field_1690.method_42503();
                    accessor.superawesomemod$setValue(dist);
                    // Trigger chunk rebuild so the renderer uses the new distance.
                    client.field_1769.method_3279();
                    // Update integrated server view distance in singleplayer.
                    if (singleplayer) {
                        client.method_1576().method_3760().method_14608(dist);
                    }
                }

                // LOD terrain: update player position for the generator.
                int pcx = (int) Math.floor(client.field_1724.method_23317()) >> 4;
                int pcz = (int) Math.floor(client.field_1724.method_23321()) >> 4;
                LODChunkData.setPlayerPos(pcx, pcz);
                LODChunkData.setLodRadius(dist);

                // In singleplayer the server sends real chunks at the full
                // distance, so skip LOD rendering everywhere. In multiplayer
                // skip only the server's actual view distance (real chunks).
                if (singleplayer) {
                    LODChunkData.setSkipRadius(dist);
                } else {
                    LODChunkData.setSkipRadius(12);
                }

                // Auto-detect seed in singleplayer.
                if (!RenderDistanceData.isSeedSet() && singleplayer) {
                    long seed = client.method_1576().method_30002().method_8412();
                    RenderDistanceData.setSeed(seed);
                }

                // In multiplayer, start LOD generator if seed is available.
                // In singleplayer, LOD is not needed (real chunks cover full
                // distance) so don't start the generator.
                if (!singleplayer && RenderDistanceData.isSeedSet()
                        && !LODHeightmapGenerator.isRunning()
                        && client.field_1687 != null) {
                    LODHeightmapGenerator.start(
                        RenderDistanceData.getSeed(),
                        client.field_1687.method_30349()
                    );
                }
            } else if (!RenderDistanceData.isEnabled() && LODHeightmapGenerator.isRunning()) {
                LODHeightmapGenerator.stop();
            }

            // 1.7 sword blocking: track whether the player is holding a sword
            // with the use key held (custom blocking state for animation).
            if (client.field_1724 != null && OldPvpData.isBlockingEnabled()) {
                boolean holdsSword = client.field_1724.method_6047().method_31573(class_3489.field_42611);
                boolean useKeyHeld = client.field_1690.field_1904.method_1434();
                boolean notActuallyUsing = !client.field_1724.method_6115();
                OldPvpData.setCustomBlocking(holdsSword && useKeyHeld && notActuallyUsing);
            } else {
                OldPvpData.setCustomBlocking(false);
            }

            // Autoclicker: fire as many simulated clicks as elapsed wall-clock allows.
            if (AutoclickerData.isEnabled() && client.field_1755 == null
                && client.field_1724 != null && client.field_1687 != null) {
                int n = AutoclickerData.clicksToFire(System.nanoTime());
                if (n > 0) {
                    MinecraftAutoclickerInvoker inv = (MinecraftAutoclickerInvoker)(Object) client;
                    if (AutoclickerData.getButton() == AutoclickerData.Button.LEFT) {
                        for (int i = 0; i < n; i++) inv.superawesomemod$startAttack();
                    } else {
                        for (int i = 0; i < n; i++) inv.superawesomemod$startUseItem();
                    }
                }
            }
        });
    }
}
