package com.steveplays.superawesomemod;

import com.steveplays.superawesomemod.FreeLookData;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_5498;

public class SuperAwesomeModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        SuperAwesomeMod.LOGGER.info("[SuperAwesomeMod] Client initialized!");

        ModKeybindings.register();

        // Track perspective so we can reset free look when the player switches views.
        final class_5498[] lastCameraType = { class_5498.field_26664 };

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Open menu on keybind press.
            while (ModKeybindings.openMenu.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new ModMenuScreen());
                }
            }

            // Maintain mod flight client-side every tick.
            // The vanilla server sends mayfly=false once at join for survival
            // players. Re-setting mayfly=true here overrides that every tick so
            // the client always permits flight — regardless of whether the server
            // has the mod installed.
            if (client.field_1724 != null && PlayerFlyData.isEnabled(client.field_1724.method_5667())) {
                client.field_1724.method_31549().field_7478 = true;
            }

            // Reset free look when the player switches camera perspective (F5).
            class_5498 currentCameraType = client.field_1690.method_31044();
            if (currentCameraType != lastCameraType[0]) {
                lastCameraType[0] = currentCameraType;
                FreeLookData.setActive(false);
                FreeLookData.reset();
            }

            // Free look: hold mode vs toggle mode.
            if (FreeLookData.isToggleMode()) {
                while (ModKeybindings.freeLook.method_1436()) {
                    boolean nowActive = !FreeLookData.isActive();
                    FreeLookData.setActive(nowActive);
                    if (!nowActive) FreeLookData.reset();
                }
            } else {
                boolean held = ModKeybindings.freeLook.method_1434();
                FreeLookData.setActive(held);
                if (!held) FreeLookData.reset();
            }
        });
    }
}
