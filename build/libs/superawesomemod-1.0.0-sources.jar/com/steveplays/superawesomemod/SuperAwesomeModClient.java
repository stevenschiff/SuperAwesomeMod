package com.steveplays.superawesomemod;

import com.steveplays.superawesomemod.mixin.MinecraftAutoclickerInvoker;
import com.steveplays.superawesomemod.mixin.OptionInstanceAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_315;
import net.minecraft.class_5498;

public class SuperAwesomeModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        SuperAwesomeMod.LOGGER.info("[SuperAwesomeMod] Client initialized!");

        ModKeybindings.register();
        ArmorHudOverlay.register();
        CombatHitboxRenderer.register();
        CombatCrosshairOverlay.register();
        CombatPotionEffectsOverlay.register();
        PvpDetectorOverlay.register();
        AppleSkinOverlay.register();
        XrayLineRenderType.touch();

        final class_5498[] lastCameraType = { class_5498.field_26664 };

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Open menu on keybind press.
            while (ModKeybindings.openMenu.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new ModMenuScreen());
                }
            }

            // Zoom: hold-to-zoom. Drain queued click events so they don't pile up,
            // then sample the live held state — only active in-game (no screen open).
            while (ModKeybindings.zoom.method_1436()) { /* drain */ }
            ZoomData.setKeyHeld(client.field_1755 == null && ModKeybindings.zoom.method_1434());
            ZoomData.tick();

            // Maintain mod flight client-side every tick.
            if (client.field_1724 != null && PlayerFlyData.isEnabled(client.field_1724.method_5667())) {
                client.field_1724.method_31549().field_7478 = true;
            }

            // Free look: active only when enabled AND in third-person.
            // Reset offsets whenever the player switches perspective (F5).
            class_5498 currentCamera = client.field_1690.method_31044();
            if (currentCamera != lastCameraType[0]) {
                lastCameraType[0] = currentCamera;
                FreeLookData.reset();
            }
            boolean thirdPerson = currentCamera != class_5498.field_26664;
            FreeLookData.setActive(FreeLookData.isEnabled() && thirdPerson);

            // Freecam movement: WASD/Space/Shift translates the freecam position.
            // Snapshot prev BEFORE applying input so the camera mixin can lerp from
            // last tick's position across the frames between ticks.
            if (FreecamData.isEnabled() && client.field_1755 == null && client.field_1724 != null) {
                FreecamData.beginTick();
                class_315 o = client.field_1690;
                float forward = (o.field_1894.method_1434()    ? 1f : 0f) - (o.field_1881.method_1434()  ? 1f : 0f);
                float strafeR = (o.field_1849.method_1434() ? 1f : 0f) - (o.field_1913.method_1434()  ? 1f : 0f);
                float vert    = (o.field_1903.method_1434()  ? 1f : 0f) - (o.field_1832.method_1434() ? 1f : 0f);
                float yawRad = (float) Math.toRadians(FreecamData.getYaw());
                double sinY = Math.sin(yawRad);
                double cosY = Math.cos(yawRad);
                double dx = -forward * sinY - strafeR * cosY;
                double dz =  forward * cosY - strafeR * sinY;
                double horiz = Math.sqrt(dx * dx + dz * dz);
                if (horiz > 1.0) { dx /= horiz; dz /= horiz; }
                float speed = FreecamData.getSpeed();
                FreecamData.smoothMove(dx * speed, vert * speed, dz * speed);
            }

            // Render distance override: force the client's render distance value
            // beyond vanilla limits using the accessor mixin.
            if (RenderDistanceData.isEnabled() && client.field_1724 != null) {
                int dist = RenderDistanceData.getDistance();
                @SuppressWarnings("unchecked")
                OptionInstanceAccessor<Integer> accessor =
                    (OptionInstanceAccessor<Integer>)(Object) client.field_1690.method_42503();
                accessor.superawesomemod$setValue(dist);
            }

            // Autoclicker: fire as many simulated clicks as elapsed wall-clock allows.
            if (AutoclickerData.isEnabled() && client.field_1755 == null
                && client.field_1724 != null && client.field_1687 != null) {
                int n = AutoclickerData.clicksToFire(System.nanoTime());
                if (n > 0) {
                    MinecraftAutoclickerInvoker inv = (MinecraftAutoclickerInvoker)(Object) client;
                    if (AutoclickerData.getButton() == AutoclickerData.Button.LEFT) {
                        for (int i = 0; i < n; i++) inv.superawesomemod$startAttack();
                    } else {
                        for (int i = 0; i < n; i++) inv.superawesomemod$startUseItem();
                    }
                }
            }
        });
    }
}
