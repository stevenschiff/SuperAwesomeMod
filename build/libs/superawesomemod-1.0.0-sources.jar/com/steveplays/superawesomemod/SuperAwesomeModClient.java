package com.steveplays.superawesomemod;

import com.steveplays.superawesomemod.mixin.OptionInstanceAccessor;
import com.steveplays.superawesomemod.mixin.ConnectionAccessor;
import io.netty.channel.Channel;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.class_2535;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_5498;

public class SuperAwesomeModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        SuperAwesomeMod.LOGGER.info("[SuperAwesomeMod] Client initialized!");

        ModKeybindings.register();
        ArmorHudOverlay.register();
        CombatHitboxRenderer.register();
        CombatCrosshairOverlay.register();
        CombatPotionEffectsOverlay.register();
        PvpDetectorOverlay.register();
        AppleSkinOverlay.register();
        LODTerrainRenderer.register();
        WaypointLineRenderType.touch();
        MiniMapOverlay.register();
        MiniMapChunkScanner.register();
        MotionBlurRenderer.register();
        MiniMapWaypointRenderer.register();
        NametagRenderer.register();
        CpsOverlay.register();
        KeystrokesOverlay.register();
        // SchematicRenderer.register();
        // SchematicRenderType.touch();
        // SchematicOverlay.register();

        // Mini Map: world join/leave persistence hooks
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            MiniMapPersistence.onWorldJoin(class_310.method_1551());

            // Inject Min Ping handler into the Netty pipeline.
            class_2535 connection = handler.method_48296();
            Channel channel = ((ConnectionAccessor) connection).getChannel();
            if (channel != null && channel.pipeline().get("superawesomemod_min_ping") == null) {
                channel.pipeline().addBefore("packet_handler", "superawesomemod_min_ping",
                    new MinPingHandler());
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            MiniMapPersistence.onWorldLeave();
        });

        final class_5498[] lastCameraType = { class_5498.field_26664 };

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Open menu on keybind press.
            while (ModKeybindings.openMenu.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new ModMenuScreen());
                }
            }

            // Mini Map: C key toggles full-screen map
            while (ModKeybindings.miniMapToggle.method_1436()) {
                if (MiniMapData.isEnabled() && client.field_1755 == null) {
                    client.method_1507(new MiniMapFullScreen());
                } else if (client.field_1755 instanceof MiniMapFullScreen) {
                    client.method_1507(null);
                }
            }

            // Mini Map persistence auto-save tick
            if (MiniMapData.isEnabled()) {
                MiniMapPersistence.tick();
            }

            // Auto Miner: mark and start/stop keys are inert unless the feature is on.
            while (ModKeybindings.autoMineMark.method_1436()) {
                if (AutoMineData.isEnabled()) markLookedAtBlock(client);
            }
            while (ModKeybindings.autoMineToggle.method_1436()) {
                if (AutoMineData.isEnabled()) {
                    if (AutoMineData.isRunning()) AutoMineData.stop("Stopped by key");
                    else AutoMineData.start();
                }
            }
            AutoMineHandler.tick(client);
            AutoFishHandler.tick(client);


            // Track current dimension for waypoint filtering
            if (client.field_1687 != null) {
                net.minecraft.class_5321<net.minecraft.class_1937> dim = client.field_1687.method_27983();
                if (dim == net.minecraft.class_1937.field_25179) {
                    MiniMapData.setCurrentDimension("overworld");
                } else if (dim == net.minecraft.class_1937.field_25180) {
                    MiniMapData.setCurrentDimension("the_nether");
                } else if (dim == net.minecraft.class_1937.field_25181) {
                    MiniMapData.setCurrentDimension("the_end");
                } else {
                    MiniMapData.setCurrentDimension(dim.toString());
                }
            }

            // Zoom: hold-to-zoom. Drain queued click events so they don't pile up,
            // then sample the live held state — only active in-game (no screen open).
            while (ModKeybindings.zoom.method_1436()) { /* drain */ }
            ZoomData.setKeyHeld(client.field_1755 == null && ModKeybindings.zoom.method_1434());
            ZoomData.tick();

            // Free look: active only when enabled AND in third-person.
            // Reset offsets whenever the player switches perspective (F5).
            class_5498 currentCamera = client.field_1690.method_31044();
            if (currentCamera != lastCameraType[0]) {
                lastCameraType[0] = currentCamera;
                FreeLookData.reset();
            }
            boolean thirdPerson = currentCamera != class_5498.field_26664;
            FreeLookData.setActive(FreeLookData.isEnabled() && thirdPerson);


            // Render distance override: force the client's render distance value
            // beyond vanilla limits using the accessor mixin.
            if (RenderDistanceData.isEnabled() && client.field_1724 != null) {
                int dist = RenderDistanceData.getDistance();
                boolean singleplayer = client.method_1576() != null;
                int current = client.field_1690.method_42503().method_41753();
                if (current != dist) {
                    @SuppressWarnings("unchecked")
                    OptionInstanceAccessor<Integer> accessor =
                        (OptionInstanceAccessor<Integer>)(Object) client.field_1690.method_42503();
                    accessor.superawesomemod$setValue(dist);
                    // Trigger chunk rebuild so the renderer uses the new distance.
                    client.field_1769.method_3279();
                    // Update integrated server view distance in singleplayer.
                    if (singleplayer) {
                        client.method_1576().method_3760().method_14608(dist);
                    }
                }

                // LOD terrain: update player position for the generator.
                int pcx = (int) Math.floor(client.field_1724.method_23317()) >> 4;
                int pcz = (int) Math.floor(client.field_1724.method_23321()) >> 4;
                LODChunkData.setPlayerPos(pcx, pcz);
                LODChunkData.setLodRadius(dist);

                // In singleplayer the server sends real chunks at the full
                // distance, so skip LOD rendering everywhere. In multiplayer
                // skip only the server's actual view distance (real chunks).
                if (singleplayer) {
                    LODChunkData.setSkipRadius(dist);
                } else {
                    LODChunkData.setSkipRadius(12);
                }

                // Auto-detect seed in singleplayer.
                if (!RenderDistanceData.isSeedSet() && singleplayer) {
                    long seed = client.method_1576().method_30002().method_8412();
                    RenderDistanceData.setSeed(seed);
                }

                // In multiplayer, start LOD generator if seed is available.
                // In singleplayer, LOD is not needed (real chunks cover full
                // distance) so don't start the generator.
                if (!singleplayer && RenderDistanceData.isSeedSet()
                        && !LODHeightmapGenerator.isRunning()
                        && client.field_1687 != null) {
                    LODHeightmapGenerator.start(
                        RenderDistanceData.getSeed(),
                        client.field_1687.method_30349()
                    );
                }
            } else if (!RenderDistanceData.isEnabled() && LODHeightmapGenerator.isRunning()) {
                LODHeightmapGenerator.stop();
            }

            // 1.7 sword blocking: track whether the player is holding a sword
            // with the use key held (custom blocking state for animation).
            if (client.field_1724 != null && OldPvpData.isBlockingEnabled()) {
                boolean holdsSword = client.field_1724.method_6047().method_31573(class_3489.field_42611);
                boolean useKeyHeld = client.field_1690.field_1904.method_1434();
                boolean notActuallyUsing = !client.field_1724.method_6115();
                OldPvpData.setCustomBlocking(holdsSword && useKeyHeld && notActuallyUsing);
            } else {
                OldPvpData.setCustomBlocking(false);
            }

            // // Schematic: layer up/down keybinds (commented out — fix later)
            // while (ModKeybindings.schematicLayerUp.consumeClick()) {
            //     if (SchematicData.isEnabled() && SchematicData.isLayerMode()) {
            //         SchematicData.setCurrentLayer(
            //             Math.min(SchematicData.getCurrentLayer() + 1, SchematicData.getMaxLayer()));
            //         SchematicVerifier.clearCache();
            //     }
            // }
            // while (ModKeybindings.schematicLayerDown.consumeClick()) {
            //     if (SchematicData.isEnabled() && SchematicData.isLayerMode()) {
            //         SchematicData.setCurrentLayer(
            //             Math.max(0, SchematicData.getCurrentLayer() - 1));
            //         SchematicVerifier.clearCache();
            //     }
            // }
            // while (ModKeybindings.schematicToggle.consumeClick()) {
            //     SchematicData.setEnabled(!SchematicData.isEnabled());
            // }
            //
            // // Schematic: verifier tick
            // if (SchematicData.isEnabled() && SchematicData.getRenderMode() == 1) {
            //     SchematicVerifier.tick(client.level, SchematicData.getCurrentPlacement());
            // }

        });
    }

    /** Marks the block type under the crosshair, so the miner knows what to hunt. */
    private static void markLookedAtBlock(net.minecraft.class_310 client) {
        if (client.field_1765 instanceof net.minecraft.class_3965 hit
            && client.field_1687 != null) {
            var block = client.field_1687.method_8320(hit.method_17777()).method_26204();
            AutoMineData.setTarget(block);
            AutoMineData.setStatus("Marked " + block.method_9518().getString());
            if (client.field_1724 != null) {
                client.field_1724.method_7353(
                    net.minecraft.class_2561.method_43470(
                        "Marked: " + block.method_9518().getString()), true);
            }
        }
    }
}
