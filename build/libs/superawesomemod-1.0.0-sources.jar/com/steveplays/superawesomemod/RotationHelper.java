package com.steveplays.superawesomemod;

import java.util.Random;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_746;

/**
 * Turns the player toward a point the way a hand would, not the way a script would.
 *
 * <p>Snapping yaw straight to the target is the single clearest tell that nobody is
 * holding the mouse, so the turn is eased: a fraction of what is left is covered each
 * step, capped at a maximum rate, which gives a fast start and a soft finish.
 *
 * <p>The path to the target is a straight one. Random noise on the angles was tried and
 * removed: re-rolled per step it reads as a shaking hand rather than a steady one, and a
 * smooth arc is both nicer to watch and more accurate. The only randomness left is the
 * aim point inside the block, which is chosen once per block and then held, so the turn
 * toward it is still direct.
 *
 * <p>The easing runs <b>once per rendered frame</b>, not once per tick. A tick is 50 ms,
 * so tick-rate easing moves the camera in 20 visible jumps a second however high the
 * frame rate is. {@link #renderStep} is driven from the renderer and scales each step by
 * real elapsed time, so the same turn takes the same wall-clock duration at any frame
 * rate — it just gets subdivided more finely when there are more frames to fill it.
 *
 * <p>The mining state machine only calls {@link #aimAt} to say where it wants to look;
 * it never moves the camera itself. That split is what lets the motion be smooth: if the
 * tick path also wrote rotation, the two would fight and the result would stutter.
 *
 * <p>Rotation is applied to the player's real yaw and pitch, so it travels to the server
 * in ordinary movement packets. Those are still only sent per tick, so this is a visual
 * change — the server sees the same turn either way.
 */
public final class RotationHelper {

    /** Hard ceiling on turn rate, in degrees per second. */
    private static final float MAX_RATE = 440f;
    /** Fraction of the remaining angle covered per tick, before the cap applies. */
    private static final float EASE_PER_TICK = 0.35f;
    /** Ticks per second, for converting the per-tick ease into a per-second rate. */
    private static final float TPS = 20f;

    private static final Random RANDOM = new Random();

    /** Where the state machine wants to look, or null when nothing is steering. */
    private static Float wantYaw = null;
    private static Float wantPitch = null;
    private static long lastFrameNanos = 0L;

    private RotationHelper() {}

    /** A point inside the block, off-centre, so repeated mining isn't pixel-identical. */
    public static class_243 humanAimPoint(double x, double y, double z) {
        return new class_243(
            x + 0.5 + (RANDOM.nextDouble() - 0.5) * 0.45,
            y + 0.5 + (RANDOM.nextDouble() - 0.5) * 0.45,
            z + 0.5 + (RANDOM.nextDouble() - 0.5) * 0.45);
    }

    /** Yaw the player would need to face the point. */
    public static float yawTo(class_746 player, class_243 point) {
        class_243 eye = player.method_33571();
        double dx = point.field_1352 - eye.field_1352;
        double dz = point.field_1350 - eye.field_1350;
        return (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
    }

    /** Pitch the player would need to face the point. */
    public static float pitchTo(class_746 player, class_243 point) {
        class_243 eye = player.method_33571();
        double dx = point.field_1352 - eye.field_1352;
        double dy = point.field_1351 - eye.field_1351;
        double dz = point.field_1350 - eye.field_1350;
        double flat = Math.sqrt(dx * dx + dz * dz);
        return (float) (-Math.toDegrees(Math.atan2(dy, flat)));
    }

    /**
     * Asks for these angles and reports whether the player is already within
     * {@code tolerance} degrees of both. The turn itself happens in {@link #renderStep}.
     */
    public static boolean aimAt(class_746 player, float yaw, float pitch, float tolerance) {
        float yawDiff = class_3532.method_15393(yaw - player.method_36454());
        float pitchDiff = class_3532.method_15393(pitch - player.method_36455());

        wantYaw = yaw;
        wantPitch = pitch;
        return Math.abs(yawDiff) <= tolerance && Math.abs(pitchDiff) <= tolerance;
    }

    /** Convenience: aim at a point, returning true once on target. */
    public static boolean lookAt(class_746 player, class_243 point, float tolerance) {
        return aimAt(player, yawTo(player, point), pitchTo(player, point), tolerance);
    }

    /** Hands the mouse back, so nothing keeps nudging the camera once mining stops. */
    public static void release() {
        wantYaw = null;
        wantPitch = null;
    }

    public static boolean isSteering() {
        return wantYaw != null;
    }

    /**
     * One frame's worth of turn. Called from the renderer before the camera is set up, so
     * the rotation written here is the rotation drawn this frame.
     */
    public static void renderStep(class_310 client) {
        long now = System.nanoTime();
        long previous = lastFrameNanos;
        lastFrameNanos = now;

        if (wantYaw == null || wantPitch == null) return;
        if (client.field_1724 == null || client.field_1755 != null) return;
        class_746 player = client.field_1724;

        // First frame after taking over has no previous timestamp to measure against.
        if (previous == 0L) return;
        // Clamp so a stutter or a paused window can't produce one enormous jump.
        float dt = Math.clamp((now - previous) / 1_000_000_000f, 0f, 0.1f);
        if (dt <= 0f) return;

        float yawDiff = class_3532.method_15393(wantYaw - player.method_36454());
        float pitchDiff = class_3532.method_15393(wantPitch - player.method_36455());

        // Exponential approach expressed per second, so the curve matches the old
        // per-tick feel at 20 fps and simply gets finer above it.
        float factor = 1f - (float) Math.pow(1f - EASE_PER_TICK, dt * TPS);
        float cap = MAX_RATE * dt;

        float yawStep = class_3532.method_15363(yawDiff * factor, -cap, cap);
        float pitchStep = class_3532.method_15363(pitchDiff * factor, -cap, cap);

        apply(player, yawStep, pitchStep);
    }

    /**
     * Writes the step the way mouse input does: the previous-frame angles move with the
     * current ones, so the camera tracks the turn directly instead of lagging a frame
     * behind through vanilla's render interpolation.
     */
    private static void apply(class_746 player, float yawStep, float pitchStep) {
        player.method_36456(player.method_36454() + yawStep);
        player.field_5982 += yawStep;

        player.method_36457(class_3532.method_15363(player.method_36455() + pitchStep, -90f, 90f));
        player.field_6004 = class_3532.method_15363(player.field_6004 + pitchStep, -90f, 90f);
    }

    /** A randomised tick count, so repeated actions don't share one cadence. */
    public static int jitterTicks(int base, int spread) {
        return base + RANDOM.nextInt(Math.max(1, spread));
    }
}
