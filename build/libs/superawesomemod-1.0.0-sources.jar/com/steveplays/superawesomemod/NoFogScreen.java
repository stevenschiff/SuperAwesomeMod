package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class NoFogScreen extends GabeOptionScreen {

    public NoFogScreen(class_437 parent) {
        super(parent, "No Fog");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", NoFogData::isEnabled, NoFogData::setEnabled);
        info("Removes distance, water and lava fog");
    }
}
