package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class HigherCrouchScreen extends GabeOptionScreen {

    public HigherCrouchScreen(class_437 parent) {
        super(parent, "Higher Crouch");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", HigherCrouchData::isEnabled, HigherCrouchData::setEnabled);
        info("1.7 style sneak camera height");
    }
}
