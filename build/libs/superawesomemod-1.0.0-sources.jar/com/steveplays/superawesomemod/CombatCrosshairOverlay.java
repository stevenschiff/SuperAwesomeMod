package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_10799;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;

@SuppressWarnings("deprecation")
public final class CombatCrosshairOverlay {

    private static final class_2960 CROSSHAIR_SPRITE =
        class_2960.method_60656("hud/crosshair");
    private static final int CROSSHAIR_SIZE = 15;

    private CombatCrosshairOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(CombatCrosshairOverlay::onHudRender);
    }

    private static void onHudRender(class_332 g, class_9779 tickCounter) {
        if (!CombatCrosshairData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;

        class_746 p = mc.field_1724;
        if (p == null) return;
        if (p.method_7325()) return;

        class_1297 target = mc.field_1692;
        boolean inRange = target != null && target.method_5732();

        int tint = inRange ? CombatCrosshairData.getInRangeARGB() : CombatCrosshairData.getOutOfRangeARGB();

        // Draw the vanilla crosshair sprite again with the chosen tint on top.
        int cx = (g.method_51421() - CROSSHAIR_SIZE) / 2;
        int cy = (g.method_51443() - CROSSHAIR_SIZE) / 2;
        g.method_52707(class_10799.field_56883, CROSSHAIR_SPRITE,
            cx, cy, CROSSHAIR_SIZE, CROSSHAIR_SIZE, tint);
    }
}
