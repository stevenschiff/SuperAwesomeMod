package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5250;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

public final class HealthIndicatorRenderer {

    private HealthIndicatorRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(HealthIndicatorRenderer::onAfterEntities);
    }

    private static void onAfterEntities(WorldRenderContext ctx) {
        if (!HealthIndicatorData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        class_746 self = mc.field_1724;
        class_638 level = mc.field_1687;
        if (self == null || level == null) return;

        class_4184 camera = ctx.gameRenderer().method_19418();
        float partialTick = mc.method_61966().method_60637(true);

        for (class_1297 entity : level.method_18112()) {
            if (!(entity instanceof class_1657 player)) continue;
            if (entity == self) continue;

            double distSq = self.method_5858(entity);
            if (distSq > 64 * 64) continue; // max 64 blocks away

            renderHealthAbove(player, ctx.matrices(), camera, partialTick, mc);
        }
    }

    private static void renderHealthAbove(class_1657 player, class_4587 poseStack,
                                           class_4184 camera, float partialTick,
                                           class_310 mc) {
        class_327 font = mc.field_1772;
        class_243 camPos = camera.method_71156();

        double x = class_3532.method_16436(partialTick, player.field_6014, player.method_23317());
        double y = class_3532.method_16436(partialTick, player.field_6036, player.method_23318());
        double z = class_3532.method_16436(partialTick, player.field_5969, player.method_23321());

        float entityHeight = player.method_17682();

        poseStack.method_22903();
        poseStack.method_46416(
            (float)(x - camPos.field_1352),
            (float)(y - camPos.field_1351) + entityHeight + 0.3f,
            (float)(z - camPos.field_1350)
        );

        // Billboard rotation: always face the camera
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));

        float scale = 0.025f;
        poseStack.method_22905(-scale, -scale, scale);

        // Build hearts text from player health
        float health = player.method_6032();
        float maxHealth = player.method_6063();
        int fullHearts = (int)(health / 2);
        boolean halfHeart = (health % 2) >= 1;
        int totalHearts = (int)(maxHealth / 2);

        class_5250 text = class_2561.method_43473();
        for (int i = 0; i < totalHearts; i++) {
            if (i < fullHearts || (i == fullHearts && halfHeart)) {
                text.method_10852(class_2561.method_43470("\u2764")
                    .method_27694(style -> style.method_36139(0xFF5555))); // red
            } else {
                text.method_10852(class_2561.method_43470("\u2764")
                    .method_27694(style -> style.method_36139(0x555555))); // dark gray
            }
        }

        float textWidth = font.method_27525(text);
        Matrix4f matrix = poseStack.method_23760().method_23761();

        class_4597.class_4598 bufferSource = mc.method_22940().method_23000();
        font.method_27522(
            text,
            -textWidth / 2f, 0,
            0xFFFFFFFF,
            false,
            matrix,
            bufferSource,
            class_327.class_6415.field_33994,
            0x40000000,
            15728880
        );
        bufferSource.method_22993();

        poseStack.method_22909();
    }
}
