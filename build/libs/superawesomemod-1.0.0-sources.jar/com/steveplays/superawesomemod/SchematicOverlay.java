package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/**
 * HUD overlay showing schematic info: name, layer indicator, verifier summary.
 * Follows the same pattern as {@link ArmorHudOverlay}.
 */
public final class SchematicOverlay {

    private SchematicOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(SchematicOverlay::onHudRender);
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter) {
        if (!SchematicData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;

        SchematicPlacement placement = SchematicData.getCurrentPlacement();
        if (placement == null) return;

        int x = 4;
        int y = 4;
        int lineHeight = 10;
        int color = 0xFFFFFF;
        int dimColor = 0xAAAAAA;

        // Schematic name
        String name = placement.getSchematic().getName();
        graphics.method_25303(mc.field_1772, "Schematic: " + name, x, y, color);
        y += lineHeight;

        // Position
        class_2338 origin = placement.getOrigin();
        graphics.method_25303(mc.field_1772,
            "Pos: " + origin.method_10263() + ", " + origin.method_10264() + ", " + origin.method_10260()
            + " | Rot: " + placement.getRotationName()
            + (placement.isMirror() ? " | Mirror" : ""),
            x, y, dimColor);
        y += lineHeight;

        // Layer mode
        if (SchematicData.isLayerMode()) {
            int layer = SchematicData.getCurrentLayer();
            int maxLayer = SchematicData.getMaxLayer();
            graphics.method_25303(mc.field_1772,
                "Layer " + layer + " / " + maxLayer + "  (PgUp/PgDn)",
                x, y, 0xFFFF55);
            y += lineHeight;
        }

        // Verifier summary (when in verifier mode)
        if (SchematicData.getRenderMode() == 1) {
            int correct = SchematicVerifier.getCorrectCount();
            int wrong = SchematicVerifier.getWrongCount();
            int missing = SchematicVerifier.getMissingCount();
            int extra = SchematicVerifier.getExtraCount();

            graphics.method_25303(mc.field_1772, "Verifier:", x, y, color);
            y += lineHeight;
            graphics.method_25303(mc.field_1772, "  Correct: " + correct, x, y, 0x55FF55);
            y += lineHeight;
            graphics.method_25303(mc.field_1772, "  Wrong: " + wrong, x, y, 0xFF5555);
            y += lineHeight;
            graphics.method_25303(mc.field_1772, "  Missing: " + missing, x, y, 0xFFFF55);
            y += lineHeight;
            graphics.method_25303(mc.field_1772, "  Extra: " + extra, x, y, 0xFF55FF);
        }
    }
}
