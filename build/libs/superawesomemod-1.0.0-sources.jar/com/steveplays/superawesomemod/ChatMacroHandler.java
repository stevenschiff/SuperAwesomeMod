package com.steveplays.superawesomemod;

import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_634;

/**
 * Sends a macro's line when its key is pressed.
 *
 * <p>Two modes, per slot-wide setting:
 * <ul>
 *   <li><b>Repeat off</b> — fires on the <em>rising edge</em> of the key, the tick it goes
 *       from up to down, so holding sends exactly once however long it is held.</li>
 *   <li><b>Repeat on</b> — keeps firing while the key stays down, one send per cooldown
 *       interval.</li>
 * </ul>
 *
 * <p>Either way the cooldown is the floor on send rate. Minecraft's own {@code consumeClick}
 * queue is drained rather than used as the trigger, because queued presses would otherwise
 * fire in a burst after a pause.
 *
 * <p>Nothing is sent while a screen is open, so typing a macro into its own settings box
 * cannot trigger it.
 */
public final class ChatMacroHandler {

    private static final boolean[] wasDown = new boolean[ChatMacroData.SLOTS];
    private static final long[] lastSentMs = new long[ChatMacroData.SLOTS];

    private ChatMacroHandler() {}

    public static void tick(class_310 client) {
        class_304[] keys = ModKeybindings.chatMacros;
        if (keys == null) return;

        boolean repeat = ChatMacroData.isRepeatWhileHeld();

        for (int i = 0; i < ChatMacroData.SLOTS && i < keys.length; i++) {
            // Always drain, enabled or not, so presses never bank up.
            while (keys[i].method_1436()) { /* drained deliberately */ }

            boolean down = keys[i].method_1434();
            boolean rising = down && !wasDown[i];
            wasDown[i] = down;

            boolean wants = repeat ? down : rising;
            if (!wants) continue;
            if (!ChatMacroData.isEnabled()) continue;
            if (client.field_1755 != null || client.field_1724 == null) continue;

            long now = System.currentTimeMillis();
            if (now - lastSentMs[i] < ChatMacroData.getCooldownMs()) continue;

            String message = ChatMacroData.getMessage(i).trim();
            if (message.isEmpty()) continue;

            lastSentMs[i] = now;
            send(client, message);
        }
    }

    private static void send(class_310 client, String message) {
        class_634 connection = client.method_1562();
        if (connection == null) return;

        if (message.startsWith("/")) {
            // sendCommand expects the command without its slash.
            connection.method_45730(message.substring(1));
        } else {
            connection.method_45729(message);
        }
    }
}
