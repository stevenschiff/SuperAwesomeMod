package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Main mod menu screen. Add a new Button entry here for each future feature.
 * Open with the G keybind (rebindable in Options → Controls → SuperAwesomeMod).
 */
public class ModMenuScreen extends class_437 {

    public ModMenuScreen() {
        super(class_2561.method_43470("SuperAwesomeMod"));
    }

    @Override
    protected void method_25426() {
        int cx    = this.field_22789 / 2;
        int cy    = this.field_22790 / 2;
        int btnW  = 200;
        int btnH  = 20;
        int gap   = 24;

        // 19 buttons centered vertically around cy: rows 0..18 of `gap`.
        int row0 = cy - (18 * gap) / 2;

        // --- Enable All preset ---
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Enable All"),
            btn -> {
                FreeLookData.setEnabled(true);
                ArmorHudData.setEnabled(true);
                CombatHitboxData.setEnabled(true);
                CombatCrosshairData.setEnabled(true);
                CombatPotionEffectsData.setEnabled(true);
                AppleSkinData.setEnabled(true);
                ShulkerTooltipData.setEnabled(true);
                OldPvpData.setSwingWhileUsingEnabled(true);
                MiniMapData.setEnabled(true);
                MiniMapData.setHudVisible(true);
                MiniMapData.setMinimapSize(64);
                MiniMapData.setCorner(3); // Bottom-Right
            }
        ).method_46434(cx - btnW / 2, row0, btnW, btnH).method_46431());

        // --- Feature buttons (add more below as the mod grows) ---
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Free Look"),
            btn -> this.field_22787.method_1507(new FreeLookScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Armor HUD"),
            btn -> this.field_22787.method_1507(new ArmorHudScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 2, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Combat Hitboxes"),
            btn -> this.field_22787.method_1507(new CombatHitboxScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 3, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Combat Crosshair"),
            btn -> this.field_22787.method_1507(new CombatCrosshairScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 4, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Combat Potion Effects"),
            btn -> this.field_22787.method_1507(new CombatPotionEffectsScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 5, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("PvP Cheat Detector"),
            btn -> this.field_22787.method_1507(new PvpDetectorScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 6, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Autoclicker"),
            btn -> this.field_22787.method_1507(new AutoclickerScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 7, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Freecam"),
            btn -> this.field_22787.method_1507(new FreecamScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 8, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("AppleSkin"),
            btn -> this.field_22787.method_1507(new AppleSkinScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 9, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Shulker Tooltips"),
            btn -> this.field_22787.method_1507(new ShulkerTooltipScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 10, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Render Distance"),
            btn -> this.field_22787.method_1507(new RenderDistanceScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 11, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Item Physics"),
            btn -> this.field_22787.method_1507(new ItemPhysicsScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 12, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("1.7 PvP Animations"),
            btn -> this.field_22787.method_1507(new OldPvpScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 13, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("X-Ray"),
            btn -> this.field_22787.method_1507(new XrayScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 14, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Mini Map"),
            btn -> this.field_22787.method_1507(new MiniMapScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 15, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Motion Blur"),
            btn -> this.field_22787.method_1507(new MotionBlurScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 16, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Schematics"),
            btn -> this.field_22787.method_1507(new SchematicScreen(this))
        ).method_46434(cx - btnW / 2, row0 + gap * 17, btnW, btnH).method_46431());

        // --- Close ---
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Close"),
            btn -> this.method_25419()
        ).method_46434(cx - btnW / 2, row0 + gap * 18, btnW, btnH).method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        graphics.method_27534(this.field_22793, this.field_22785,
            this.field_22789 / 2, this.field_22790 / 2 - 132, 0xFFFFFF);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
