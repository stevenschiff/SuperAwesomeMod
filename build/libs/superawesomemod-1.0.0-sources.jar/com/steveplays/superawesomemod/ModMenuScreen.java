package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Main mod menu screen. Add a new Button entry here for each future feature.
 * Open with the G keybind (rebindable in Options → Controls → SuperAwesomeMod).
 */
public class ModMenuScreen extends class_437 {

    public ModMenuScreen() {
        super(class_2561.method_43470("SuperAwesomeMod"));
    }

    @Override
    protected void method_25426() {
        int cx    = this.field_22789 / 2;
        int cy    = this.field_22790 / 2;
        int btnW  = 200;
        int btnH  = 20;
        int gap   = 26;

        // --- Feature buttons (add more below as the mod grows) ---
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Jump Height"),
            btn -> this.field_22787.method_1507(new JumpHeightScreen(this))
        ).method_46434(cx - btnW / 2, cy - gap * 2, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Flight"),
            btn -> this.field_22787.method_1507(new FlyScreen(this))
        ).method_46434(cx - btnW / 2, cy - gap, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Attack Range"),
            btn -> this.field_22787.method_1507(new AttackRangeScreen(this))
        ).method_46434(cx - btnW / 2, cy, btnW, btnH).method_46431());

        // --- Close ---
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Close"),
            btn -> this.method_25419()
        ).method_46434(cx - btnW / 2, cy + gap * 2, btnW, btnH).method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        graphics.method_27534(this.field_22793, this.field_22785,
            this.field_22789 / 2, this.field_22790 / 2 - 80, 0xFFFFFF);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
