package com.steveplays.superawesomemod;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Main mod menu screen. Buttons flow left-to-right in rows with a search bar
 * at the top-left. Matching buttons are highlighted with a white outline.
 * Open with the G keybind (rebindable in Options → Controls → SuperAwesomeMod).
 */
public class ModMenuScreen extends class_437 {

    private class_342 searchField;
    private final List<FeatureButton> featureButtons = new ArrayList<>();

    private static class FeatureButton {
        final String label;
        final class_4185 button;

        FeatureButton(String label, class_4185 button) {
            this.label = label;
            this.button = button;
        }
    }

    public ModMenuScreen() {
        super(class_2561.method_43470("SuperAwesomeMod"));
    }

    @Override
    protected void method_25426() {
        featureButtons.clear();

        int padding = 10;
        int btnW = 140;
        int btnH = 20;
        int gapX = 4;
        int gapY = 4;

        // --- Search bar at top-left ---
        searchField = new class_342(this.field_22793, padding, padding, 200, btnH,
                class_2561.method_43470("Search"));
        searchField.method_47404(class_2561.method_43470("Search..."));
        searchField.method_1880(50);
        this.method_37063(searchField);

        // --- Buttons start below the search bar ---
        int startY = padding + btnH + gapY + 4;
        int availableWidth = this.field_22789 - 2 * padding;
        int buttonsPerRow = Math.max(1, (availableWidth + gapX) / (btnW + gapX));

        // Enable All
        addFeature("Enable All", buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY,
                btn -> {
                    FreeLookData.setEnabled(true);
                    ArmorHudData.setEnabled(true);
                    CombatHitboxData.setEnabled(true);
                    CombatCrosshairData.setEnabled(true);
                    CombatPotionEffectsData.setEnabled(true);
                    AppleSkinData.setEnabled(true);
                    ShulkerTooltipData.setEnabled(true);
                    OldPvpData.setSwingWhileUsingEnabled(true);
                    MiniMapData.setEnabled(true);
                    MiniMapData.setHudVisible(true);
                    MiniMapData.setMinimapSize(64);
                    MiniMapData.setCorner(3);
                    NametagData.setEnabled(true);
                    MotionBlurData.setEnabled(true);
                    MotionBlurData.setStrength(3);
                    HealthIndicatorData.setEnabled(true);
                    HigherCrouchData.setEnabled(true);
                    CpsData.setEnabled(true);
                    CpsData.setScale(5);
                    KeystrokesData.setEnabled(true);
                    KeystrokesData.setCorner(3);
                    NoFogData.setEnabled(true);
                });

        // Feature buttons
        addFeature("Free Look",             buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new FreeLookScreen(this)));
        addFeature("Armor HUD",             buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new ArmorHudScreen(this)));
        addFeature("Combat Hitboxes",       buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new CombatHitboxScreen(this)));
        addFeature("Combat Crosshair",      buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new CombatCrosshairScreen(this)));
        addFeature("Combat Potion Effects", buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new CombatPotionEffectsScreen(this)));
        addFeature("PvP Cheat Detector",    buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new PvpDetectorScreen(this)));
        addFeature("Autoclicker",           buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new AutoclickerScreen(this)));
        addFeature("Freecam",               buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new FreecamScreen(this)));
        addFeature("AppleSkin",             buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new AppleSkinScreen(this)));
        addFeature("Shulker Tooltips",      buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new ShulkerTooltipScreen(this)));
        addFeature("Render Distance",       buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new RenderDistanceScreen(this)));
        addFeature("Item Physics",          buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new ItemPhysicsScreen(this)));
        addFeature("1.7 PvP Animations",   buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new OldPvpScreen(this)));
        addFeature("X-Ray",                buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new XrayScreen(this)));
        addFeature("Mini Map",             buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new MiniMapScreen(this)));
        addFeature("Motion Blur",          buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new MotionBlurScreen(this)));
        addFeature("Health Indicators",    buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new HealthIndicatorScreen(this)));
        addFeature("Nametag",              buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new NametagScreen(this)));
        addFeature("Min Ping",             buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new MinPingScreen(this)));
        addFeature("Higher Crouch",        buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new HigherCrouchScreen(this)));
        addFeature("Farther Players",      buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new FartherPlayersScreen(this)));
        addFeature("CPS Counter",          buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new CpsScreen(this)));
        addFeature("Keystrokes",           buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new KeystrokesScreen(this)));
        addFeature("No Fog",              buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.field_22787.method_1507(new NoFogScreen(this)));

        // Close button
        addFeature("Close", buttonsPerRow, btnW, btnH, gapX, gapY, padding, startY, btn -> this.method_25419());
    }

    private void addFeature(String label, int buttonsPerRow, int btnW, int btnH,
                            int gapX, int gapY, int padding, int startY,
                            class_4185.class_4241 action) {
        int index = featureButtons.size();
        int col = index % buttonsPerRow;
        int row = index / buttonsPerRow;
        int x = padding + col * (btnW + gapX);
        int y = startY + row * (btnH + gapY);

        class_4185 btn = class_4185.method_46430(class_2561.method_43470(label), action)
                .method_46434(x, y, btnW, btnH).method_46431();
        this.method_37063(btn);
        featureButtons.add(new FeatureButton(label, btn));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        // Draw a fully opaque background so the menu always covers F3 and other overlays.
        graphics.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF000000);
        super.method_25394(graphics, mouseX, mouseY, delta);

        // Draw white outline around buttons that match the search query
        String query = searchField.method_1882().toLowerCase().trim();
        if (!query.isEmpty()) {
            for (FeatureButton fb : featureButtons) {
                if (fb.label.toLowerCase().contains(query)) {
                    int x = fb.button.method_46426() - 2;
                    int y = fb.button.method_46427() - 2;
                    int w = fb.button.method_25368() + 4;
                    int h = fb.button.method_25364() + 4;
                    // White outline (2px border via nested outlines)
                    graphics.method_73198(x, y, w, h, 0xFFFFFFFF);
                    graphics.method_73198(x + 1, y + 1, w - 2, h - 2, 0xFFFFFFFF);
                }
            }
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
