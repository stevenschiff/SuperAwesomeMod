package com.steveplays.superawesomemod;

import com.steveplays.superawesomemod.network.FlySpeedPayload;
import com.steveplays.superawesomemod.network.ToggleFlyPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class FlyScreen extends class_437 {

    private final class_437 parent;

    // Speed preset labels and their values (must stay in sync)
    private static final String[] SPEED_LABELS = { "Slow", "Normal", "Fast", "Very Fast" };
    private static final float[]  SPEED_VALUES  = {
        FlySpeedPayload.SLOW,
        FlySpeedPayload.NORMAL,
        FlySpeedPayload.FAST,
        FlySpeedPayload.VERY_FAST
    };

    public FlyScreen(class_437 parent) {
        super(class_2561.method_43470("Flight"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        // Toggle button — label reflects current state from shared PlayerFlyData
        boolean canFly = isFlightEnabled();
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470(canFly ? "Disable Flight" : "Enable Flight"),
            btn -> toggleFlight()
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        // Speed preset buttons — evenly spaced in a single row
        int totalSpeedW = SPEED_LABELS.length * 48 + (SPEED_LABELS.length - 1) * 4;
        int speedStartX = cx - totalSpeedW / 2;
        for (int i = 0; i < SPEED_LABELS.length; i++) {
            final float speed = SPEED_VALUES[i];
            this.method_37063(class_4185.method_46430(
                class_2561.method_43470(SPEED_LABELS[i]),
                btn -> setSpeed(speed)
            ).method_46434(speedStartX + i * 52, cy - 10, 48, btnH).method_46431());
        }

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private void toggleFlight() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;

        boolean newState = !PlayerFlyData.isEnabled(mc.field_1724.method_5667());

        // Write to the shared ConcurrentHashMap — the client tick hook reads this
        // every tick to maintain mayfly=true locally (works on any server).
        PlayerFlyData.setEnabled(mc.field_1724.method_5667(), newState);

        // Apply immediately to this client so flight starts/stops without waiting
        // for the next tick. This works on any server — no packet round-trip needed.
        mc.field_1724.method_31549().field_7478 = newState;
        mc.field_1724.method_31549().field_7479 = newState;

        // Also send the packet so servers that have the mod installed get updated
        // server-side as well (for correct physics validation on those servers).
        ClientPlayNetworking.send(new ToggleFlyPayload(newState));

        this.field_22787.method_1507(this.parent);
    }

    private void setSpeed(float speed) {
        // Apply immediately client-side for zero-latency feel
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            mc.field_1724.method_31549().method_7248(speed);
        }
        ClientPlayNetworking.send(new FlySpeedPayload(speed));
    }

    /**
     * Reads from PlayerFlyData (the shared ConcurrentHashMap) rather than the
     * client-side mayfly flag. This gives accurate state even before the server
     * has had a chance to sync the abilities packet back.
     */
    private boolean isFlightEnabled() {
        class_310 mc = class_310.method_1551();
        return mc.field_1724 != null && PlayerFlyData.isEnabled(mc.field_1724.method_5667());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);

        boolean canFly = isFlightEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (canFly ? "Enabled" : "Disabled")),
            cx, cy - 58, canFly ? 0x55FF55 : 0xFF5555);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Speed:"),
            cx, cy - 24, 0xAAAAAA);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
