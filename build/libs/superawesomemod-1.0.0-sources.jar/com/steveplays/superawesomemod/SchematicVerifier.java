package com.steveplays.superawesomemod;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_638;

/**
 * Compares placed blocks in the world against the expected schematic blocks.
 * Caches results and rescans periodically (tick-throttled).
 */
public final class SchematicVerifier {

    private SchematicVerifier() {}

    public enum Status {
        CORRECT,
        WRONG_BLOCK,
        MISSING,
        EXTRA
    }

    private static final Map<class_2338, Status> cache = new HashMap<>();
    private static int tickCounter = 0;
    private static final int SCAN_INTERVAL = 10;
    private static final int SCAN_RADIUS = 32;

    private static int correctCount = 0;
    private static int wrongCount = 0;
    private static int missingCount = 0;
    private static int extraCount = 0;

    /**
     * Returns the cached verification status at the given position, or null if not scanned.
     */
    public static Status getStatus(class_2338 pos) {
        return cache.get(pos);
    }

    public static int getCorrectCount() { return correctCount; }
    public static int getWrongCount() { return wrongCount; }
    public static int getMissingCount() { return missingCount; }
    public static int getExtraCount() { return extraCount; }

    /**
     * Called every client tick when verifier mode is active.
     */
    public static void tick(class_638 level, SchematicPlacement placement) {
        if (level == null || placement == null) return;

        tickCounter++;
        if (tickCounter < SCAN_INTERVAL) return;
        tickCounter = 0;

        rescan(level, placement);
    }

    public static void clearCache() {
        cache.clear();
        correctCount = 0;
        wrongCount = 0;
        missingCount = 0;
        extraCount = 0;
    }

    private static void rescan(class_638 level, SchematicPlacement placement) {
        cache.clear();
        correctCount = 0;
        wrongCount = 0;
        missingCount = 0;
        extraCount = 0;

        class_2338 min = placement.getMin();
        class_2338 max = placement.getMax();

        var player = net.minecraft.class_310.method_1551().field_1724;
        if (player == null) return;

        class_2338 playerPos = player.method_24515();

        int startX = Math.max(min.method_10263(), playerPos.method_10263() - SCAN_RADIUS);
        int startY = Math.max(min.method_10264(), playerPos.method_10264() - SCAN_RADIUS);
        int startZ = Math.max(min.method_10260(), playerPos.method_10260() - SCAN_RADIUS);
        int endX = Math.min(max.method_10263(), playerPos.method_10263() + SCAN_RADIUS);
        int endY = Math.min(max.method_10264(), playerPos.method_10264() + SCAN_RADIUS);
        int endZ = Math.min(max.method_10260(), playerPos.method_10260() + SCAN_RADIUS);

        // Layer mode restriction
        if (SchematicData.isLayerMode()) {
            int layerY = min.method_10264() + SchematicData.getCurrentLayer();
            startY = layerY;
            endY = layerY + 1;
        }

        class_2338.class_2339 mutable = new class_2338.class_2339();

        for (int y = startY; y < endY; y++) {
            for (int z = startZ; z < endZ; z++) {
                for (int x = startX; x < endX; x++) {
                    mutable.method_10103(x, y, z);

                    class_2680 expected = placement.getBlockStateAt(mutable);
                    class_2680 actual = level.method_8320(mutable);

                    boolean expectedAir = expected.method_26215();
                    boolean actualAir = actual.method_26215();

                    Status status;
                    if (expectedAir && actualAir) {
                        continue; // both air, skip
                    } else if (expectedAir && !actualAir) {
                        status = Status.EXTRA;
                        extraCount++;
                    } else if (!expectedAir && actualAir) {
                        status = Status.MISSING;
                        missingCount++;
                    } else if (expected.equals(actual)) {
                        status = Status.CORRECT;
                        correctCount++;
                    } else {
                        status = Status.WRONG_BLOCK;
                        wrongCount++;
                    }

                    cache.put(mutable.method_10062(), status);
                }
            }
        }
    }
}
