package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class MotionBlurScreen extends class_437 {

    private final class_437 parent;

    public MotionBlurScreen(class_437 parent) {
        super(class_2561.method_43470("Motion Blur"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        // Toggle on/off
        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                MotionBlurData.setEnabled(!MotionBlurData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        // Strength slider 1..10
        this.method_37063(new StrengthSlider(
            cx - btnW / 2, cy - 14, btnW, btnH,
            MotionBlurData.getStrength()
        ));

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(MotionBlurData.isEnabled()
            ? "Motion Blur: Enabled"
            : "Motion Blur: Disabled");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 60, 0xFFFFFF);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class StrengthSlider extends class_357 {
        StrengthSlider(int x, int y, int w, int h, int initialStrength) {
            super(x, y, w, h, class_2561.method_43473(),
                normalize(initialStrength));
            this.method_25346();
        }

        private static double normalize(int strength) {
            return (double) (strength - MotionBlurData.MIN_STRENGTH)
                 / (double) (MotionBlurData.MAX_STRENGTH - MotionBlurData.MIN_STRENGTH);
        }

        @Override
        protected void method_25346() {
            int str = (int) Math.round(this.field_22753
                * (MotionBlurData.MAX_STRENGTH - MotionBlurData.MIN_STRENGTH)
                + MotionBlurData.MIN_STRENGTH);
            this.method_25355(class_2561.method_43470("Strength: " + str));
        }

        @Override
        protected void method_25344() {
            int str = (int) Math.round(this.field_22753
                * (MotionBlurData.MAX_STRENGTH - MotionBlurData.MIN_STRENGTH)
                + MotionBlurData.MIN_STRENGTH);
            MotionBlurData.setStrength(str);
        }
    }
}
