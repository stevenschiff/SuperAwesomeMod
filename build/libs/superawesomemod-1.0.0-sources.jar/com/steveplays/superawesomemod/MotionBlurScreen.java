package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class MotionBlurScreen extends GabeOptionScreen {

    public MotionBlurScreen(class_437 parent) {
        super(parent, "Motion Blur");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", MotionBlurData::isEnabled, MotionBlurData::setEnabled);
        slider("Strength", MotionBlurData.MIN_STRENGTH, MotionBlurData.MAX_STRENGTH,
               MotionBlurData::getStrength, MotionBlurData::setStrength, String::valueOf);
    }
}
