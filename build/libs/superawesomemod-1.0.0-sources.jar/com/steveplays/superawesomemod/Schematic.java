package com.steveplays.superawesomemod;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2680;

/**
 * In-memory representation of a loaded {@code .litematic} schematic.
 */
public final class Schematic {

    private final String name;
    private final String author;
    private final class_2382 enclosingSize;
    private final List<SchematicRegion> regions;
    private final int totalBlocks;

    public Schematic(String name, String author, class_2382 enclosingSize,
                     List<SchematicRegion> regions, int totalBlocks) {
        this.name = name;
        this.author = author;
        this.enclosingSize = enclosingSize;
        this.regions = List.copyOf(regions);
        this.totalBlocks = totalBlocks;
    }

    /**
     * Returns the block state at the given position relative to the schematic origin (0,0,0).
     * Iterates regions to find which one (if any) contains the position.
     */
    public class_2680 getBlockState(int x, int y, int z) {
        for (SchematicRegion region : regions) {
            class_2338 min = region.getMinPos();
            class_2338 max = region.getMaxPos();

            if (x >= min.method_10263() && x < max.method_10263()
                && y >= min.method_10264() && y < max.method_10264()
                && z >= min.method_10260() && z < max.method_10260()) {
                int rx = x - min.method_10263();
                int ry = y - min.method_10264();
                int rz = z - min.method_10260();
                return region.getBlockState(rx, ry, rz);
            }
        }
        return class_2246.field_10124.method_9564();
    }

    /**
     * Counts all non-air blocks grouped by block state.
     */
    public Map<class_2680, Integer> countBlocks() {
        Map<class_2680, Integer> counts = new HashMap<>();
        for (SchematicRegion region : regions) {
            int sx = region.getAbsSizeX();
            int sy = region.getAbsSizeY();
            int sz = region.getAbsSizeZ();
            for (int y = 0; y < sy; y++) {
                for (int z = 0; z < sz; z++) {
                    for (int x = 0; x < sx; x++) {
                        class_2680 state = region.getBlockState(x, y, z);
                        if (!state.method_26215()) {
                            counts.merge(state, 1, Integer::sum);
                        }
                    }
                }
            }
        }
        return counts;
    }

    public String getName() { return name; }
    public String getAuthor() { return author; }
    public class_2382 getEnclosingSize() { return enclosingSize; }
    public List<SchematicRegion> getRegions() { return regions; }
    public int getTotalBlocks() { return totalBlocks; }

    /**
     * Returns the minimum corner across all regions.
     */
    public class_2338 getMinPos() {
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        for (SchematicRegion r : regions) {
            class_2338 min = r.getMinPos();
            minX = Math.min(minX, min.method_10263());
            minY = Math.min(minY, min.method_10264());
            minZ = Math.min(minZ, min.method_10260());
        }
        return new class_2338(minX, minY, minZ);
    }

    /**
     * Returns the maximum corner (exclusive) across all regions.
     */
    public class_2338 getMaxPos() {
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        for (SchematicRegion r : regions) {
            class_2338 max = r.getMaxPos();
            maxX = Math.max(maxX, max.method_10263());
            maxY = Math.max(maxY, max.method_10264());
            maxZ = Math.max(maxZ, max.method_10260());
        }
        return new class_2338(maxX, maxY, maxZ);
    }
}
