package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_310;
import net.minecraft.class_3620;
import net.minecraft.class_638;

public final class MiniMapChunkScanner {

    private MiniMapChunkScanner() {}

    public static void register() {
        ClientChunkEvents.CHUNK_LOAD.register(MiniMapChunkScanner::onChunkLoad);
    }

    private static void onChunkLoad(class_638 level, class_2818 chunk) {
        if (!MiniMapData.isEnabled()) return;

        int chunkX = chunk.method_12004().field_9181;
        int chunkZ = chunk.method_12004().field_9180;

        // Always rescan (terrain may have changed)
        int[] colors = scanChunk(level, chunk);
        MiniMapChunkCache.put(chunkX, chunkZ, colors);
        MiniMapPersistence.markDirty();
    }

    public static void scanLoadedChunks(class_638 level) {
        // Scan all currently loaded chunks (used on world join to fill cache)
        // This is called after persistence loads, so we only scan chunks not in cache
        if (level == null) return;
        // Chunks are loaded by the client automatically; we rely on CHUNK_LOAD events
        // This method can force-scan visible chunks if needed
    }

    public static int[] scanChunk(class_638 level, class_2818 chunk) {
        int[] colors = new int[256];
        int baseX = chunk.method_12004().field_9181 * 16;
        int baseZ = chunk.method_12004().field_9180 * 16;

        boolean isNether = level.method_27983() == class_1937.field_25180;
        int playerY = -1;
        if (isNether) {
            var player = class_310.method_1551().field_1724;
            if (player != null) {
                playerY = (int) player.method_23318();
            }
        }

        class_2338.class_2339 mutable = new class_2338.class_2339();

        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int surfaceY;
                if (isNether) {
                    // Scan downward from the player's Y to find the floor
                    surfaceY = findNetherSurface(chunk, lx, lz, baseX, baseZ, mutable, playerY);
                } else {
                    surfaceY = chunk.method_12005(class_2902.class_2903.field_13202, lx, lz);
                }

                mutable.method_10103(baseX + lx, surfaceY, baseZ + lz);
                class_2680 state = chunk.method_8320(mutable);
                class_3620 mapColor = state.method_26205(level, mutable);

                if (mapColor != class_3620.field_16008) {
                    colors[lx * 16 + lz] = mapColor.field_16011 | 0xFF000000;
                } else {
                    colors[lx * 16 + lz] = 0xFF000000; // black for none
                }
            }
        }
        return colors;
    }

    /**
     * In the Nether, scan downward from the player's Y level to find the
     * first solid non-lava block. This gives us the actual floor the player
     * is walking on rather than the ceiling/roof above.
     */
    private static int findNetherSurface(class_2818 chunk, int lx, int lz,
                                          int baseX, int baseZ,
                                          class_2338.class_2339 mutable,
                                          int playerY) {
        int startY = (playerY > 0) ? playerY : 80;
        for (int y = startY; y >= 0; y--) {
            mutable.method_10103(baseX + lx, y, baseZ + lz);
            class_2680 state = chunk.method_8320(mutable);
            if (state.method_26215() || state.method_26204() == class_2246.field_10164) continue;
            return y;
        }
        return 0;
    }
}
