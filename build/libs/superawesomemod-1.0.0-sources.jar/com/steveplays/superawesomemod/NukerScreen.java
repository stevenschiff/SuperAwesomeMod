package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class NukerScreen extends class_437 {

    private final class_437 parent;

    public NukerScreen(class_437 parent) {
        super(class_2561.method_43470("Nuker"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                NukerData.setEnabled(!NukerData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 52, btnW, btnH).method_46431());

        this.method_37063(new RadiusSlider(cx - btnW / 2, cy - 28, btnW, btnH,
                NukerData.getRadius()));

        this.method_37063(class_4185.method_46430(
            instantLabel(),
            btn -> {
                NukerData.setInstantOnly(!NukerData.isInstantOnly());
                btn.method_25355(instantLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 4, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(NukerData.isEnabled() ? "Disable Nuker" : "Enable Nuker");
    }

    private static class_2561 instantLabel() {
        return class_2561.method_43470("Instant blocks only: " + (NukerData.isInstantOnly() ? "On" : "Off"));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 82, 0xFFFFFF);

        boolean on = NukerData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 70, on ? 0x55FF55 : 0xFF5555);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Instant for grass, crops, torches, leaves w/ shears"),
            cx, cy + 46, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Stone and ore are never instant - the server times those"),
            cx, cy + 58, 0xFFAA00);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("With instant-only off, hard blocks go one at a time"),
            cx, cy + 70, 0xAAAAAA);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class RadiusSlider extends class_357 {
        RadiusSlider(int x, int y, int w, int h, int initial) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.method_25346();
        }

        private static double normalize(int v) {
            return (double) (v - NukerData.MIN_RADIUS) / (NukerData.MAX_RADIUS - NukerData.MIN_RADIUS);
        }

        private int denormalize() {
            return (int) Math.round(this.field_22753
                * (NukerData.MAX_RADIUS - NukerData.MIN_RADIUS) + NukerData.MIN_RADIUS);
        }

        @Override
        protected void method_25346() {
            this.method_25355(class_2561.method_43470("Radius: " + denormalize() + " blocks"));
        }

        @Override
        protected void method_25344() {
            NukerData.setRadius(denormalize());
        }
    }
}
