package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_10799;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;

/**
 * The live half of the spacing trainer: what your gap is <em>right now</em>.
 *
 * <p>This is the part that actually teaches. Nobody can feel the difference between
 * 2.2 and 2.8 blocks unaided, but with a number and a colour attached the distinction
 * becomes learnable inside one session. The bar carries tick marks at the band edges
 * so it teaches where the bands are, not just where you currently sit.
 */
@SuppressWarnings("deprecation")
public final class SpacingOverlay {

    private static final int BAR_WIDTH = 100;
    private static final int BAR_HEIGHT = 4;
    private static final long FLASH_MS = 1000L;

    private static final class_2960 CROSSHAIR_SPRITE =
        class_2960.method_60656("hud/crosshair");
    private static final int CROSSHAIR_SIZE = 15;

    private SpacingOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(SpacingOverlay::onHudRender);
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter) {
        if (!SpacingData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;

        class_746 self = mc.field_1724;
        if (self == null || self.method_7325() || mc.field_1687 == null) return;

        class_1297 target = pickTarget(mc, self);
        // Confirmed with the user: nothing on screen unless a player is close.
        if (target == null) return;

        double reach = CombatReach.attackReach(self);
        double gap = CombatReach.gap(self.method_33571(), target.method_5829());
        SpacingData.Zone zone = SpacingData.zoneOf(gap, reach);

        if (SpacingData.isGradedCrosshair()) {
            drawGradedCrosshair(graphics, zone);
        }

        float scale = SpacingData.getScale() / 2.0f;
        int panelW = BAR_WIDTH;
        int anchorX = (int) (graphics.method_51421() / 2.0f - (panelW * scale) / 2.0f);
        int anchorY = (int) (graphics.method_51443() - 62 * scale);

        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate((float) anchorX, (float) anchorY);
        graphics.method_51448().scale(scale, scale);

        if (SpacingData.isShowMeter()) {
            drawMeter(graphics, mc, gap, reach, zone);
        }
        if (SpacingData.isShowFlash()) {
            drawFlash(graphics, mc);
        }

        graphics.method_51448().popMatrix();
    }

    private static void drawMeter(class_332 graphics, class_310 mc,
                                  double gap, double reach, SpacingData.Zone zone) {
        String number = String.format("%.2f", gap);
        String label = zone.label;

        int numberW = mc.field_1772.method_1727(number);
        graphics.method_51433(mc.field_1772, number,
            (BAR_WIDTH - numberW) / 2, 0, zone.argb, true);

        int barY = mc.field_1772.field_2000 + 2;
        graphics.method_25294(0, barY, BAR_WIDTH, barY + BAR_HEIGHT, 0xC0000000);

        int filled = (int) Math.round(BAR_WIDTH * Math.clamp(gap / reach, 0.0, 1.0));
        graphics.method_25294(0, barY, filled, barY + BAR_HEIGHT, zone.argb);

        // Band edges, so the bar teaches the zones rather than just a level.
        tick(graphics, SpacingData.BAND_INSIDE, reach, barY);
        tick(graphics, SpacingData.BAND_CLOSE, reach, barY);
        tick(graphics, SpacingData.BAND_GOOD, reach, barY);

        int labelW = mc.field_1772.method_1727(label);
        graphics.method_51433(mc.field_1772, label,
            (BAR_WIDTH - labelW) / 2, barY + BAR_HEIGHT + 2, zone.argb, true);
    }

    private static void tick(class_332 graphics, double at, double reach, int barY) {
        if (at >= reach) return;
        int x = (int) Math.round(BAR_WIDTH * (at / reach));
        graphics.method_25294(x, barY - 1, x + 1, barY + BAR_HEIGHT + 1, 0xFFFFFFFF);
    }

    /** The gap of your last swing, fading out. */
    private static void drawFlash(class_332 graphics, class_310 mc) {
        long age = SpacingTracker.millisSinceLastSwing();
        if (age > FLASH_MS) return;

        double last = SpacingTracker.getLastGap();
        if (Double.isNaN(last)) return;

        int alpha = (int) (255 * (1.0 - (double) age / FLASH_MS));
        if (alpha <= 8) return;

        class_746 self = mc.field_1724;
        double reach = self == null ? 3.0 : CombatReach.attackReach(self);
        int rgb = SpacingData.zoneOf(last, reach).argb & 0x00FFFFFF;

        String text = "hit " + String.format("%.2f", last);
        int w = mc.field_1772.method_1727(text);
        graphics.method_51433(mc.field_1772, text,
            (BAR_WIDTH - w) / 2, -(mc.field_1772.field_2000 + 2), (alpha << 24) | rgb, true);
    }

    /**
     * Re-blits the crosshair tinted by zone — the same trick
     * {@code CombatCrosshairOverlay} uses for its binary in/out-of-range tint, graded
     * across the bands instead. Feedback with nothing extra to read.
     */
    private static void drawGradedCrosshair(class_332 graphics, SpacingData.Zone zone) {
        int x = (graphics.method_51421() - CROSSHAIR_SIZE) / 2;
        int y = (graphics.method_51443() - CROSSHAIR_SIZE) / 2;
        graphics.method_52707(class_10799.field_56883, CROSSHAIR_SPRITE,
            x, y, CROSSHAIR_SIZE, CROSSHAIR_SIZE, zone.argb);
    }

    /**
     * The crosshair target when it's a player, otherwise the nearest player inside
     * {@link SpacingData#NEARBY_RADIUS}. Returns null when nobody is close, which is
     * what keeps the HUD clear outside of fights.
     */
    private static class_1297 pickTarget(class_310 mc, class_746 self) {
        if (mc.field_1692 instanceof class_1657 p && p != self && p.method_5732()) {
            return p;
        }

        class_243 eye = self.method_33571();
        class_1297 best = null;
        double bestSqr = SpacingData.NEARBY_RADIUS * SpacingData.NEARBY_RADIUS;

        for (class_1657 p : mc.field_1687.method_18456()) {
            if (p == self || !p.method_5732() || p.method_7325()) continue;
            double d = CombatReach.gapSqr(eye, p.method_5829());
            if (d < bestSqr) {
                bestSqr = d;
                best = p;
            }
        }
        return best;
    }
}
