package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class SwapSyncScreen extends class_437 {

    private final class_437 parent;

    public SwapSyncScreen(class_437 parent) {
        super(class_2561.method_43470("Swap Sync"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                SwapSyncData.setEnabled(!SwapSyncData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        this.method_37063(new GuardSlider(cx - btnW / 2, cy - 10, btnW, btnH,
                SwapSyncData.getGuardTicks()));

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(SwapSyncData.isEnabled()
            ? "Disable Swap Sync" : "Enable Swap Sync");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);

        boolean on = SwapSyncData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 58, on ? 0x55FF55 : 0xFF5555);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Waits after a weapon swap so the hit uses the new weapon"),
            cx, cy + 46, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Higher = safer on a laggy server, but slower combos"),
            cx, cy + 58, 0xAAAAAA);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class GuardSlider extends class_357 {
        GuardSlider(int x, int y, int w, int h, int initial) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.method_25346();
        }

        private static double normalize(int v) {
            return (double) (v - SwapSyncData.MIN_GUARD_TICKS)
                 / (SwapSyncData.MAX_GUARD_TICKS - SwapSyncData.MIN_GUARD_TICKS);
        }

        private int denormalize() {
            return (int) Math.round(this.field_22753
                * (SwapSyncData.MAX_GUARD_TICKS - SwapSyncData.MIN_GUARD_TICKS)
                + SwapSyncData.MIN_GUARD_TICKS);
        }

        @Override
        protected void method_25346() {
            int t = denormalize();
            this.method_25355(class_2561.method_43470(
                "Wait after swap: " + t + (t == 1 ? " tick" : " ticks")));
        }

        @Override
        protected void method_25344() {
            SwapSyncData.setGuardTicks(denormalize());
        }
    }
}
