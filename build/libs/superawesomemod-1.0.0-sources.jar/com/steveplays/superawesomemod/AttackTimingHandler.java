package com.steveplays.superawesomemod;

import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_640;
import net.minecraft.class_746;

/**
 * Shared attack gate for Mace Timing, Swap Sync and the Stun Slam Optimizer.
 *
 * <p>These only ever <em>suppress</em> a swing that was going to be wasted. Nothing
 * here clicks, queues or replays — you throw every punch, and the gate's whole job is
 * to stop a mistimed one from spending the swing.
 *
 * <p>Suppressing is a real gain rather than a no-op, because {@code startAttack} resets
 * the attack-strength meter whether or not the swing connected. An early click costs
 * you the swing <em>and</em> starts the next one from an empty meter — which is what
 * makes bad hits feel like they come in pairs. Dropping the first keeps your next
 * click at full charge.
 *
 * <p>All three gates are scoped to spear, axe, mace and sword; gating anything else
 * would interfere with mining and building for no benefit.
 */
public final class AttackTimingHandler {

    private enum Weapon { NONE, SPEAR, AXE, MACE, OTHER }

    /** Flat post-swap hold from Swap Sync. */
    private static int swapGuard = 0;
    private static int lastSlot = -1;

    /** Ping-scaled hold from the Stun Slam Optimizer, armed only by a combo swap. */
    private static int comboGuard = 0;
    /** How long the optimizer's charge gate stays armed after a combo swap. */
    private static int comboWindow = 0;
    private static Weapon lastWeapon = Weapon.NONE;

    private AttackTimingHandler() {}

    /** Whether a swing right now should be suppressed. Called from the attack mixin. */
    public static boolean shouldHold(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null) return false;

        class_1799 held = player.method_6047();
        if (!isCombatWeapon(held)) return false;

        if (SwapSyncData.isEnabled() && swapGuard > 0) return true;

        if (SlamOptimizerData.isEnabled()) {
            if (comboGuard > 0) return true;
            // Inside the combo, an uncharged mace hit is the one that ruins the slam.
            if (comboWindow > 0 && held.method_31574(class_1802.field_49814) && !isCharged(player)) return true;
        }

        if (MaceTimingData.isEnabled() && held.method_31574(class_1802.field_49814)) {
            return player.method_7261(0.0f) < MaceTimingData.getMinStrength();
        }

        return false;
    }

    public static void tick(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null) {
            reset();
            return;
        }

        // Slot changes drive Swap Sync. Tracked even while the feature is off, so
        // enabling it mid-game can't inherit a stale slot and arm a phantom guard.
        int slot = player.method_31548().method_67532();
        if (slot != lastSlot) {
            lastSlot = slot;
            swapGuard = SwapSyncData.getGuardTicks();
        } else if (swapGuard > 0) {
            swapGuard--;
        }

        // Weapon changes drive the combo optimizer. Only the two transitions that make
        // up a slam arm it — reaching for an axe to chop wood leaves your clicks alone.
        Weapon weapon = classify(player.method_6047());
        if (weapon != lastWeapon) {
            boolean comboStep = (lastWeapon == Weapon.SPEAR && weapon == Weapon.AXE)
                             || (lastWeapon == Weapon.AXE && weapon == Weapon.MACE);
            if (comboStep) {
                comboGuard = SlamOptimizerData.settleTicksFor(pingOf(client));
                comboWindow = SlamOptimizerData.COMBO_WINDOW_TICKS;
            }
            lastWeapon = weapon;
        } else {
            if (comboGuard > 0) comboGuard--;
            if (comboWindow > 0) comboWindow--;
        }
    }

    /** Our own latency as the server reports it, or 0 when unavailable. */
    private static int pingOf(class_310 client) {
        if (client.field_1724 == null || client.method_1562() == null) return 0;
        class_640 info = client.method_1562().method_2871(client.field_1724.method_5667());
        return info == null ? 0 : info.method_2959();
    }

    private static boolean isCharged(class_746 player) {
        return player.method_7261(0.0f) >= 1.0f;
    }

    private static void reset() {
        swapGuard = 0;
        lastSlot = -1;
        comboGuard = 0;
        comboWindow = 0;
        lastWeapon = Weapon.NONE;
    }

    private static Weapon classify(class_1799 stack) {
        if (stack.method_7960()) return Weapon.NONE;
        if (stack.method_31574(class_1802.field_49814)) return Weapon.MACE;
        if (stack.method_31573(class_3489.field_63257)) return Weapon.SPEAR;
        if (stack.method_31573(class_3489.field_42612)) return Weapon.AXE;
        return Weapon.OTHER;
    }

    private static boolean isCombatWeapon(class_1799 stack) {
        if (stack.method_7960()) return false;
        return stack.method_31574(class_1802.field_49814)
            || stack.method_31573(class_3489.field_63257)
            || stack.method_31573(class_3489.field_42612)
            || stack.method_31573(class_3489.field_42611);
    }
}
