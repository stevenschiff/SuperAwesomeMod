package com.steveplays.superawesomemod;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8791;
import net.minecraft.class_8792;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * A server-side fake player that can hold items and continuously use them
 * (e.g. keep a shield raised). Created via the {@code /npc} commands.
 */
public class FakePlayer extends class_3222 {

    private boolean continuousUseMainHand = false;
    private boolean continuousUseOffHand = false;

    /** How many ticks to wait before re-raising the shield after it gets disabled. */
    private int shieldDisableDuration = 100; // 5 seconds (vanilla default)
    /** Ticks remaining before the shield can be re-raised. */
    private int shieldDisableTicksRemaining = 0;

    private FakePlayer(MinecraftServer server, class_3218 level, GameProfile profile) {
        super(server, level, profile, class_8791.method_53821());
    }

    /**
     * Spawns a fake player at the given position and registers it with the
     * server's {@link net.minecraft.class_3324}.
     * <p>
     * Must be called on the server thread (commands run on the server thread).
     */
    public static FakePlayer spawn(MinecraftServer server, class_3218 level,
                                   String name, double x, double y, double z,
                                   float yaw, float pitch) {

        UUID uuid = UUID.nameUUIDFromBytes(("FakePlayer:" + name).getBytes());
        GameProfile profile = new GameProfile(uuid, name);

        FakePlayer fp = new FakePlayer(server, level, profile);
        fp.method_5808(x, y, z, yaw, pitch);

        FakeClientConnection fakeConn = new FakeClientConnection();
        class_8792 cookie = class_8792.method_53824(profile, false);
        server.method_3760().method_14570(fakeConn, fp, cookie);

        fp.field_13987.method_14372();
        return fp;
    }

    // ------------------------------------------------------------------
    // Continuous item use
    // ------------------------------------------------------------------

    public void setContinuousUse(class_1268 hand, boolean enabled) {
        if (hand == class_1268.field_5808) {
            continuousUseMainHand = enabled;
        } else {
            continuousUseOffHand = enabled;
        }
        if (!enabled && method_6115() && method_6058() == hand) {
            method_6021();
        }
    }

    public boolean isContinuousUse(class_1268 hand) {
        return hand == class_1268.field_5808 ? continuousUseMainHand : continuousUseOffHand;
    }

    // ------------------------------------------------------------------
    // Shield disable delay
    // ------------------------------------------------------------------

    public void setShieldDisableDuration(int ticks) {
        this.shieldDisableDuration = ticks;
    }

    public int getShieldDisableDuration() {
        return shieldDisableDuration;
    }

    @Override
    public void method_6021() {
        // If continuous use is still enabled for this hand, the stop was caused
        // externally (e.g. axe hit disabling the shield), so start the cooldown.
        if (method_6115()) {
            class_1268 hand = method_6058();
            if (isContinuousUse(hand)) {
                shieldDisableTicksRemaining = shieldDisableDuration;
            }
        }
        super.method_6021();
    }

    // ------------------------------------------------------------------
    // Tick
    // ------------------------------------------------------------------

    @Override
    public void method_5773() {
        MinecraftServer srv = this.method_51469().method_8503();
        if (srv != null && srv.method_3780() % 10 == 0) {
            this.field_13987.method_14372();
            this.method_51469().method_14178().method_14096(this);
        }

        try {
            super.method_5773();
            this.method_14226();
        } catch (NullPointerException ignored) {
            // Defensive: some code paths may touch connection state
            // that doesn't fully exist for fake players.
        }

        tickContinuousItemUse();
    }

    private void tickContinuousItemUse() {
        if (shieldDisableTicksRemaining > 0) {
            shieldDisableTicksRemaining--;
            return;
        }
        if (continuousUseMainHand) {
            class_1799 main = method_5998(class_1268.field_5808);
            if (!main.method_7960() && !method_6115()) {
                method_6019(class_1268.field_5808);
            }
        }
        if (continuousUseOffHand && !method_6115()) {
            class_1799 off = method_5998(class_1268.field_5810);
            if (!off.method_7960()) {
                method_6019(class_1268.field_5810);
            }
        }
    }

    @Override
    public void method_6116(class_1304 slot, class_1799 previous, class_1799 stack) {
        // Suppress equipment-change processing while using an item to
        // prevent the use state from being interrupted by entity data sync.
        if (!method_6115()) {
            super.method_6116(slot, previous, stack);
        }
    }

    @Override
    public void method_14231() {
        // Intentionally empty — prevents ServerCommonPacketListenerImpl.onDisconnect()
        // from firing (which in singleplayer could halt the server).
        // FakePlayerManager handles removal via PlayerList.remove() instead.
    }
}
