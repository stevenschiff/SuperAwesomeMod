package com.steveplays.superawesomemod;

import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2680;

/**
 * A loaded schematic placed at a specific world position with optional rotation and mirror.
 */
public final class SchematicPlacement {

    private final Schematic schematic;
    private class_2338 origin;
    private class_2470 rotation;
    private boolean mirror;

    public SchematicPlacement(Schematic schematic, class_2338 origin) {
        this.schematic = schematic;
        this.origin = origin;
        this.rotation = class_2470.field_11467;
        this.mirror = false;
    }

    /**
     * Returns the expected block state at the given world position,
     * applying rotation and mirror transforms.
     */
    public class_2680 getBlockStateAt(class_2338 worldPos) {
        int rx = worldPos.method_10263() - origin.method_10263();
        int ry = worldPos.method_10264() - origin.method_10264();
        int rz = worldPos.method_10260() - origin.method_10260();

        // Reverse rotation to map world coords back to schematic coords
        int[] local = reverseTransform(rx, ry, rz);
        class_2680 state = schematic.getBlockState(local[0], local[1], local[2]);

        if (state.method_26215()) return state;

        // Apply transforms to the block state
        if (mirror) {
            state = state.method_26185(class_2415.field_11301);
        }
        state = state.method_26186(rotation);
        return state;
    }

    /**
     * Whether the given world position falls within this placement's bounds.
     */
    public boolean containsPos(class_2338 worldPos) {
        int rx = worldPos.method_10263() - origin.method_10263();
        int ry = worldPos.method_10264() - origin.method_10264();
        int rz = worldPos.method_10260() - origin.method_10260();

        int[] local = reverseTransform(rx, ry, rz);
        class_2338 min = schematic.getMinPos();
        class_2338 max = schematic.getMaxPos();

        return local[0] >= min.method_10263() && local[0] < max.method_10263()
            && local[1] >= min.method_10264() && local[1] < max.method_10264()
            && local[2] >= min.method_10260() && local[2] < max.method_10260();
    }

    /**
     * Reverses rotation and mirror to convert world-relative coords to schematic coords.
     */
    private int[] reverseTransform(int x, int y, int z) {
        if (mirror) {
            x = -x;
        }
        // Reverse the rotation
        return switch (rotation) {
            case field_11467 -> new int[]{x, y, z};
            case field_11463 -> new int[]{z, y, -x};
            case field_11464 -> new int[]{-x, y, -z};
            case field_11465 -> new int[]{-z, y, x};
        };
    }

    public class_2338 getMin() {
        class_2338 sMin = schematic.getMinPos();
        class_2338 sMax = schematic.getMaxPos();
        // Transform all 4 horizontal corners and find the actual min
        int[][] corners = {
            forwardTransform(sMin.method_10263(), sMin.method_10264(), sMin.method_10260()),
            forwardTransform(sMax.method_10263() - 1, sMin.method_10264(), sMin.method_10260()),
            forwardTransform(sMin.method_10263(), sMin.method_10264(), sMax.method_10260() - 1),
            forwardTransform(sMax.method_10263() - 1, sMin.method_10264(), sMax.method_10260() - 1)
        };
        int minX = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        for (int[] c : corners) {
            minX = Math.min(minX, c[0]);
            minZ = Math.min(minZ, c[2]);
        }
        return origin.method_10069(minX, sMin.method_10264(), minZ);
    }

    public class_2338 getMax() {
        class_2338 sMin = schematic.getMinPos();
        class_2338 sMax = schematic.getMaxPos();
        int[][] corners = {
            forwardTransform(sMin.method_10263(), sMax.method_10264(), sMin.method_10260()),
            forwardTransform(sMax.method_10263() - 1, sMax.method_10264(), sMin.method_10260()),
            forwardTransform(sMin.method_10263(), sMax.method_10264(), sMax.method_10260() - 1),
            forwardTransform(sMax.method_10263() - 1, sMax.method_10264(), sMax.method_10260() - 1)
        };
        int maxX = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        int maxY = corners[0][1];
        for (int[] c : corners) {
            maxX = Math.max(maxX, c[0]);
            maxZ = Math.max(maxZ, c[2]);
        }
        // +1 because getMax is exclusive
        return origin.method_10069(maxX + 1, maxY, maxZ + 1);
    }

    private int[] forwardTransform(int x, int y, int z) {
        int rx, rz;
        switch (rotation) {
            case field_11463 -> { rx = -z; rz = x; }
            case field_11464 -> { rx = -x; rz = -z; }
            case field_11465 -> { rx = z; rz = -x; }
            default -> { rx = x; rz = z; }
        }
        if (mirror) {
            rx = -rx;
        }
        return new int[]{rx, y, rz};
    }

    // Getters and setters
    public Schematic getSchematic() { return schematic; }
    public class_2338 getOrigin() { return origin; }
    public void setOrigin(class_2338 origin) { this.origin = origin; }

    public class_2470 getRotation() { return rotation; }
    public void setRotation(class_2470 rotation) { this.rotation = rotation; }
    public void cycleRotation() {
        this.rotation = switch (rotation) {
            case field_11467 -> class_2470.field_11463;
            case field_11463 -> class_2470.field_11464;
            case field_11464 -> class_2470.field_11465;
            case field_11465 -> class_2470.field_11467;
        };
    }

    public boolean isMirror() { return mirror; }
    public void setMirror(boolean mirror) { this.mirror = mirror; }
    public void toggleMirror() { this.mirror = !this.mirror; }

    public String getRotationName() {
        return switch (rotation) {
            case field_11467 -> "0°";
            case field_11463 -> "90°";
            case field_11464 -> "180°";
            case field_11465 -> "270°";
        };
    }
}
