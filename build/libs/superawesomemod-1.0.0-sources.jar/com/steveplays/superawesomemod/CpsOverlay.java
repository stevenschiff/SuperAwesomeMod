package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

@SuppressWarnings("deprecation")
public final class CpsOverlay {

    private CpsOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(CpsOverlay::onHudRender);
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter) {
        if (!CpsData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842 || mc.field_1724 == null) return;

        int width  = graphics.method_51421();
        int height = graphics.method_51443();

        int leftCps  = CpsData.getLeftCps();
        int rightCps = CpsData.getRightCps();

        String leftText  = String.valueOf(leftCps);
        String separator = " | ";
        String rightText = String.valueOf(rightCps);
        String cpsLabel  = " CPS";
        String fullText  = leftText + separator + rightText + cpsLabel;

        float scale = CpsData.getScale() / 5.0f; // scale 5 = 1.0x

        // Position: right of the hotbar. Hotbar right edge is at width/2 + 91.
        int hotbarRight = width / 2 + 91;
        int fullTextWidth = mc.field_1772.method_1727(fullText);

        // Compute box dimensions in scaled space
        int padding = 4;
        int boxWidth  = fullTextWidth + padding * 2;
        int boxHeight = mc.field_1772.field_2000 + padding * 2;

        // Anchor: right of hotbar, vertically centered on hotbar row
        int anchorX = (int)(hotbarRight + 8);
        int anchorY = (int)(height - 10 - (boxHeight * scale) / 2);

        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate((float) anchorX, (float) anchorY);
        graphics.method_51448().scale(scale, scale);

        // Pure black background
        graphics.method_25294(0, 0, boxWidth, boxHeight, 0xFF000000);

        // Draw text centered in box
        int textX = padding;
        int textY = padding;
        graphics.method_51433(mc.field_1772, fullText, textX, textY, 0xFFFFFFFF, false);

        graphics.method_51448().popMatrix();
    }
}
