package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

@SuppressWarnings("deprecation")
public final class CpsOverlay {

    private CpsOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(CpsOverlay::onHudRender);
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter) {
        if (!CpsData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842 || mc.field_1724 == null) return;

        int width  = graphics.method_51421();
        int height = graphics.method_51443();

        int leftCps  = CpsData.getLeftCps();
        int rightCps = CpsData.getRightCps();

        String text = leftCps + " | " + rightCps + " CPS";

        float scale = CpsData.getScale() / 5.0f; // scale 5 = 1.0x

        // Position: right of the hotbar. Hotbar right edge is at width/2 + 91.
        int hotbarRight = width / 2 + 91;
        int textWidth = mc.field_1772.method_1727(text);

        graphics.method_51448().pushMatrix();
        // Anchor point: right of hotbar, vertically centered on hotbar row.
        float anchorX = hotbarRight + 8;
        float anchorY = height - 14;
        graphics.method_51448().translate(anchorX, anchorY);
        graphics.method_51448().scale(scale, scale);

        // Background box
        int bgWidth  = textWidth + 6;
        int bgHeight = 12;
        graphics.method_25294(-3, -2, bgWidth - 3, bgHeight - 2, 0x80000000);

        // Text
        graphics.method_51433(mc.field_1772, text, 0, 0, 0xFFFFFF, true);

        graphics.method_51448().popMatrix();
    }
}
