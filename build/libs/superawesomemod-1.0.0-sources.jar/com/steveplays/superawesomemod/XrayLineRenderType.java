package com.steveplays.superawesomemod;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_1921;

public final class XrayLineRenderType {

    private static final RenderPipeline PIPELINE = RenderPipeline.builder(class_10799.field_56859)
        .withLocation("superawesomemod:lines_xray")
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .build();

    public static final class_1921 LINES_XRAY = class_1921.method_75940(
        "superawesomemod:lines_xray",
        class_12247.method_75927(PIPELINE)
            .method_75930(class_12245.field_63976)
            .method_75931(class_12246.field_63983)
            .method_75938()
    );

    private XrayLineRenderType() {}

    public static void touch() {}
}
