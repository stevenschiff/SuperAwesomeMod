package com.steveplays.superawesomemod;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;

/**
 * Auto Totem: keeps a Totem of Undying in the offhand.
 *
 * <p>Uses one {@link class_1713#field_7791} click with button 40 — the offhand-swap button
 * the vanilla F key uses — so a refill is a single ordinary container click rather
 * than a pickup/place/put-back dance with a live cursor. Nothing here is a custom
 * packet; it's the same message the client sends when you press F on a slot.
 */
public final class AutoTotemHandler {

    /** Button number that {@code AbstractContainerMenu} treats as "swap with offhand". */
    private static final int OFFHAND_SWAP_BUTTON = 40;

    private static int cooldown = 0;

    private AutoTotemHandler() {}

    public static void tick(class_310 client) {
        if (!AutoTotemData.isEnabled()) {
            cooldown = 0;
            return;
        }

        class_1657 player = client.field_1724;
        if (player == null || client.field_1761 == null) return;

        // Only with no screen open: clicking container 0 while a chest is open would
        // desync the menu the server thinks we have in front of us.
        if (client.field_1755 != null) return;

        if (cooldown > 0) {
            cooldown--;
            return;
        }

        if (player.method_6079().method_31574(class_1802.field_8288)) return;

        int menuSlot = findTotemMenuSlot(player.method_31548());
        if (menuSlot < 0) return;

        client.field_1761.method_2906(
            player.field_7498.field_7763, menuSlot,
            OFFHAND_SWAP_BUTTON, class_1713.field_7791, player);

        cooldown = AutoTotemData.getDelayTicks();
    }

    /**
     * Finds a totem and returns its slot number in the player's inventory menu, or -1.
     * The menu numbers the hotbar after the main inventory, so the two ranges convert
     * differently.
     */
    private static int findTotemMenuSlot(class_1661 inventory) {
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_31574(class_1802.field_8288)) continue;

            if (i < class_1661.method_7368()) {
                return class_1723.field_30810 + i;
            }
            if (i < class_1723.field_30809) {
                return i;
            }
        }
        return -1;
    }
}
