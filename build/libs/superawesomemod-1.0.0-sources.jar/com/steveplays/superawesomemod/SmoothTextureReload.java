package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3300;

/**
 * Drops the interpolation cache whenever resources reload.
 *
 * <p>The cache is keyed on {@code SpriteContents} identity and holds a scratch image per
 * sprite. A reload builds new sprites and closes the old ones, so without this the cache
 * would keep references to freed native memory and grow on every pack switch or F3+T.
 */
public final class SmoothTextureReload implements SimpleSynchronousResourceReloadListener {

    private static final class_2960 ID =
        class_2960.method_60655("superawesomemod", "smooth_textures");

    private SmoothTextureReload() {}

    public static void register() {
        ResourceManagerHelper.get(class_3264.field_14188)
            .registerReloadListener(new SmoothTextureReload());
    }

    @Override
    public class_2960 getFabricId() {
        return ID;
    }

    @Override
    public void method_14491(class_3300 manager) {
        SmoothTextureHandler.clear();
    }
}
