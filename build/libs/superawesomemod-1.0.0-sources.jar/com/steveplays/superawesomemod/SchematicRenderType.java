package com.steveplays.superawesomemod;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_2960;

/**
 * Custom render types for the schematic overlay.
 * Ghost mode uses filled quads; verifier/outline mode uses lines.
 */
public final class SchematicRenderType {

    // Translucent filled quads for ghost block overlay
    private static final RenderPipeline GHOST_PIPELINE = RenderPipeline.builder(class_10799.field_56860)
        .withLocation(class_2960.method_60655("superawesomemod", "schematic_ghost"))
        .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
        .withCull(false)
        .build();

    public static final class_1921 SCHEMATIC_GHOST = class_1921.method_75940(
        "schematic_ghost",
        class_12247.method_75927(GHOST_PIPELINE).method_75938()
    );

    // Wireframe lines for verifier / outline mode
    private static final RenderPipeline OUTLINE_PIPELINE = RenderPipeline.builder(class_10799.field_56859)
        .withLocation(class_2960.method_60655("superawesomemod", "schematic_outline"))
        .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
        .build();

    public static final class_1921 SCHEMATIC_OUTLINE = class_1921.method_75940(
        "schematic_outline",
        class_12247.method_75927(OUTLINE_PIPELINE)
            .method_75930(class_12245.field_63976)
            .method_75931(class_12246.field_63983)
            .method_75938()
    );

    private SchematicRenderType() {}

    /** Force class loading so render pipelines are registered. */
    public static void touch() {}
}
