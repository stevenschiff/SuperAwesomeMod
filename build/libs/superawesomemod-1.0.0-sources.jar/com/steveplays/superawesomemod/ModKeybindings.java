package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ModKeybindings {

    // Custom category shown in Options → Controls
    public static final class_304.class_11900 CATEGORY = class_304.class_11900.method_74698(
        class_2960.method_60655("superawesomemod", "mod_keys")
    );

    public static class_304 openMenu;
    public static class_304 zoom;

    public static void register() {
        openMenu = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.superawesomemod.open_menu",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_G,
            CATEGORY
        ));
        zoom = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.superawesomemod.zoom",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_X,
            CATEGORY
        ));
    }
}
