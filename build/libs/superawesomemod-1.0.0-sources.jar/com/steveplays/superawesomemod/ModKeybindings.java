package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class ModKeybindings {

    // Custom category shown in Options → Controls
    public static final class_304.class_11900 CATEGORY = class_304.class_11900.method_74698(
        class_2960.method_60655("superawesomemod", "mod_keys")
    );

    public static class_304 openMenu;
    public static class_304 zoom;
    public static class_304 miniMapToggle;
    public static class_304 schematicLayerUp;
    public static class_304 schematicLayerDown;
    public static class_304 schematicToggle;
    public static class_304 boatFlyDown;

    public static void register() {
        openMenu = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.superawesomemod.open_menu",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_G,
            CATEGORY
        ));
        zoom = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.superawesomemod.zoom",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_X,
            CATEGORY
        ));
        miniMapToggle = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.superawesomemod.minimap_toggle",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_C,
            CATEGORY
        ));
        schematicLayerUp = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.superawesomemod.schematic_layer_up",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_PAGE_UP,
            CATEGORY
        ));
        schematicLayerDown = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.superawesomemod.schematic_layer_down",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_PAGE_DOWN,
            CATEGORY
        ));
        schematicToggle = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.superawesomemod.schematic_toggle",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_UNKNOWN,
            CATEGORY
        ));
        // Right Shift, not sneak — sneak leaves the boat.
        boatFlyDown = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.superawesomemod.boat_fly_down",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            CATEGORY
        ));
    }
}
