package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class CpsScreen extends class_437 {

    private final class_437 parent;

    public CpsScreen(class_437 parent) {
        super(class_2561.method_43470("CPS Counter"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                CpsData.setEnabled(!CpsData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 46, btnW, btnH).method_46431());

        this.method_37063(new ScaleSlider(
            cx - btnW / 2, cy - 20, btnW, btnH,
            CpsData.getScale()
        ));

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 14, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(CpsData.isEnabled()
            ? "CPS Counter: Enabled" : "CPS Counter: Disabled");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Shows left & right click CPS next to the hotbar"),
            cx, cy - 58, 0xAAAAAA);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class ScaleSlider extends class_357 {
        ScaleSlider(int x, int y, int w, int h, int initialScale) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initialScale));
            this.method_25346();
        }

        private static double normalize(int scale) {
            return (double) (scale - 1) / 9.0;
        }

        @Override
        protected void method_25346() {
            int s = (int) Math.round(this.field_22753 * 9.0 + 1.0);
            this.method_25355(class_2561.method_43470("Size: " + s));
        }

        @Override
        protected void method_25344() {
            int s = (int) Math.round(this.field_22753 * 9.0 + 1.0);
            CpsData.setScale(s);
        }
    }
}
