package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class CpsScreen extends GabeOptionScreen {

    public CpsScreen(class_437 parent) {
        super(parent, "CPS Counter");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", CpsData::isEnabled, CpsData::setEnabled);
        slider("Size", 1, 10, CpsData::getScale, CpsData::setScale, String::valueOf);
        slider("Offset", 0, 100, CpsData::getOffset, CpsData::setOffset, String::valueOf);
    }
}
