package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class AntiHungerScreen extends class_437 {

    private final class_437 parent;

    public AntiHungerScreen(class_437 parent) {
        super(class_2561.method_43470("Anti-Hunger"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                AntiHungerData.setEnabled(!AntiHungerData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 64, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            sub("Walk Report", AntiHungerData.isWalkReport()),
            btn -> {
                AntiHungerData.setWalkReport(!AntiHungerData.isWalkReport());
                btn.method_25355(sub("Walk Report", AntiHungerData.isWalkReport()));
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            sub("Freeze Hunger", AntiHungerData.isFreezeHunger()),
            btn -> {
                AntiHungerData.setFreezeHunger(!AntiHungerData.isFreezeHunger());
                btn.method_25355(sub("Freeze Hunger", AntiHungerData.isFreezeHunger()));
            }
        ).method_46434(cx - btnW / 2, cy - 16, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            sub("Pause near players", AntiHungerData.isPauseNearPlayers()),
            btn -> {
                AntiHungerData.setPauseNearPlayers(!AntiHungerData.isPauseNearPlayers());
                btn.method_25355(sub("Pause near players", AntiHungerData.isPauseNearPlayers()));
            }
        ).method_46434(cx - btnW / 2, cy + 8, btnW, btnH).method_46431());

        this.method_37063(new RadiusSlider(cx - btnW / 2, cy + 32, btnW, btnH,
                AntiHungerData.getPauseRadius()));

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 56, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(AntiHungerData.isEnabled() ? "Disable Anti-Hunger" : "Enable Anti-Hunger");
    }

    private static class_2561 sub(String name, boolean on) {
        return class_2561.method_43470(name + ": " + (on ? "On" : "Off"));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 94, 0xFFFFFF);

        boolean on = AntiHungerData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 82, on ? 0x55FF55 : 0xFF5555);

        boolean host = this.field_22787.method_1496();

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Walk Report: sprint costs no hunger - works on any server"),
            cx, cy + 82, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470(host
                ? "Freeze Hunger: active - stops all hunger including attacking"
                : "Freeze Hunger: not active here - worlds you host only"),
            cx, cy + 94, host ? 0xAAAAAA : 0xFFAA00);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Sprint speed while reporting a walk is what anticheat looks for"),
            cx, cy + 106, 0xFF5555);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class RadiusSlider extends class_357 {
        RadiusSlider(int x, int y, int w, int h, int initial) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.method_25346();
        }

        private static double normalize(int v) {
            return (double) (v - AntiHungerData.MIN_PAUSE_RADIUS)
                 / (AntiHungerData.MAX_PAUSE_RADIUS - AntiHungerData.MIN_PAUSE_RADIUS);
        }

        private int denormalize() {
            return (int) Math.round(this.field_22753
                * (AntiHungerData.MAX_PAUSE_RADIUS - AntiHungerData.MIN_PAUSE_RADIUS)
                + AntiHungerData.MIN_PAUSE_RADIUS);
        }

        @Override
        protected void method_25346() {
            this.method_25355(class_2561.method_43470("Pause radius: " + denormalize() + " blocks"));
        }

        @Override
        protected void method_25344() {
            AntiHungerData.setPauseRadius(denormalize());
        }
    }
}
