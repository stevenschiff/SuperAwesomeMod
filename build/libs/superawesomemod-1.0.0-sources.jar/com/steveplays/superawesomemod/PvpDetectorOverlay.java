package com.steveplays.superawesomemod;

import java.util.List;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/**
 * Top-right HUD listing tracked players and their suspicion stats.
 *
 * Layout per row:  [name]  [ping]  H:[hits]  Max:[reach]  [BAND]
 * Suspicion band is colored:  NONE=gray  LOW=yellow  MED=orange  HIGH=red
 */
@SuppressWarnings("deprecation")
public final class PvpDetectorOverlay {

    private static final int ROW_HEIGHT = 11;
    private static final int PADDING    = 4;
    private static final int MAX_ROWS   = 6;

    private static final int COL_NONE = 0xFF888888;
    private static final int COL_LOW  = 0xFFE0C040;
    private static final int COL_MED  = 0xFFE08020;
    private static final int COL_HIGH = 0xFFE03030;
    private static final int COL_TXT  = 0xFFE0E0E0;
    private static final int COL_BG   = 0x80000000;
    private static final int COL_PING_OK   = 0xFF60D060;
    private static final int COL_PING_WARN = 0xFFE0C040;
    private static final int COL_PING_BAD  = 0xFFE03030;

    private PvpDetectorOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(PvpDetectorOverlay::onHudRender);
    }

    private static void onHudRender(class_332 g, class_9779 tickCounter) {
        if (!PvpDetectorData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;

        PvpDetectorTracker.tick();
        List<PvpDetectorTracker.PlayerStats> rows = PvpDetectorTracker.snapshot();
        if (rows.isEmpty()) {
            drawIdle(g, mc.field_1772);
            return;
        }
        if (rows.size() > MAX_ROWS) rows = rows.subList(0, MAX_ROWS);

        class_327 font = mc.field_1772;
        int titleW = font.method_1727("PvP Watch");
        int width  = Math.max(titleW, longestRowWidth(font, rows)) + PADDING * 2;
        int height = (rows.size() + 1) * ROW_HEIGHT + PADDING * 2;

        int x = g.method_51421() - width - PADDING;
        int y = PADDING;

        // Background panel.
        g.method_25294(x, y, x + width, y + height, COL_BG);

        // Title row.
        g.method_51439(font, class_2561.method_43470("PvP Watch"), x + PADDING, y + PADDING, COL_TXT, false);

        int rowY = y + PADDING + ROW_HEIGHT;
        for (PvpDetectorTracker.PlayerStats st : rows) {
            String row = formatRow(st);
            int bandColor = bandColor(st.band());
            g.method_51439(font, class_2561.method_43470(row), x + PADDING, rowY, COL_TXT, false);

            // Re-draw the trailing band token in band-color so it pops.
            String badge = " " + st.band().name();
            int badgeX = x + PADDING + font.method_1727(row) - font.method_1727(badge);
            g.method_51439(font, class_2561.method_43470(badge), badgeX, rowY, bandColor, false);

            // Recolor the ping field.
            int pingColor = pingColor(st.pingMs);
            String pingTok = " " + (st.pingMs < 0 ? "?" : st.pingMs) + "ms";
            int pingX = x + PADDING + font.method_1727(st.name) + font.method_1727(" ");
            g.method_51439(font, class_2561.method_43470(pingTok.trim()), pingX, rowY, pingColor, false);

            rowY += ROW_HEIGHT;
        }
    }

    private static String formatRow(PvpDetectorTracker.PlayerStats st) {
        String ping = st.pingMs < 0 ? "?ms" : (st.pingMs + "ms");
        return String.format("%s %s H:%d Max:%.1f %s",
            st.name,
            ping,
            st.hitCount(),
            st.maxReach(),
            st.band().name());
    }

    private static int longestRowWidth(class_327 font, List<PvpDetectorTracker.PlayerStats> rows) {
        int max = 0;
        for (PvpDetectorTracker.PlayerStats st : rows) {
            int w = font.method_1727(formatRow(st));
            if (w > max) max = w;
        }
        return max;
    }

    private static int bandColor(PvpDetectorTracker.Band band) {
        return switch (band) {
            case HIGH -> COL_HIGH;
            case MED  -> COL_MED;
            case LOW  -> COL_LOW;
            case NONE -> COL_NONE;
        };
    }

    private static int pingColor(int ms) {
        if (ms < 0)    return COL_NONE;
        if (ms < 100)  return COL_PING_OK;
        if (ms < 250)  return COL_PING_WARN;
        return COL_PING_BAD;
    }

    private static void drawIdle(class_332 g, class_327 font) {
        int width  = font.method_1727("PvP Watch — no observed hits") + PADDING * 2;
        int height = ROW_HEIGHT + PADDING * 2;
        int x = g.method_51421() - width - PADDING;
        int y = PADDING;
        g.method_25294(x, y, x + width, y + height, COL_BG);
        g.method_51439(font,
            class_2561.method_43470("PvP Watch — no observed hits"),
            x + PADDING, y + PADDING, COL_NONE, false);
    }
}
