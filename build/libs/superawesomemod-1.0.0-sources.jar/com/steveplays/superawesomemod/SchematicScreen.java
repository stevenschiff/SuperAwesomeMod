package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Main settings screen for the Schematics feature.
 * Follows the same pattern as {@link MiniMapScreen}.
 */
public class SchematicScreen extends class_437 {

    private final class_437 parent;

    private static final int BTN_W = 200;
    private static final int BTN_H = 20;

    public SchematicScreen(class_437 parent) {
        super(class_2561.method_43470("Schematics"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 84;
        int gap = 24;

        // Master toggle
        this.method_37063(class_4185.method_46430(
            enabledLabel(),
            btn -> {
                SchematicData.setEnabled(!SchematicData.isEnabled());
                btn.method_25355(enabledLabel());
            }
        ).method_46434(cx - BTN_W / 2, topY, BTN_W, BTN_H).method_46431());

        // Browse Schematics
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Browse Schematics"),
            btn -> this.field_22787.method_1507(new SchematicBrowserScreen(this))
        ).method_46434(cx - BTN_W / 2, topY + gap, BTN_W, BTN_H).method_46431());

        // Position / Rotate
        class_4185 posBtn = class_4185.method_46430(
            class_2561.method_43470("Position / Rotate"),
            btn -> this.field_22787.method_1507(new SchematicPositionScreen(this))
        ).method_46434(cx - BTN_W / 2, topY + gap * 2, BTN_W, BTN_H).method_46431();
        posBtn.field_22763 = SchematicData.getCurrentPlacement() != null;
        this.method_37063(posBtn);

        // Material List
        class_4185 matBtn = class_4185.method_46430(
            class_2561.method_43470("Material List"),
            btn -> this.field_22787.method_1507(new SchematicMaterialListScreen(this))
        ).method_46434(cx - BTN_W / 2, topY + gap * 3, BTN_W, BTN_H).method_46431();
        matBtn.field_22763 = SchematicData.getCurrentPlacement() != null;
        this.method_37063(matBtn);

        // Render Mode cycle
        this.method_37063(class_4185.method_46430(
            renderModeLabel(),
            btn -> {
                SchematicData.cycleRenderMode();
                btn.method_25355(renderModeLabel());
            }
        ).method_46434(cx - BTN_W / 2, topY + gap * 4, BTN_W, BTN_H).method_46431());

        // Layer Mode toggle
        this.method_37063(class_4185.method_46430(
            layerModeLabel(),
            btn -> {
                SchematicData.setLayerMode(!SchematicData.isLayerMode());
                btn.method_25355(layerModeLabel());
            }
        ).method_46434(cx - BTN_W / 2, topY + gap * 5, BTN_W, BTN_H).method_46431());

        // Ghost Alpha cycle
        this.method_37063(class_4185.method_46430(
            alphaLabel(),
            btn -> {
                SchematicData.cycleGhostAlpha();
                btn.method_25355(alphaLabel());
            }
        ).method_46434(cx - BTN_W / 2, topY + gap * 6, BTN_W, BTN_H).method_46431());

        // Easy Place toggle
        this.method_37063(class_4185.method_46430(
            easyPlaceLabel(),
            btn -> {
                SchematicData.setEasyPlaceEnabled(!SchematicData.isEasyPlaceEnabled());
                btn.method_25355(easyPlaceLabel());
                this.method_41843();
            }
        ).method_46434(cx - BTN_W / 2, topY + gap * 7, BTN_W, BTN_H).method_46431());

        // Allow on Server toggle (greyed out when Easy Place is off)
        class_4185 serverBtn = class_4185.method_46430(
            allowOnServerLabel(),
            btn -> {
                SchematicData.setEasyPlaceAllowOnServer(!SchematicData.isEasyPlaceAllowOnServer());
                btn.method_25355(allowOnServerLabel());
            }
        ).method_46434(cx - BTN_W / 2, topY + gap * 8, BTN_W, BTN_H).method_46431();
        serverBtn.field_22763 = SchematicData.isEasyPlaceEnabled();
        this.method_37063(serverBtn);

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, topY + gap * 9 + 8, 100, BTN_H).method_46431());
    }

    private class_2561 enabledLabel() {
        return class_2561.method_43470(SchematicData.isEnabled()
            ? "Schematics: Enabled" : "Schematics: Disabled");
    }

    private class_2561 renderModeLabel() {
        return class_2561.method_43470("Render Mode: " + SchematicData.getRenderModeName());
    }

    private class_2561 layerModeLabel() {
        return class_2561.method_43470(SchematicData.isLayerMode()
            ? "Layer Mode: On" : "Layer Mode: Off");
    }

    private class_2561 alphaLabel() {
        return class_2561.method_43470("Ghost Alpha: " + String.format("%.1f", SchematicData.getGhostAlpha()));
    }

    private class_2561 easyPlaceLabel() {
        return class_2561.method_43470(SchematicData.isEasyPlaceEnabled()
            ? "Easy Place: On" : "Easy Place: Off");
    }

    private class_2561 allowOnServerLabel() {
        return class_2561.method_43470(SchematicData.isEasyPlaceAllowOnServer()
            ? "Allow on Server: On" : "Allow on Server: Off");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 84;

        graphics.method_27534(this.field_22793, this.field_22785, cx, topY - 16, 0xFFFFFF);

        SchematicPlacement p = SchematicData.getCurrentPlacement();
        if (p != null) {
            graphics.method_27534(this.field_22793,
                class_2561.method_43470("Loaded: " + p.getSchematic().getName()),
                cx, topY - 6, 0xAAAAAA);
        }

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
