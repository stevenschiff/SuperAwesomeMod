package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class StunSlamScreen extends class_437 {

    private final class_437 parent;

    public StunSlamScreen(class_437 parent) {
        super(class_2561.method_43470("Stun Slam"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        // Toggle on/off
        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                StunSlamData.setEnabled(!StunSlamData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 52, btnW, btnH).method_46431());

        // Mode
        this.method_37063(class_4185.method_46430(
            modeLabel(),
            btn -> {
                StunSlamData.cycleMode();
                btn.method_25355(modeLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 28, btnW, btnH).method_46431());

        // Click counts
        this.method_37063(new ClickSlider(cx - btnW / 2, cy - 4, btnW, btnH,
                "Axe clicks", StunSlamData.getAxeClicks(), StunSlamData::setAxeClicks));
        this.method_37063(new ClickSlider(cx - btnW / 2, cy + 20, btnW, btnH,
                "Mace clicks", StunSlamData.getMaceClicks(), StunSlamData::setMaceClicks));

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 46, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(StunSlamData.isEnabled() ? "Disable Stun Slam" : "Enable Stun Slam");
    }

    private class_2561 modeLabel() {
        return class_2561.method_43470("Mode: " + StunSlamData.getModeName());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 82, 0xFFFFFF);

        boolean on = StunSlamData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 70, on ? 0x55FF55 : 0xFF5555);

        String hint = StunSlamData.getMode() == StunSlamData.Mode.SWAP_ASSIST
            ? "Clicks fire on spear -> axe and axe -> mace only"
            : "Press the Stun Slam keybind to run the whole combo";
        graphics.method_27534(this.field_22793, class_2561.method_43470(hint), cx, cy + 72, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Clicks are 1 tick apart - the 2nd mace hit is stun, not damage"),
            cx, cy + 84, 0xFFAA00);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class ClickSlider extends class_357 {
        private final String label;
        private final java.util.function.IntConsumer sink;

        ClickSlider(int x, int y, int w, int h, String label, int initial,
                    java.util.function.IntConsumer sink) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.label = label;
            this.sink = sink;
            this.method_25346();
        }

        private static double normalize(int v) {
            return (double) (v - StunSlamData.MIN_CLICKS)
                 / (StunSlamData.MAX_CLICKS - StunSlamData.MIN_CLICKS);
        }

        private int denormalize() {
            return (int) Math.round(this.field_22753
                * (StunSlamData.MAX_CLICKS - StunSlamData.MIN_CLICKS) + StunSlamData.MIN_CLICKS);
        }

        @Override
        protected void method_25346() {
            // label is null on the super() call that runs before the field is assigned
            if (this.label == null) return;
            this.method_25355(class_2561.method_43470(this.label + ": " + denormalize()));
        }

        @Override
        protected void method_25344() {
            if (this.sink == null) return;
            this.sink.accept(denormalize());
        }
    }
}
