package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public final class KeystrokesOverlay {

    private static final int KEY_SIZE = 22;
    private static final int GAP     = 2;

    // Colors
    private static final int BG_PRESSED   = 0xC0CCCCCC; // slightly darker white
    private static final int BG_RELEASED  = 0xC0000000; // black
    private static final int TEXT_COLOR   = 0xFFFFFFFF;  // white text

    private KeystrokesOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(KeystrokesOverlay::onHudRender);
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter) {
        if (!KeystrokesData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842 || mc.field_1724 == null) return;

        int width = graphics.method_51421();

        // Top-right corner with some padding
        int baseX = width - 3 * (KEY_SIZE + GAP) - 6;
        int baseY = 6;

        boolean w     = mc.field_1690.field_1894.method_1434();
        boolean a     = mc.field_1690.field_1913.method_1434();
        boolean s     = mc.field_1690.field_1881.method_1434();
        boolean d     = mc.field_1690.field_1849.method_1434();
        boolean space = mc.field_1690.field_1903.method_1434();

        // Row 0: W (centered)
        drawKey(graphics, mc, "W", baseX + KEY_SIZE + GAP, baseY, w);

        // Row 1: A S D
        int row1Y = baseY + KEY_SIZE + GAP;
        drawKey(graphics, mc, "A", baseX, row1Y, a);
        drawKey(graphics, mc, "S", baseX + KEY_SIZE + GAP, row1Y, s);
        drawKey(graphics, mc, "D", baseX + 2 * (KEY_SIZE + GAP), row1Y, d);

        // Row 2: Spacebar (full width)
        int row2Y = row1Y + KEY_SIZE + GAP;
        int spaceWidth = 3 * KEY_SIZE + 2 * GAP;
        int bg = space ? BG_PRESSED : BG_RELEASED;
        graphics.method_25294(baseX, row2Y, baseX + spaceWidth, row2Y + KEY_SIZE, bg);
        String spaceLabel = "\u2014"; // em dash to represent spacebar
        int textW = mc.field_1772.method_1727(spaceLabel);
        graphics.method_51433(mc.field_1772, spaceLabel,
            baseX + (spaceWidth - textW) / 2,
            row2Y + (KEY_SIZE - 8) / 2,
            TEXT_COLOR, true);
    }

    private static void drawKey(class_332 graphics, class_310 mc,
                                String label, int x, int y, boolean pressed) {
        int bg = pressed ? BG_PRESSED : BG_RELEASED;
        graphics.method_25294(x, y, x + KEY_SIZE, y + KEY_SIZE, bg);
        int textW = mc.field_1772.method_1727(label);
        graphics.method_51433(mc.field_1772, label,
            x + (KEY_SIZE - textW) / 2,
            y + (KEY_SIZE - 8) / 2,
            TEXT_COLOR, true);
    }
}
