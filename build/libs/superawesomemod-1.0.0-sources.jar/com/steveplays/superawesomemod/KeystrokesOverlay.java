package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

@SuppressWarnings("deprecation")
public final class KeystrokesOverlay {

    private static final int BASE_KEY_SIZE = 22;
    private static final int BASE_GAP     = 2;

    // Colors
    private static final int BG_PRESSED   = 0xC0CCCCCC; // slightly darker white
    private static final int BG_RELEASED  = 0xC0000000; // black
    private static final int TEXT_COLOR   = 0xFFFFFFFF;  // white text

    private KeystrokesOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(KeystrokesOverlay::onHudRender);
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter) {
        if (!KeystrokesData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842 || mc.field_1724 == null) return;

        int screenWidth  = graphics.method_51421();
        int screenHeight = graphics.method_51443();
        float scale = KeystrokesData.getScale() / 5.0f; // scale 5 = 1.0x

        int keySize = BASE_KEY_SIZE;
        int gap     = BASE_GAP;

        // Total widget size in unscaled coords
        int widgetW = 3 * keySize + 2 * gap;
        int widgetH = 3 * keySize + 2 * gap; // 3 rows: W, ASD, Space

        // Compute anchor based on corner
        int corner = KeystrokesData.getCorner();
        int padding = 6;
        float anchorX, anchorY;
        switch (corner) {
            case 0 -> { // Top-Left
                anchorX = padding;
                anchorY = padding;
            }
            case 2 -> { // Bottom-Left
                anchorX = padding;
                anchorY = screenHeight - widgetH * scale - padding;
            }
            case 3 -> { // Bottom-Right
                anchorX = screenWidth - widgetW * scale - padding;
                anchorY = screenHeight - widgetH * scale - padding;
            }
            default -> { // 1 = Top-Right
                anchorX = screenWidth - widgetW * scale - padding;
                anchorY = padding;
            }
        }

        boolean w     = mc.field_1690.field_1894.method_1434();
        boolean a     = mc.field_1690.field_1913.method_1434();
        boolean s     = mc.field_1690.field_1881.method_1434();
        boolean d     = mc.field_1690.field_1849.method_1434();
        boolean space = mc.field_1690.field_1903.method_1434();

        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate(anchorX, anchorY);
        graphics.method_51448().scale(scale, scale);

        // Row 0: W (centered)
        drawKey(graphics, mc, "W", keySize + gap, 0, keySize, w);

        // Row 1: A S D
        int row1Y = keySize + gap;
        drawKey(graphics, mc, "A", 0, row1Y, keySize, a);
        drawKey(graphics, mc, "S", keySize + gap, row1Y, keySize, s);
        drawKey(graphics, mc, "D", 2 * (keySize + gap), row1Y, keySize, d);

        // Row 2: Spacebar (full width)
        int row2Y = 2 * (keySize + gap);
        int spaceWidth = widgetW;
        int bg = space ? BG_PRESSED : BG_RELEASED;
        graphics.method_25294(0, row2Y, spaceWidth, row2Y + keySize, bg);
        String spaceLabel = "\u2014"; // em dash to represent spacebar
        int textW = mc.field_1772.method_1727(spaceLabel);
        graphics.method_51433(mc.field_1772, spaceLabel,
            (spaceWidth - textW) / 2,
            row2Y + (keySize - 8) / 2,
            TEXT_COLOR, true);

        graphics.method_51448().popMatrix();
    }

    private static void drawKey(class_332 graphics, class_310 mc,
                                String label, int x, int y, int size, boolean pressed) {
        int bg = pressed ? BG_PRESSED : BG_RELEASED;
        graphics.method_25294(x, y, x + size, y + size, bg);
        int textW = mc.field_1772.method_1727(label);
        graphics.method_51433(mc.field_1772, label,
            x + (size - textW) / 2,
            y + (size - 8) / 2,
            TEXT_COLOR, true);
    }
}
