package com.steveplays.superawesomemod;

import java.util.List;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Walks to the nearest block of the marked type and mines it.
 *
 * <p>Runs as a small state machine rather than doing everything each tick: find a target,
 * path to it, walk the path, aim, mine, repeat. Each stage can fail into a stopped state
 * with a reason, because a bot that quietly stands still is worse than one that says it
 * gave up.
 *
 * <p>Movement is published through {@link #getMoveTarget()} and applied by
 * {@code AutoMineInputMixin} as ordinary key presses, so the server sees a walking player.
 * Nothing here teleports.
 */
public final class AutoMineHandler {

    /** How close to a path node before moving to the next one. */
    private static final double NODE_REACHED = 0.6;
    /** Interaction range to leave when standing next to the block being mined. */
    private static final double MINE_REACH = 3.5;
    /** How far down the path to look while walking, in blocks. */
    private static final double LOOK_AHEAD = 3.5;
    private static final int RESCAN_INTERVAL = 20;

    private enum State { SEARCH, PATH, WALK, MINE }

    private static State state = State.SEARCH;
    private static class_2338 targetBlock = null;
    private static List<class_2338> path = List.of();
    private static int pathIndex = 0;
    private static int rescanTimer = 0;
    private static int actionDelay = 0;
    private static float lastHealth = -1f;
    private static class_243 aimPoint = null;

    /** Where the walker currently wants to go, or null when it should stand still. */
    private static class_2338 moveTarget = null;
    private static boolean wantJump = false;

    private AutoMineHandler() {}

    public static class_2338 getMoveTarget() { return moveTarget; }
    public static boolean  wantsJump()     { return wantJump; }

    public static void tick(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null || client.field_1687 == null || client.field_1761 == null) {
            reset();
            return;
        }

        if (!AutoMineData.isRunning() || client.field_1755 != null) {
            moveTarget = null;
            wantJump = false;
            // Give the mouse back the moment the run ends, so nothing keeps steering.
            RotationHelper.release();
            lastHealth = player.method_6032();
            return;
        }

        // Safety stop: anything that hurts ends the run. This is also what covers lava,
        // after the fact rather than before — the path avoids fluids, but a mob or a fall
        // can still land a hit, and continuing to mine through it is how a bot dies.
        if (lastHealth >= 0f && player.method_6032() < lastHealth - 0.01f) {
            AutoMineData.stop("Stopped: took damage");
            reset();
            return;
        }
        lastHealth = player.method_6032();

        if (actionDelay > 0) {
            actionDelay--;
            return;
        }

        switch (state) {
            case SEARCH -> search(client, player);
            case PATH   -> buildPath(client, player);
            case WALK   -> walk(client, player);
            case MINE   -> mine(client, player);
        }
    }

    private static void search(class_310 client, class_746 player) {
        moveTarget = null;
        class_2248 want = AutoMineData.getTarget();
        if (want == null) {
            AutoMineData.stop("Stopped: nothing marked");
            return;
        }

        if (rescanTimer-- > 0) return;
        rescanTimer = RESCAN_INTERVAL;

        class_2338 found = nearest(client.field_1687, player.method_24515(), want,
                                 AutoMineData.getSearchRadius());
        if (found == null) {
            AutoMineData.stop("Stopped: no " + AutoMineData.getTargetName() + " nearby");
            return;
        }

        targetBlock = found;
        AutoMineData.setStatus("Pathing");
        state = State.PATH;
    }

    private static void buildPath(class_310 client, class_746 player) {
        moveTarget = null;
        if (targetBlock == null) {
            state = State.SEARCH;
            return;
        }

        // Already close enough to just mine it.
        if (player.method_33571().method_1025(class_243.method_24953(targetBlock))
                <= MINE_REACH * MINE_REACH) {
            beginMining();
            return;
        }

        path = PathFinder.findPath(client.field_1687, player.method_24515(), targetBlock, MINE_REACH);
        if (path.isEmpty()) {
            // Walk-only by design: a sealed target has no route and that is not a bug.
            AutoMineData.stop("Stopped: no walkable route");
            return;
        }
        pathIndex = 0;
        AutoMineData.setStatus("Walking");
        state = State.WALK;
    }

    private static void walk(class_310 client, class_746 player) {
        if (targetBlock == null || client.field_1687.method_8320(targetBlock).method_26204()
                != AutoMineData.getTarget()) {
            // Someone else mined it, or it changed under us.
            state = State.SEARCH;
            return;
        }

        if (player.method_33571().method_1025(class_243.method_24953(targetBlock))
                <= MINE_REACH * MINE_REACH) {
            beginMining();
            return;
        }

        if (pathIndex >= path.size()) {
            state = State.PATH;
            return;
        }

        class_2338 node = path.get(pathIndex);
        class_243 nodeCentre = new class_243(node.method_10263() + 0.5, node.method_10264(), node.method_10260() + 0.5);
        double flatDistSqr = (player.method_23317() - nodeCentre.field_1352) * (player.method_23317() - nodeCentre.field_1352)
                           + (player.method_23321() - nodeCentre.field_1350) * (player.method_23321() - nodeCentre.field_1350);

        if (flatDistSqr < NODE_REACHED * NODE_REACHED) {
            pathIndex++;
            return;
        }

        moveTarget = node;
        wantJump = node.method_10264() > player.method_24515().method_10264() && player.method_24828();

        // Look where we are going, not at the target — staring at the ore while
        // side-stepping toward it is not how a person walks. Aim well down the path
        // rather than at the node underfoot: the yaw to a point half a block away
        // swings hard for a small sideways step, which is what made the camera judder.
        RotationHelper.lookAt(player, lookAheadPoint(player), 8f);
    }

    /**
     * A point several blocks along the remaining path, at head height, so the direction
     * to it changes slowly as the player walks. Falls back to the furthest node left when
     * the path is shorter than {@link #LOOK_AHEAD}.
     */
    private static class_243 lookAheadPoint(class_746 player) {
        class_243 eye = player.method_33571();
        double eyeOffset = eye.field_1351 - player.method_23318();
        class_243 chosen = null;

        for (int i = pathIndex; i < path.size(); i++) {
            class_2338 p = path.get(i);
            // Head height above the node, so pitch tracks the slope of the route
            // instead of pointing down at the player's own feet.
            chosen = new class_243(p.method_10263() + 0.5, p.method_10264() + eyeOffset, p.method_10260() + 0.5);
            double dx = chosen.field_1352 - eye.field_1352;
            double dz = chosen.field_1350 - eye.field_1350;
            if (dx * dx + dz * dz >= LOOK_AHEAD * LOOK_AHEAD) break;
        }

        if (chosen != null) return chosen;
        return targetBlock != null
            ? class_243.method_24953(targetBlock)
            : eye.method_1019(player.method_5720());
    }

    private static void beginMining() {
        moveTarget = null;
        wantJump = false;
        aimPoint = RotationHelper.humanAimPoint(targetBlock.method_10263(), targetBlock.method_10264(), targetBlock.method_10260());
        // A short pause before swinging, so arriving and mining aren't the same instant.
        actionDelay = RotationHelper.jitterTicks(2, 4);
        AutoMineData.setStatus("Mining");
        state = State.MINE;
    }

    private static void mine(class_310 client, class_746 player) {
        moveTarget = null;

        if (targetBlock == null) {
            state = State.SEARCH;
            return;
        }
        if (client.field_1687.method_8320(targetBlock).method_26204() != AutoMineData.getTarget()) {
            // Broken — go again, after a beat.
            actionDelay = RotationHelper.jitterTicks(3, 5);
            state = State.SEARCH;
            return;
        }
        if (player.method_33571().method_1025(class_243.method_24953(targetBlock))
                > MINE_REACH * MINE_REACH) {
            state = State.PATH;
            return;
        }

        if (!RotationHelper.lookAt(player, aimPoint, 4f)) return;

        class_2350 face = class_2350.method_58251(
            player.method_33571().method_1020(class_243.method_24953(targetBlock)));
        client.field_1761.method_2902(targetBlock, face);
        player.method_6104(net.minecraft.class_1268.field_5808);
    }

    /** Nearest matching block by straight-line distance, searched outward from the player. */
    private static class_2338 nearest(class_1937 level, class_2338 from, class_2248 want, int radius) {
        class_2338 best = null;
        double bestSqr = Double.MAX_VALUE;
        class_2338.class_2339 cursor = new class_2338.class_2339();

        int minY = Math.max(level.method_31607(), from.method_10264() - radius);
        int maxY = Math.min(level.method_31600(), from.method_10264() + radius);

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int y = minY; y <= maxY; y++) {
                    cursor.method_10103(from.method_10263() + dx, y, from.method_10260() + dz);
                    if (level.method_8320(cursor).method_26204() != want) continue;
                    double d = cursor.method_10262(from);
                    if (d < bestSqr) {
                        bestSqr = d;
                        best = cursor.method_10062();
                    }
                }
            }
        }
        return best;
    }

    private static void reset() {
        state = State.SEARCH;
        targetBlock = null;
        path = List.of();
        pathIndex = 0;
        moveTarget = null;
        wantJump = false;
        aimPoint = null;
        actionDelay = 0;
        RotationHelper.release();
    }
}
