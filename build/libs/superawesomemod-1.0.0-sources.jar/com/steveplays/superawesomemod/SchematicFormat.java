package com.steveplays.superawesomemod;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2507;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Parses {@code .litematic} files (gzip-compressed NBT) into {@link Schematic} objects.
 */
public final class SchematicFormat {

    private SchematicFormat() {}

    /**
     * Loads a {@code .litematic} file from disk.
     */
    public static Schematic load(Path file) throws IOException {
        class_2487 root = class_2507.method_30613(file, net.minecraft.class_2505.method_53898());

        // Metadata
        class_2487 metadata = root.method_68568("Metadata");
        String name = metadata.method_68564("Name", "");
        String author = metadata.method_68564("Author", "");
        int totalBlocks = metadata.method_68083("TotalBlocks", 0);

        class_2487 sizeTag = metadata.method_68568("EnclosingSize");
        class_2382 enclosingSize = new class_2382(
            sizeTag.method_68083("x", 0),
            sizeTag.method_68083("y", 0),
            sizeTag.method_68083("z", 0)
        );

        // Regions
        class_2487 regionsTag = root.method_68568("Regions");
        List<SchematicRegion> regions = new ArrayList<>();

        for (String regionName : regionsTag.method_10541()) {
            class_2487 regionTag = regionsTag.method_68568(regionName);
            SchematicRegion region = parseRegion(regionName, regionTag);
            if (region != null) {
                regions.add(region);
            }
        }

        return new Schematic(name, author, enclosingSize, regions, totalBlocks);
    }

    private static SchematicRegion parseRegion(String name, class_2487 tag) {
        // Position
        class_2487 posTag = tag.method_68568("Position");
        class_2338 position = new class_2338(
            posTag.method_68083("x", 0),
            posTag.method_68083("y", 0),
            posTag.method_68083("z", 0)
        );

        // Size (may have negative components)
        class_2487 sizeTag = tag.method_68568("Size");
        class_2382 size = new class_2382(
            sizeTag.method_68083("x", 0),
            sizeTag.method_68083("y", 0),
            sizeTag.method_68083("z", 0)
        );

        if (size.method_10263() == 0 || size.method_10264() == 0 || size.method_10260() == 0) {
            return null; // empty region
        }

        // Block state palette
        class_2499 paletteTag = tag.method_68569("BlockStatePalette");
        class_2680[] palette = new class_2680[paletteTag.size()];
        for (int i = 0; i < paletteTag.size(); i++) {
            palette[i] = paletteTag.method_10602(i)
                .map(SchematicFormat::parseBlockState)
                .orElse(class_2246.field_10124.method_9564());
        }

        // Block states (packed long array)
        long[] blockData = tag.method_10565("BlockStates").orElse(new long[0]);
        int volume = Math.abs(size.method_10263()) * Math.abs(size.method_10264()) * Math.abs(size.method_10260());
        int bitsPerEntry = Math.max(2, Integer.SIZE - Integer.numberOfLeadingZeros(Math.max(1, palette.length - 1)));
        LitematicaBitArray blockStates = new LitematicaBitArray(bitsPerEntry, volume, blockData);

        return new SchematicRegion(name, position, size, palette, blockStates);
    }

    /**
     * Parses a single block state from its NBT palette entry.
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private static class_2680 parseBlockState(class_2487 tag) {
        String blockName = tag.method_68564("Name", "minecraft:air");
        class_2960 id = class_2960.method_12829(blockName);
        if (id == null) {
            return class_2246.field_10124.method_9564();
        }

        Optional<class_2248> blockOpt = class_7923.field_41175.method_17966(id);
        if (blockOpt.isEmpty()) {
            SuperAwesomeMod.LOGGER.warn("[Schematic] Unknown block: {}", blockName);
            return class_2246.field_10124.method_9564();
        }

        class_2248 block = blockOpt.get();
        class_2680 state = block.method_9564();

        if (tag.method_10545("Properties")) {
            class_2487 props = tag.method_68568("Properties");
            class_2689<class_2248, class_2680> stateDefinition = block.method_9595();

            for (String key : props.method_10541()) {
                class_2769<?> property = stateDefinition.method_11663(key);
                if (property != null) {
                    String value = props.method_68564(key, "");
                    Optional<?> parsed = property.method_11900(value);
                    if (parsed.isPresent()) {
                        state = state.method_11657((class_2769) property, (Comparable) parsed.get());
                    }
                }
            }
        }

        return state;
    }
}
