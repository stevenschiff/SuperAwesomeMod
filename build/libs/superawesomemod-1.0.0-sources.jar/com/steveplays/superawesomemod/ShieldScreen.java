package com.steveplays.superawesomemod;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ShieldScreen extends class_437 {

    private final class_437 parent;

    public ShieldScreen(class_437 parent) {
        super(class_2561.method_43470("Shield"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                ShieldData.setEnabled(!ShieldData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 52, btnW, btnH).method_46431());

        this.method_37063(new ShieldSlider(cx - btnW / 2, cy - 28, btnW, btnH,
            "Shield transparency", ShieldData.MIN_TRANSPARENCY, ShieldData.MAX_TRANSPARENCY,
            ShieldData::getTransparency, ShieldData::setTransparency, true));

        this.method_37063(new ShieldSlider(cx - btnW / 2, cy - 4, btnW, btnH,
            "When used", ShieldData.MIN_OFFSET, ShieldData.MAX_OFFSET,
            ShieldData::getUsedOffset, ShieldData::setUsedOffset, false));

        this.method_37063(new ShieldSlider(cx - btnW / 2, cy + 20, btnW, btnH,
            "When not used", ShieldData.MIN_OFFSET, ShieldData.MAX_OFFSET,
            ShieldData::getNotUsedOffset, ShieldData::setNotUsedOffset, false));

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 44, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(ShieldData.isEnabled() ? "Disable Shield" : "Enable Shield");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 82, 0xFFFFFF);

        boolean on = ShieldData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 70, on ? 0x55FF55 : 0xFF5555);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Offsets move the shield up or down on screen"),
            cx, cy + 70, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Used = holding right-click  |  Not used = just held"),
            cx, cy + 82, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Banner patterns stay solid; plain shields fade fully"),
            cx, cy + 94, 0xFFAA00);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class ShieldSlider extends class_357 {
        private final String label;
        private final int min;
        private final int max;
        private final IntConsumer sink;
        private final boolean percent;

        ShieldSlider(int x, int y, int w, int h, String label, int min, int max,
                     IntSupplier source, IntConsumer sink, boolean percent) {
            super(x, y, w, h, class_2561.method_43473(), (double) (source.getAsInt() - min) / (max - min));
            this.label = label;
            this.min = min;
            this.max = max;
            this.sink = sink;
            this.percent = percent;
            this.method_25346();
        }

        private int denormalize() {
            return (int) Math.round(this.field_22753 * (this.max - this.min) + this.min);
        }

        @Override
        protected void method_25346() {
            // Runs once from super() before the fields are assigned.
            if (this.label == null) return;
            int v = denormalize();
            this.method_25355(class_2561.method_43470(
                this.label + ": " + (this.percent ? v + "%" : (v > 0 ? "+" + v : String.valueOf(v)))));
        }

        @Override
        protected void method_25344() {
            if (this.sink == null) return;
            this.sink.accept(denormalize());
        }
    }
}
