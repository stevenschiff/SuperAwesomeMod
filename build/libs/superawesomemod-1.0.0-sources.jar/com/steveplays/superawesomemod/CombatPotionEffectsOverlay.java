package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("deprecation")
public final class CombatPotionEffectsOverlay {

    private CombatPotionEffectsOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(CombatPotionEffectsOverlay::onHudRender);
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter) {
        if (!CombatPotionEffectsData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;

        class_746 player = mc.field_1724;
        if (player == null) return;

        int screenWidth = graphics.method_51421();
        int lineHeight = 11;
        int startY = 52;
        int padding = 4;

        List<class_1293> effects = new ArrayList<>(player.method_6026());

        // Debug: always show when enabled to confirm rendering works.
        String debugLine = "Time: " + effects.size() + "s";
        int debugWidth = mc.field_1772.method_1727(debugLine);
        graphics.method_25303(mc.field_1772, debugLine, screenWidth - debugWidth - padding, startY, 0xFF55FF55);

        int rendered = 1;
        for (class_1293 effect : effects) {
            int duration = effect.method_5584();
            int seconds = duration / 20;

            String name;
            try {
                name = effect.method_5579().comp_349().method_5560().getString();
            } catch (Exception e) {
                name = "Effect";
            }

            int amplifier = effect.method_5578();
            if (amplifier > 0) {
                name += " " + toRoman(amplifier + 1);
            }

            String line = name + " Time: " + seconds + "s";

            int textWidth = mc.field_1772.method_1727(line);
            int x = screenWidth - textWidth - padding;
            int y = startY + rendered * lineHeight;

            // ARGB colors with full alpha (0xFF prefix).
            int color = 0xFFFFFFFF; // white
            if (seconds < 10) {
                color = 0xFFFF5555; // red
            } else if (seconds < 30) {
                color = 0xFFFFFF55; // yellow
            }

            graphics.method_25303(mc.field_1772, line, x, y, color);
            rendered++;
        }
    }

    private static String toRoman(int num) {
        return switch (num) {
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            default -> String.valueOf(num);
        };
    }
}
