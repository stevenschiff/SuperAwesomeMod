package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

public final class CombatPotionEffectsOverlay {

    private CombatPotionEffectsOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(CombatPotionEffectsOverlay::onHudRender);
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter) {
        if (!CombatPotionEffectsData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;

        class_746 player = mc.field_1724;
        if (player == null) return;

        Collection<class_1293> effects = player.method_6026();
        if (effects.isEmpty()) return;

        // Sort effects the same way vanilla does: beneficial first, then by duration descending.
        List<class_1293> sorted = new ArrayList<>(effects);
        sorted.sort(Comparator.comparingInt(class_1293::method_5584));

        int screenWidth = graphics.method_51421();

        // Vanilla renders effect icons starting at x = screenWidth - 25 for the first icon,
        // then moving left by 25 for each subsequent icon. Icons are at y = 1.
        // The icon is 24x24 pixels. We render the timer text centered below each icon.
        int iconSize = 25;
        int iconY = 1;
        int textY = iconY + 26; // Just below the 24px icon

        for (int i = 0; i < sorted.size(); i++) {
            class_1293 effect = sorted.get(i);
            int duration = effect.method_5584();
            if (duration <= 0) continue;

            String timeStr = formatDuration(duration);
            int iconX = screenWidth - iconSize * (i + 1);
            int textWidth = mc.field_1772.method_1727(timeStr);
            int textX = iconX + (iconSize - textWidth) / 2;

            // Draw with shadow for readability
            graphics.method_51433(mc.field_1772, timeStr, textX, textY, 0xFFFFFF, true);
        }
    }

    private static String formatDuration(int ticks) {
        int totalSeconds = ticks / 20;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        if (minutes > 0) {
            return String.format("%d:%02d", minutes, seconds);
        }
        return String.format("0:%02d", seconds);
    }
}
