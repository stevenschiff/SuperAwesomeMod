package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_9779;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@SuppressWarnings("deprecation")
public final class CombatPotionEffectsOverlay {

    private CombatPotionEffectsOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(CombatPotionEffectsOverlay::onHudRender);
    }

    private static void onHudRender(class_332 graphics, class_9779 tickCounter) {
        if (!CombatPotionEffectsData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;

        class_746 player = mc.field_1724;
        if (player == null) return;

        List<class_1293> effects = new ArrayList<>(player.method_6026());
        if (effects.isEmpty()) return;

        // Sort by duration descending (longest first).
        effects.sort(Comparator.comparingInt(class_1293::method_5584).reversed());

        int screenWidth = graphics.method_51421();
        int lineHeight = 11;
        // Render below vanilla's effect icon area (starts around y=52 to be safe).
        int startY = 52;
        int padding = 2;

        for (int i = 0; i < effects.size(); i++) {
            class_1293 effect = effects.get(i);
            int duration = effect.method_5584();
            // Skip infinite or expired effects.
            if (duration <= 0 || duration == class_1293.field_42106) continue;

            class_6880<class_1291> effectType = effect.method_5579();
            String name = effectType.comp_349().method_5560().getString();
            int amplifier = effect.method_5578();
            if (amplifier > 0) {
                name += " " + toRoman(amplifier + 1);
            }
            String timeStr = formatDuration(duration);
            String line = name + " " + timeStr;

            int textWidth = mc.field_1772.method_1727(line);
            int x = screenWidth - textWidth - padding;
            int y = startY + i * lineHeight;

            // Color based on remaining time: white normally, yellow < 30s, red < 10s.
            int color = 0xFFFFFF;
            int seconds = duration / 20;
            if (seconds < 10) {
                color = 0xFF5555;
            } else if (seconds < 30) {
                color = 0xFFFF55;
            }

            graphics.method_51433(mc.field_1772, line, x, y, color, true);
        }
    }

    private static String formatDuration(int ticks) {
        int totalSeconds = ticks / 20;
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%d:%02d", minutes, seconds);
    }

    private static String toRoman(int num) {
        return switch (num) {
            case 2 -> "II";
            case 3 -> "III";
            case 4 -> "IV";
            case 5 -> "V";
            default -> String.valueOf(num);
        };
    }
}
