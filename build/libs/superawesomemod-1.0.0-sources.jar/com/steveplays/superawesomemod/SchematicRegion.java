package com.steveplays.superawesomemod;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2382;
import net.minecraft.class_2680;

/**
 * One region within a loaded {@code .litematic} schematic.
 * Holds position, size, a palette of {@link class_2680}s, and the packed block data.
 */
public final class SchematicRegion {

    private final String name;
    private final class_2338 position; // relative to schematic origin
    private final class_2382 size;        // may contain negative components (direction)
    private final class_2680[] palette;
    private final LitematicaBitArray blockStates;

    public SchematicRegion(String name, class_2338 position, class_2382 size,
                           class_2680[] palette, LitematicaBitArray blockStates) {
        this.name = name;
        this.position = position;
        this.size = size;
        this.palette = palette;
        this.blockStates = blockStates;
    }

    /**
     * Returns the block state at the given position relative to this region's origin.
     * Coordinates must be in [0, abs(sizeAxis)) for each axis.
     */
    public class_2680 getBlockState(int x, int y, int z) {
        int sx = Math.abs(size.method_10263());
        int sy = Math.abs(size.method_10264());
        int sz = Math.abs(size.method_10260());

        if (x < 0 || x >= sx || y < 0 || y >= sy || z < 0 || z >= sz) {
            return class_2246.field_10124.method_9564();
        }

        int index = (y * sx * sz) + (z * sx) + x;
        int paletteIndex = blockStates.get(index);

        if (paletteIndex < 0 || paletteIndex >= palette.length) {
            return class_2246.field_10124.method_9564();
        }
        return palette[paletteIndex];
    }

    public String getName() { return name; }
    public class_2338 getPosition() { return position; }
    public class_2382 getSize() { return size; }

    public int getAbsSizeX() { return Math.abs(size.method_10263()); }
    public int getAbsSizeY() { return Math.abs(size.method_10264()); }
    public int getAbsSizeZ() { return Math.abs(size.method_10260()); }

    /**
     * Returns the minimum corner of this region in region-local coordinates,
     * accounting for negative size components.
     */
    public class_2338 getMinPos() {
        int minX = size.method_10263() < 0 ? position.method_10263() + size.method_10263() + 1 : position.method_10263();
        int minY = size.method_10264() < 0 ? position.method_10264() + size.method_10264() + 1 : position.method_10264();
        int minZ = size.method_10260() < 0 ? position.method_10260() + size.method_10260() + 1 : position.method_10260();
        return new class_2338(minX, minY, minZ);
    }

    /**
     * Returns the maximum corner (exclusive) of this region in region-local coordinates.
     */
    public class_2338 getMaxPos() {
        class_2338 min = getMinPos();
        return min.method_10069(getAbsSizeX(), getAbsSizeY(), getAbsSizeZ());
    }

    public class_2680[] getPalette() { return palette; }
}
