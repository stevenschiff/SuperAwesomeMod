package com.steveplays.superawesomemod;

import com.steveplays.superawesomemod.network.AttackRangePayload;
import com.steveplays.superawesomemod.network.FlySpeedPayload;
import com.steveplays.superawesomemod.network.JumpHeightPayload;
import com.steveplays.superawesomemod.network.ToggleFlyPayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1324;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SuperAwesomeMod implements ModInitializer {

    public static final String MOD_ID = "superawesomemod";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("[SuperAwesomeMod] Initializing — MC 1.21.11 / Fabric Loader");

        registerPackets();
        registerTickHooks();
        ModEvents.register();
        ModCommands.register();
    }

    private static void registerPackets() {
        // --- Jump height ---
        PayloadTypeRegistry.playC2S().register(JumpHeightPayload.TYPE, JumpHeightPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(JumpHeightPayload.TYPE, (payload, context) -> {
            float value = Math.clamp(payload.multiplier(), PlayerJumpData.MIN, PlayerJumpData.MAX);
            PlayerJumpData.setMultiplier(context.player().method_5667(), value);
            context.player().method_64398(class_2561.method_43470(
                "[SuperAwesomeMod] Jump height set to " + value + "x"
            ));
        });

        // --- Flight toggle ---
        // The payload now carries the explicit intended state (not a blind toggle)
        // so client and server always agree even if the packet arrives late.
        PayloadTypeRegistry.playC2S().register(ToggleFlyPayload.TYPE, ToggleFlyPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ToggleFlyPayload.TYPE, (payload, context) -> {
            class_3222 player = context.player();
            boolean enable = payload.enabled();
            PlayerFlyData.setEnabled(player.method_5667(), enable);
            player.method_31549().field_7478 = enable;
            player.method_31549().field_7479 = enable;  // start flying immediately when enabling
            player.method_7355();
            player.method_64398(class_2561.method_43470(
                "[SuperAwesomeMod] Flight " + (enable ? "enabled" : "disabled")
            ));
        });

        // --- Fly speed ---
        PayloadTypeRegistry.playC2S().register(FlySpeedPayload.TYPE, FlySpeedPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(FlySpeedPayload.TYPE, (payload, context) -> {
            class_3222 player = context.player();
            player.method_31549().method_7248(payload.speed());
            player.method_7355();
        });

        // --- Attack range ---
        PayloadTypeRegistry.playC2S().register(AttackRangePayload.TYPE, AttackRangePayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(AttackRangePayload.TYPE, (payload, context) -> {
            class_3222 player = context.player();
            float range = Math.clamp(payload.range(), AttackRangePayload.MIN, AttackRangePayload.MAX);
            PlayerAttackRangeData.setRange(player.method_5667(), range);
            class_1324 attr = player.method_5996(class_5134.field_47759);
            if (attr != null) attr.method_6192(range);
            player.method_64398(class_2561.method_43470(
                "[SuperAwesomeMod] Attack range set to " + range + " blocks"
            ));
        });

        // Clean up mod state when a player disconnects
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            PlayerFlyData.remove(handler.field_14140.method_5667());
            PlayerAttackRangeData.remove(handler.field_14140.method_5667());
        });
    }

    /**
     * Tick hooks re-apply mod state every server tick.
     *
     * This serves two purposes:
     * 1. In singleplayer, the client thread writes to the shared ConcurrentHashMap
     *    (PlayerFlyData / PlayerAttackRangeData) immediately on button click. The
     *    server thread reads from that same map here and applies the effect — this
     *    is the same pattern that makes JumpHeight work without needing the packet.
     * 2. For any player, if vanilla code silently resets mayfly or the attribute
     *    (e.g. on respawn), this hook restores it within one tick.
     */
    private static void registerTickHooks() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                // --- Flight ---
                if (PlayerFlyData.isEnabled(player.method_5667())) {
                    if (!player.method_31549().field_7478) {
                        player.method_31549().field_7478 = true;
                        player.method_7355();
                    }
                }

                // --- Attack range ---
                if (PlayerAttackRangeData.hasCustomRange(player.method_5667())) {
                    float desired = PlayerAttackRangeData.getRange(player.method_5667());
                    class_1324 attr = player.method_5996(class_5134.field_47759);
                    if (attr != null && (float) attr.method_6201() != desired) {
                        attr.method_6192(desired);
                    }
                }
            }
        });
    }
}
