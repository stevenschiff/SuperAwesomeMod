package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class MiniMapScreen extends class_437 {

    private final class_437 parent;

    private static final int BTN_W = 200;
    private static final int BTN_H = 20;

    public MiniMapScreen(class_437 parent) {
        super(class_2561.method_43470("Mini Map"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 60;
        int gap = 24;

        // Master toggle
        this.method_37063(class_4185.method_46430(
            enabledLabel(),
            btn -> {
                MiniMapData.setEnabled(!MiniMapData.isEnabled());
                btn.method_25355(enabledLabel());
            }
        ).method_46434(cx - BTN_W / 2, topY, BTN_W, BTN_H).method_46431());

        // HUD visibility toggle
        this.method_37063(class_4185.method_46430(
            hudLabel(),
            btn -> {
                MiniMapData.setHudVisible(!MiniMapData.isHudVisible());
                btn.method_25355(hudLabel());
            }
        ).method_46434(cx - BTN_W / 2, topY + gap, BTN_W, BTN_H).method_46431());

        // Minimap size cycle (64, 96, 128, 160, 192, 224, 256)
        this.method_37063(class_4185.method_46430(
            sizeLabel(),
            btn -> {
                int size = MiniMapData.getMinimapSize() + 32;
                if (size > 256) size = 64;
                MiniMapData.setMinimapSize(size);
                btn.method_25355(sizeLabel());
            }
        ).method_46434(cx - BTN_W / 2, topY + gap * 2, BTN_W, BTN_H).method_46431());

        // Corner position cycle
        this.method_37063(class_4185.method_46430(
            cornerLabel(),
            btn -> {
                int c = (MiniMapData.getCorner() + 1) % 4;
                MiniMapData.setCorner(c);
                btn.method_25355(cornerLabel());
            }
        ).method_46434(cx - BTN_W / 2, topY + gap * 3, BTN_W, BTN_H).method_46431());

        // Entity display mode
        this.method_37063(class_4185.method_46430(
            entityLabel(),
            btn -> {
                int mode = (MiniMapData.getEntityMode() + 1) % 3;
                MiniMapData.setEntityMode(mode);
                btn.method_25355(entityLabel());
            }
        ).method_46434(cx - BTN_W / 2, topY + gap * 4, BTN_W, BTN_H).method_46431());

        // Manage Waypoints button
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Manage Waypoints (" + MiniMapData.getWaypoints().size() + ")"),
            btn -> this.field_22787.method_1507(new MiniMapWaypointListScreen(this))
        ).method_46434(cx - BTN_W / 2, topY + gap * 5, BTN_W, BTN_H).method_46431());

        // Back button
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, topY + gap * 6 + 8, 100, BTN_H).method_46431());
    }

    private class_2561 enabledLabel() {
        return class_2561.method_43470(MiniMapData.isEnabled()
            ? "Mini Map: Enabled" : "Mini Map: Disabled");
    }

    private class_2561 hudLabel() {
        return class_2561.method_43470(MiniMapData.isHudVisible()
            ? "Corner Map: Shown" : "Corner Map: Hidden");
    }

    private class_2561 sizeLabel() {
        return class_2561.method_43470("Minimap Size: " + MiniMapData.getMinimapSize());
    }

    private class_2561 cornerLabel() {
        return class_2561.method_43470("Corner: " + MiniMapData.getCornerName());
    }

    private class_2561 entityLabel() {
        return class_2561.method_43470("Entities: " + MiniMapData.getEntityModeName());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 60;

        graphics.method_27534(this.field_22793, this.field_22785, cx, topY - 16, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Press C to open full map (when enabled)"),
            cx, topY - 6, 0xAAAAAA);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
