package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class AntiKnockbackScreen extends class_437 {

    private final class_437 parent;

    public AntiKnockbackScreen(class_437 parent) {
        super(class_2561.method_43470("Anti-Knockback"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        // Toggle on/off
        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                AntiKnockbackData.setEnabled(!AntiKnockbackData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        // Knockback taken (0-100%)
        this.method_37063(new KnockbackSlider(cx - btnW / 2, cy - 10, btnW, btnH,
                AntiKnockbackData.getPercent()));

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(AntiKnockbackData.isEnabled()
            ? "Disable Anti-Knockback"
            : "Enable Anti-Knockback");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);

        boolean on = AntiKnockbackData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 58, on ? 0x55FF55 : 0xFF5555);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("0% = never pushed back  |  100% = normal"),
            cx, cy + 46, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Works on any server  |  covers hits and explosions"),
            cx, cy + 58, 0xAAAAAA);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class KnockbackSlider extends class_357 {
        KnockbackSlider(int x, int y, int w, int h, int initial) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.method_25346();
        }

        private static double normalize(int v) {
            return (double) (v - AntiKnockbackData.MIN_PERCENT)
                 / (AntiKnockbackData.MAX_PERCENT - AntiKnockbackData.MIN_PERCENT);
        }

        private int denormalize() {
            return (int) Math.round(this.field_22753
                * (AntiKnockbackData.MAX_PERCENT - AntiKnockbackData.MIN_PERCENT)
                + AntiKnockbackData.MIN_PERCENT);
        }

        @Override
        protected void method_25346() {
            this.method_25355(class_2561.method_43470("Knockback taken: " + denormalize() + "%"));
        }

        @Override
        protected void method_25344() {
            AntiKnockbackData.setPercent(denormalize());
        }
    }
}
