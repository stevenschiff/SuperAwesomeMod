package com.steveplays.superawesomemod;

import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_5134;

/**
 * Reach maths shared by the spacing trainer and the full-colour hitbox tint.
 *
 * <p>Deliberately the same quantity the server validates against: {@code Player}
 * checks {@code aABB.distanceToSqr(getEyePosition())} against the entity interaction
 * range, so "gap" here means eye to the nearest point of the hitbox — 0 when you are
 * touching, and never above the reach when a hit actually connects.
 *
 * <p>{@code CombatHitboxRenderer} carries its own private copy of this arithmetic. It
 * is left alone rather than refactored so a working feature isn't disturbed; the two
 * must stay in agreement, since Full Colour is a sub-toggle of that renderer.
 */
public final class CombatReach {

    private CombatReach() {}

    /** The player's attack reach, honouring any attribute modifiers (spears raise it). */
    public static double attackReach(class_1657 player) {
        class_1324 attr = player.method_5996(class_5134.field_47759);
        return attr != null ? attr.method_6194() : class_1657.field_47820;
    }

    /** Distance from the eye to the nearest point of the box; 0 when inside it. */
    public static double gap(class_243 eye, class_238 box) {
        return Math.sqrt(gapSqr(eye, box));
    }

    public static double gapSqr(class_243 eye, class_238 box) {
        double dx = Math.max(0.0, Math.max(box.field_1323 - eye.field_1352, eye.field_1352 - box.field_1320));
        double dy = Math.max(0.0, Math.max(box.field_1322 - eye.field_1351, eye.field_1351 - box.field_1325));
        double dz = Math.max(0.0, Math.max(box.field_1321 - eye.field_1350, eye.field_1350 - box.field_1324));
        return dx * dx + dy * dy + dz * dz;
    }
}
