package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.FullColorArmorTint;
import net.minecraft.class_10186;
import net.minecraft.class_10197;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Full Colour, armour half — part two: the single choke point where every armour
 * layer's colour is decided. Its return value becomes the {@code color} argument of
 * each armour {@code submitModel} call, so overriding it here covers helmet through
 * boots, dyed or not, in one place.
 *
 * <p>The tint is never 0 by construction — {@code renderLayers} treats a colour of 0
 * as "skip this layer", and a zero here would make armour vanish rather than tint.
 * Every entry in {@code CombatHitboxData.COLOR_ARGB} is opaque, which is what keeps
 * that safe.
 */
@Mixin(class_10197.class)
public abstract class FullColorArmorColorMixin {

    @Inject(
        method = "getColorForLayer(Lnet/minecraft/client/resources/model/EquipmentClientInfo$Layer;I)I",
        at = @At("HEAD"),
        cancellable = true
    )
    private static void superawesomemod$tintArmour(class_10186.class_10189 layer, int dyeColor,
                                                   CallbackInfoReturnable<Integer> cir) {
        int tint = FullColorArmorTint.get();
        if (tint != 0) cir.setReturnValue(tint);
    }
}
