package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.NoFogData;
import net.minecraft.class_11401;
import net.minecraft.class_4184;
import net.minecraft.class_638;
import net.minecraft.class_7285;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Removes lava fog by pushing fog distances very far when No Fog is enabled.
 */
@Mixin(class_11401.class)
public class LavaFogMixin {

    @Inject(method = "setupFog", at = @At("TAIL"))
    private void superawesomemod$clearLavaFog(class_7285 fogData, class_4184 camera,
            class_638 level, float partialTick, class_9779 deltaTracker, CallbackInfo ci) {
        if (NoFogData.isEnabled()) {
            fogData.field_60582 = -8.0f;
            fogData.field_60584 = 1000000.0f;
        }
    }
}
