package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.OldPvpData;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public abstract class ItemInHandRendererMixin {

    @Shadow @Final private class_310 minecraft;

    @Shadow
    protected abstract void applyItemArmTransform(class_4587 poseStack, class_1306 arm, float equipProgress);

    @Shadow
    public abstract void renderItem(class_1309 entity, class_1799 stack,
            class_811 context, class_4587 poseStack,
            class_11659 collector, int light);

    @Inject(method = "renderArmWithItem", at = @At("HEAD"), cancellable = true)
    private void superawesomemod$swordBlockingVisual(
            class_742 player, float partialTicks, float pitch,
            class_1268 hand, float swingProgress, class_1799 itemStack,
            float equipProgress, class_4587 poseStack,
            class_11659 collector, int combinedLight,
            CallbackInfo ci) {
        if (!OldPvpData.isBlockingEnabled()) return;
        if (itemStack.method_7960() || !itemStack.method_31573(class_3489.field_42611)) return;
        if (player.method_31550()) return;

        boolean useKeyHeld = minecraft.field_1690.field_1904.method_1434();
        boolean notActuallyUsing = !player.method_6115();

        if (!useKeyHeld || !notActuallyUsing) return;

        // Mark as custom blocking for swing-while-blocking detection
        if (hand == class_1268.field_5808) {
            OldPvpData.setCustomBlocking(true);
        }

        boolean isMainHand = (hand == class_1268.field_5808);
        class_1306 arm = isMainHand ? player.method_6068() : player.method_6068().method_5928();
        boolean isRight = (arm == class_1306.field_6183);
        int side = isRight ? 1 : -1;

        poseStack.method_22903();

        // Apply standard arm positioning
        applyItemArmTransform(poseStack, arm, equipProgress);

        // Apply 1.7 sword blocking transforms (classic diagonal block pose)
        poseStack.method_46416(side * -0.14142136f, 0.08f, 0.14142136f);
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(-102.25f));
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * 13.365f));
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(side * 78.05f));

        // Render the sword in the blocking pose
        class_811 ctx = isRight
                ? class_811.field_4322
                : class_811.field_4321;
        renderItem(player, itemStack, ctx, poseStack, collector, combinedLight);

        poseStack.method_22909();
        ci.cancel();
    }
}
