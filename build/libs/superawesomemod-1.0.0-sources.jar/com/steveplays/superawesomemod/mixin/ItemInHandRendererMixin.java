package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.OldPvpData;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public abstract class ItemInHandRendererMixin {

    @Shadow @Final private class_310 minecraft;

    @Shadow
    private void applyItemArmTransform(class_4587 poseStack, class_1306 arm, float equipProgress) {
        throw new AssertionError();
    }

    @Shadow
    public abstract void renderItem(class_1309 entity, class_1799 stack,
            class_811 context, class_4587 poseStack,
            class_11659 collector, int light);

    @Shadow
    private void swingArm(float swingProgress, class_4587 poseStack, int direction, class_1306 arm) {
        throw new AssertionError();
    }

    @Unique
    private float superawesomemod$currentSwingProgress;

    @Inject(method = "renderArmWithItem", at = @At("HEAD"), cancellable = true)
    private void superawesomemod$swordBlockingVisual(
            class_742 player, float partialTicks, float pitch,
            class_1268 hand, float swingProgress, class_1799 itemStack,
            float equipProgress, class_4587 poseStack,
            class_11659 collector, int combinedLight,
            CallbackInfo ci) {
        // Capture swing progress for the @Redirect below
        this.superawesomemod$currentSwingProgress = swingProgress;

        if (!OldPvpData.isBlockingEnabled()) return;
        if (itemStack.method_7960() || !itemStack.method_31573(class_3489.field_42611)) return;
        if (player.method_31550()) return;

        boolean useKeyHeld = minecraft.field_1690.field_1904.method_1434();
        boolean notActuallyUsing = !player.method_6115();

        if (!useKeyHeld || !notActuallyUsing) return;

        // Mark as custom blocking for swing-while-blocking detection
        if (hand == class_1268.field_5808) {
            OldPvpData.setCustomBlocking(true);
        }

        boolean isMainHand = (hand == class_1268.field_5808);
        class_1306 arm = isMainHand ? player.method_6068() : player.method_6068().method_5928();
        boolean isRight = (arm == class_1306.field_6183);
        int side = isRight ? 1 : -1;

        poseStack.method_22903();

        // Base arm positioning (modern equivalent of 1.8 transformFirstPersonItem)
        applyItemArmTransform(poseStack, arm, equipProgress);

        // Enter legacy (1.8) coordinate space — the blocking transforms were
        // designed for the old system where transformFirstPersonItem applied
        // rotateY(45) and scale(0.4). This wrapper converts between modern
        // and legacy coordinate systems (same technique as Animatium).
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * 45.0f));
        poseStack.method_22905(0.4f, 0.4f, 0.4f);

        // Block-hitting: apply swing animation in legacy space
        if (swingProgress > 0.0f) {
            swingArm(swingProgress, poseStack, side, arm);
        }

        // 1.8 blocking pose (vanilla func_178103_d)
        poseStack.method_46416(side * -0.5f, 0.2f, 0.0f);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * 30.0f));
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(-80.0f));
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * 60.0f));

        // Exit legacy coordinate space
        poseStack.method_22905(2.5f, 2.5f, 2.5f);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(side * -45.0f));

        // Render the sword in the blocking pose
        class_811 ctx = isRight
                ? class_811.field_4322
                : class_811.field_4321;
        renderItem(player, itemStack, ctx, poseStack, collector, combinedLight);

        poseStack.method_22909();
        ci.cancel();
    }

    /**
     * Redirect the second isUsingItem() call in renderArmWithItem so that
     * when the player is mid-swing, the renderer takes the idle+swing branch
     * instead of the eating-only branch. This makes the swing animation
     * briefly play over the eating animation, matching 1.7 behavior.
     */
    @Redirect(method = "renderArmWithItem",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/player/AbstractClientPlayer;isUsingItem()Z",
                    ordinal = 1))
    private boolean superawesomemod$allowSwingWhileUsing(class_742 player) {
        if (OldPvpData.isSwingWhileUsingEnabled() && this.superawesomemod$currentSwingProgress > 0.0f) {
            return false;
        }
        return player.method_6115();
    }
}
