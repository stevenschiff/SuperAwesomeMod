package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.NoFallData;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Prevents fall damage by resetting fallDistance every tick when No Fall is enabled.
 */
@Mixin(class_746.class)
public abstract class NoFallMixin {

    @Inject(method = "aiStep", at = @At("TAIL"))
    private void superawesomemod$noFall(CallbackInfo ci) {
        if (!NoFallData.isEnabled()) return;
        class_746 self = (class_746) (Object) this;
        self.field_6017 = 0f;
    }
}
