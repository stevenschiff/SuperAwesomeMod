package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.BoatFlyData;
import net.minecraft.class_10255;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_315;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Boat Fly: allows boats to fly when the player is riding them.
 * Uses Space/Shift for vertical movement, WASD for horizontal,
 * with flight physics similar to player flight.
 */
@Mixin(class_10255.class)
public abstract class BoatFlyMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void superawesomemod$boatFly(CallbackInfo ci) {
        if (!BoatFlyData.isEnabled()) return;

        class_10255 boat = (class_10255) (Object) this;
        class_310 mc = class_310.method_1551();

        // Only apply when the local player is the driver
        if (mc.field_1724 == null || !boat.method_5626(mc.field_1724)
                || boat.method_5642() != mc.field_1724) {
            return;
        }
        if (mc.field_1755 != null) return;

        class_315 o = mc.field_1690;
        float forward = (o.field_1894.method_1434()    ? 1f : 0f) - (o.field_1881.method_1434()  ? 1f : 0f);
        float strafeR = (o.field_1849.method_1434() ? 1f : 0f) - (o.field_1913.method_1434()  ? 1f : 0f);
        float vert    = (o.field_1903.method_1434()  ? 1f : 0f) - (o.field_1832.method_1434() ? 1f : 0f);

        float yawRad = (float) Math.toRadians(boat.method_36454());
        double sinY = Math.sin(yawRad);
        double cosY = Math.cos(yawRad);

        double dx = -forward * sinY - strafeR * cosY;
        double dz =  forward * cosY - strafeR * sinY;

        // Normalize horizontal so diagonal isn't faster
        double horiz = Math.sqrt(dx * dx + dz * dz);
        if (horiz > 1.0) { dx /= horiz; dz /= horiz; }

        float speed = BoatFlyData.getSpeed();
        boat.method_18799(new class_243(dx * speed, vert * speed, dz * speed));

        // Prevent the boat from taking fall damage
        boat.field_6017 = 0f;
    }
}
