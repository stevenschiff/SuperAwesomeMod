package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.ItemPhysicsData;
import net.minecraft.class_10039;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import net.minecraft.class_5819;
import net.minecraft.class_7833;
import net.minecraft.class_916;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_916.class)
public abstract class ItemEntityRendererMixin {

    @Shadow @Final private class_5819 random;

    @Inject(method = "submit(Lnet/minecraft/client/renderer/entity/state/ItemEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
            at = @At("HEAD"), cancellable = true)
    private void superawesomemod$flatItemPhysics(
            class_10039 state, class_4587 poseStack,
            class_11659 collector, class_12075 cameraState,
            CallbackInfo ci) {
        if (!ItemPhysicsData.isEnabled()) return;
        if (state.field_55310.method_65606()) {
            ci.cancel();
            return;
        }

        poseStack.method_22903();

        class_238 bounds = state.field_55310.method_72173();
        float depth = (float) bounds.method_17941();
        boolean isFlatItem = depth < 0.0625f;

        // Stable random Y rotation per entity so items don't all face the same way
        random.method_43052(state.field_55312);
        float yRot = random.method_43057() * 360.0f;

        if (isFlatItem) {
            // Flat sprite item (sword, stick, etc.): lay face-up on the ground
            poseStack.method_46416(0.0f, 0.003f, 0.0f);
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(90.0f));
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(yRot));
        } else {
            // 3D block item (cobblestone, chest, etc.): sit on ground, no bob/spin
            float groundY = (float) (-bounds.field_1322);
            poseStack.method_46416(0.0f, groundY, 0.0f);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(yRot));
        }

        // Render item model(s) using the public static helper
        class_916.method_72986(
                poseStack, collector, state.field_61820, state, random, bounds);

        poseStack.method_22909();
        ci.cancel();
    }
}
