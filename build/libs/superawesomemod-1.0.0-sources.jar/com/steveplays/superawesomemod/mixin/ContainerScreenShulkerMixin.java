package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.ShulkerTooltipData;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1735;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2480;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_9288;
import net.minecraft.class_9334;

@Mixin(class_465.class)
public abstract class ContainerScreenShulkerMixin {

    @Shadow protected class_1735 hoveredSlot;

    @Unique private static final int SLOT_SIZE    = 18;
    @Unique private static final int COLS         = 9;
    @Unique private static final int ROWS         = 3;
    @Unique private static final int PADDING      = 7;
    @Unique private static final int TITLE_HEIGHT = 12;

    /**
     * Returns true when the shulker preview should be active: feature enabled,
     * shift held, and hovering a shulker box item.
     */
    @Unique
    private boolean superawesomemod$shouldShowPreview() {
        if (!ShulkerTooltipData.isEnabled()) return false;
        long handle = GLFW.glfwGetCurrentContext();
        boolean shiftHeld = GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                         || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (!shiftHeld) return false;
        if (this.hoveredSlot == null || !this.hoveredSlot.method_7681()) return false;
        class_1799 stack = this.hoveredSlot.method_7677();
        if (!(stack.method_7909() instanceof class_1747 blockItem)) return false;
        return blockItem.method_7711() instanceof class_2480;
    }

    /**
     * Suppress the vanilla tooltip when our shulker preview is showing.
     */
    @Inject(method = "renderTooltip", at = @At("HEAD"), cancellable = true)
    private void superawesomemod$hideVanillaTooltip(class_332 graphics, int mouseX, int mouseY, CallbackInfo ci) {
        if (superawesomemod$shouldShowPreview()) {
            ci.cancel();
        }
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void superawesomemod$renderShulkerPreview(
            class_332 graphics, int mouseX, int mouseY, float partialTick,
            CallbackInfo ci) {

        if (!superawesomemod$shouldShowPreview()) return;

        class_1799 stack = this.hoveredSlot.method_7677();

        // Read shulker contents via 1.21.x component API
        class_9288 contents = stack.method_58694(class_9334.field_49622);
        if (contents == null) return;

        // Collect items into a list for indexed access
        List<class_1799> items = new ArrayList<>();
        contents.method_57489().forEach(items::add);
        if (items.isEmpty()) return;

        // Pad to 27 slots so grid positions are correct
        while (items.size() < 27) {
            items.add(class_1799.field_8037);
        }

        // Compute scale: scale 1 -> 0.5x, scale 10 -> 2.0x
        int scale = ShulkerTooltipData.getScale();
        float scaleFactor = 0.5f + (scale - 1) * (1.5f / 9.0f);

        // Tooltip dimensions in screen pixels
        int bgW = COLS * SLOT_SIZE + PADDING * 2;
        int bgH = ROWS * SLOT_SIZE + TITLE_HEIGHT + PADDING * 2;
        int totalW = (int) (bgW * scaleFactor);
        int totalH = (int) (bgH * scaleFactor);

        // Position near cursor with edge clamping
        class_310 mc = class_310.method_1551();
        int screenW = graphics.method_51421();
        int screenH = graphics.method_51443();

        int tooltipX = mouseX + 12;
        int tooltipY = mouseY - 12;

        if (tooltipX + totalW > screenW) tooltipX = mouseX - totalW - 4;
        if (tooltipY + totalH > screenH) tooltipY = screenH - totalH;
        if (tooltipX < 0) tooltipX = 0;
        if (tooltipY < 0) tooltipY = 0;

        // Use the 1.21.11 Matrix3x2fStack API (pushMatrix/popMatrix, 2D translate/scale)
        graphics.method_51448().pushMatrix();
        graphics.method_51448().translate((float) tooltipX, (float) tooltipY);
        graphics.method_51448().scale(scaleFactor, scaleFactor);

        // Background
        graphics.method_25294(0, 0, bgW, bgH, 0xCC100010);

        // Border (1px, purple tint)
        int bc = 0xFF8040C0;
        graphics.method_25294(0, 0, bgW, 1, bc);
        graphics.method_25294(0, bgH - 1, bgW, bgH, bc);
        graphics.method_25294(0, 0, 1, bgH, bc);
        graphics.method_25294(bgW - 1, 0, bgW, bgH, bc);

        // Shulker box name
        class_2561 name = stack.method_7964();
        graphics.method_51439(mc.field_1772, name, PADDING, PADDING, 0xFFFFFF, true);

        // Item grid
        int gridX = PADDING;
        int gridY = PADDING + TITLE_HEIGHT;

        for (int i = 0; i < Math.min(items.size(), 27); i++) {
            class_1799 slotStack = items.get(i);
            if (slotStack.method_7960()) continue;

            int col = i % COLS;
            int row = i / COLS;
            int ix = gridX + col * SLOT_SIZE + 1;
            int iy = gridY + row * SLOT_SIZE + 1;

            graphics.method_51427(slotStack, ix, iy);
            graphics.method_51431(mc.field_1772, slotStack, ix, iy);
        }

        graphics.method_51448().popMatrix();
    }
}
