package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.MotionBlurRenderer;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import net.minecraft.class_9920;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public abstract class GameRendererMotionBlurMixin {

    @Shadow @Final private class_9920 resourcePool;

    @Inject(method = "render", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/LevelRenderer;doEntityOutline()V",
            shift = At.Shift.AFTER))
    private void superawesomemod$afterEntityOutline(class_9779 deltaTracker, boolean bl, CallbackInfo ci) {
        MotionBlurRenderer.onRenderPost(this.resourcePool);
    }
}
