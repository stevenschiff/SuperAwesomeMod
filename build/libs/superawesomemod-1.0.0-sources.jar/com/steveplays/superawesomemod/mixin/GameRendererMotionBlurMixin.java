package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.MotionBlurRenderer;
import net.minecraft.class_757;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
public abstract class GameRendererMotionBlurMixin {

    @Inject(method = "renderLevel", at = @At("TAIL"))
    private void superawesomemod$applyMotionBlur(class_9779 deltaTracker, CallbackInfo ci) {
        MotionBlurRenderer.applyMotionBlur();
    }
}
