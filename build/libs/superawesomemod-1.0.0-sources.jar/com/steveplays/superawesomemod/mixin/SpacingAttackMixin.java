package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.SpacingTracker;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Measures the gap the instant we commit to a swing.
 *
 * <p>This is the point where both positions are still exactly what we saw when we
 * decided to click, so the recorded number is the spacing we actually chose. Waiting
 * for the server's damage event instead would fold our ping into the measurement.
 *
 * <p>Observation only — it never influences whether the attack proceeds.
 */
@Mixin(class_636.class)
public abstract class SpacingAttackMixin {

    @Inject(method = "attack", at = @At("HEAD"))
    private void superawesomemod$recordSpacing(class_1657 player, class_1297 target, CallbackInfo ci) {
        SpacingTracker.recordSwing(target);
    }
}
