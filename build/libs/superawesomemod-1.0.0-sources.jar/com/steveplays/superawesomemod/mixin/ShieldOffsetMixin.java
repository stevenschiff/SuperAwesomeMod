package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.ShieldData;
import com.steveplays.superawesomemod.ShieldRenderFlag;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Shield: shifts the first-person shield up or down, and marks the window so
 * {@link ShieldTransparencyMixin} knows the shield being drawn is ours.
 *
 * <p>The translate happens at HEAD, before vanilla's own arm transforms, so it acts in
 * view space — a straightforward "move it up/down the screen" rather than something
 * that twists with the arm animation.
 *
 * <p>The push is tracked in a field rather than assumed, because another mixin on this
 * same method can cancel it. That cannot currently collide (this only touches shields,
 * the sword-blocking mixin only cancels for swords) but an unbalanced pose stack
 * corrupts every later draw call in the frame, which is not a failure worth risking on
 * an assumption.
 */
@Mixin(class_759.class)
public abstract class ShieldOffsetMixin {

    @Unique
    private boolean superawesomemod$shieldPushed = false;

    @Inject(method = "renderArmWithItem", at = @At("HEAD"))
    private void superawesomemod$shieldBegin(
            class_742 player, float partialTicks, float pitch,
            class_1268 hand, float swingProgress, class_1799 itemStack,
            float equipProgress, class_4587 poseStack,
            class_11659 collector, int combinedLight,
            CallbackInfo ci) {

        this.superawesomemod$shieldPushed = false;
        if (!ShieldData.isEnabled()) return;
        if (itemStack.method_7960() || !itemStack.method_31574(class_1802.field_8255)) return;

        ShieldRenderFlag.set(true);

        // "Used" means raised: for a shield, blocking is item use, and we check the
        // stack identity so the offhand shield doesn't follow a main-hand item's use.
        boolean blocking = player.method_6115() && player.method_6030() == itemStack;
        float offset = ShieldData.offsetFor(blocking);
        if (offset == 0.0f) return;

        poseStack.method_22903();
        poseStack.method_46416(0.0f, offset, 0.0f);
        this.superawesomemod$shieldPushed = true;
    }

    @Inject(method = "renderArmWithItem", at = @At("RETURN"))
    private void superawesomemod$shieldEnd(
            class_742 player, float partialTicks, float pitch,
            class_1268 hand, float swingProgress, class_1799 itemStack,
            float equipProgress, class_4587 poseStack,
            class_11659 collector, int combinedLight,
            CallbackInfo ci) {

        ShieldRenderFlag.set(false);

        if (this.superawesomemod$shieldPushed) {
            poseStack.method_22909();
            this.superawesomemod$shieldPushed = false;
        }
    }
}
