package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.FartherPlayersData;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_4604;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Override the shouldRender check on EntityRenderer so that player entities
 * are visible up to the configured distance (64-512 blocks) instead of the
 * default tracking range.
 */
@Mixin(class_897.class)
public abstract class FartherPlayersMixin<T extends class_1297, S extends class_10017> {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void superawesomemod$fartherPlayers(T entity, class_4604 frustum, double camX, double camY, double camZ,
                                                 CallbackInfoReturnable<Boolean> cir) {
        if (!FartherPlayersData.isEnabled()) return;
        if (!(entity instanceof class_1657)) return;

        // Always render player entities within the configured distance.
        double dx = entity.method_23317() - camX;
        double dy = entity.method_23318() - camY;
        double dz = entity.method_23321() - camZ;
        double distSq = dx * dx + dy * dy + dz * dz;
        double maxDist = FartherPlayersData.getDistance();
        if (distSq <= maxDist * maxDist) {
            cir.setReturnValue(true);
        }
    }
}
