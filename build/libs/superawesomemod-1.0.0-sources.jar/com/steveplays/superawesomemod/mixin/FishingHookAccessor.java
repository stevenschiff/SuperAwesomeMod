package com.steveplays.superawesomemod.mixin;

import net.minecraft.class_1536;
import net.minecraft.class_2940;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes the hook's synced "biting" flag.
 *
 * <p>The server tells every client when a fish is on the line — that is how the bobber
 * animates — so the bite is a fact we are given rather than something to infer from a
 * splash sound or the bobber's vertical speed. The accessor is private and static, hence
 * this.
 */
@Mixin(class_1536.class)
public interface FishingHookAccessor {

    @Accessor("DATA_BITING")
    static class_2940<Boolean> superawesomemod$dataBiting() {
        throw new AssertionError();
    }
}
