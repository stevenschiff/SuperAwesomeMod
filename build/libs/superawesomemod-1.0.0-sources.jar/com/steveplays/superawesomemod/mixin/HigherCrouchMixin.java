package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.HigherCrouchData;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Higher Crouch: instant crouch/uncrouch with barely any camera dip (1.8 style).
 *
 * Bypasses vanilla's smooth crouch interpolation entirely by forcing the camera
 * to the correct absolute eye height each frame. When crouching the camera
 * instantly drops to 1.54 (only 0.08 below standing); when releasing shift
 * the camera instantly returns to 1.62.
 */
@Mixin(value = class_4184.class, priority = 1050)
public abstract class HigherCrouchMixin {

    @Shadow private class_243 position;
    @Shadow protected abstract void setPosition(class_243 pos);

    private static final double STANDING_EYE_HEIGHT = 1.62;
    private static final double CROUCH_EYE_HEIGHT = 1.54;

    @Unique private boolean hasCrouchedOnce = false;

    @Inject(method = "setup", at = @At("TAIL"))
    private void superawesomemod$higherCrouch(class_1937 level, class_1297 entity, boolean detached,
                                               boolean mirror, float partialTick, CallbackInfo ci) {
        if (!HigherCrouchData.isEnabled()) return;
        if (!(entity instanceof class_1657 player)) return;
        if (detached) return;

        boolean crouching = player.method_18276();
        double lerpedFeetY = player.field_5971 + (player.method_23318() - player.field_5971) * partialTick;

        if (crouching) {
            // Force camera to our crouch eye height instantly — no interpolation.
            setPosition(new class_243(this.position.field_1352, lerpedFeetY + CROUCH_EYE_HEIGHT, this.position.field_1350));
            hasCrouchedOnce = true;
        } else if (hasCrouchedOnce) {
            // Not crouching — if vanilla's camera is below standing eye height,
            // it's still playing the stand-up interpolation. Force it to
            // standing height every frame until vanilla catches up.
            double standingEyeY = lerpedFeetY + STANDING_EYE_HEIGHT;
            if (this.position.field_1351 < standingEyeY - 0.001) {
                setPosition(new class_243(this.position.field_1352, standingEyeY, this.position.field_1350));
            }
        }
    }
}
