package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.HigherCrouchData;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_4048;
import net.minecraft.class_4050;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Makes the crouch height higher so the player barely ducks.
 * Vanilla crouching dims are ~1.5 tall with ~1.27 eye height.
 * We override to 1.65 tall with ~1.54 eye height for a subtle dip.
 */
@Mixin(class_1297.class)
public abstract class HigherCrouchMixin {

    @Inject(method = "getDimensions", at = @At("RETURN"), cancellable = true)
    private void superawesomemod$higherCrouch(class_4050 pose, CallbackInfoReturnable<class_4048> cir) {
        if (!HigherCrouchData.isEnabled()) return;
        if (!((Object) this instanceof class_1657)) return;
        if (pose != class_4050.field_18081) return;

        class_4048 original = cir.getReturnValue();
        // Raise crouch height from ~1.5 to 1.65, eye height from ~1.27 to 1.54
        float newHeight = 1.65f;
        float newEyeHeight = 1.54f;
        cir.setReturnValue(class_4048.method_18384(original.comp_2185(), newHeight)
            .method_55685(newEyeHeight));
    }
}
