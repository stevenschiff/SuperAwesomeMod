package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.HigherCrouchData;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_4050;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Higher Crouch: instant crouch/uncrouch with barely any camera dip (1.8 style).
 *
 * Only activates when the player is in the CROUCHING pose — crawling, swimming,
 * elytra flight, and other poses are left at their vanilla camera height.
 *
 * Also syncs the entity's eye height to the camera position so the raycast
 * (crosshair target) matches what the player sees.
 */
@Mixin(value = class_4184.class, priority = 1050)
public abstract class HigherCrouchMixin {

    @Shadow private class_243 position;
    @Shadow protected abstract void setPosition(class_243 pos);

    private static final double STANDING_EYE_HEIGHT = 1.62;
    private static final double CROUCH_EYE_HEIGHT = 1.54;

    @Unique private boolean hasCrouchedOnce = false;

    @Inject(method = "setup", at = @At("TAIL"))
    private void superawesomemod$higherCrouch(class_1937 level, class_1297 entity, boolean detached,
                                               boolean mirror, float partialTick, CallbackInfo ci) {
        if (!HigherCrouchData.isEnabled()) return;
        if (!(entity instanceof class_1657 player)) return;
        if (detached) return;

        class_4050 pose = player.method_18376();
        double lerpedFeetY = player.field_5971 + (player.method_23318() - player.field_5971) * partialTick;

        if (pose == class_4050.field_18081) {
            // Force camera to our crouch eye height instantly — no interpolation.
            setPosition(new class_243(this.position.field_1352, lerpedFeetY + CROUCH_EYE_HEIGHT, this.position.field_1350));
            // Sync entity eye height so raycasts start from the same position as the camera.
            ((EntityEyeHeightAccessor) player).superawesomemod$setEyeHeight((float) CROUCH_EYE_HEIGHT);
            hasCrouchedOnce = true;
        } else if (hasCrouchedOnce && pose == class_4050.field_18076) {
            // Only force standing height when actually standing — not when
            // crawling (SWIMMING), flying (FALL_FLYING), or any other non-standing pose.
            double standingEyeY = lerpedFeetY + STANDING_EYE_HEIGHT;
            if (this.position.field_1351 < standingEyeY - 0.001) {
                setPosition(new class_243(this.position.field_1352, standingEyeY, this.position.field_1350));
            }
        }
    }
}
