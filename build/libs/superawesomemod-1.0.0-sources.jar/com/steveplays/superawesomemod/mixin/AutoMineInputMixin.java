package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.AutoMineData;
import com.steveplays.superawesomemod.AutoMineHandler;
import net.minecraft.class_10185;
import net.minecraft.class_2338;
import net.minecraft.class_241;
import net.minecraft.class_310;
import net.minecraft.class_743;
import net.minecraft.class_744;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Walks the player for the auto miner by writing the same movement input the keyboard
 * would produce.
 *
 * <p>Overwriting {@code moveVector} and {@code keyPresses} at the tail of
 * {@code KeyboardInput.tick()} means everything downstream — friction, collision, the
 * position packets the server validates — behaves exactly as if the keys were held. The
 * alternative, nudging the player's position directly, would desync and read as teleporting.
 *
 * <p>The move vector is in the player's local frame, so the heading is rotated into
 * player space; otherwise the walker would stride off in a fixed world direction whenever
 * the camera turned.
 */
@Mixin(class_743.class)
public abstract class AutoMineInputMixin extends class_744 {

    @Inject(method = "tick", at = @At("TAIL"))
    private void superawesomemod$driveAutoMine(CallbackInfo ci) {
        if (!AutoMineData.isRunning()) return;

        class_2338 goal = AutoMineHandler.getMoveTarget();
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null) return;

        if (goal == null) {
            // Standing still is a state too — mining, or stopped.
            this.field_55868 = class_241.field_1340;
            this.field_54155 = new class_10185(false, false, false, false, false,
                                        this.field_54155.comp_3164(), false);
            return;
        }

        double dx = (goal.method_10263() + 0.5) - player.method_23317();
        double dz = (goal.method_10260() + 0.5) - player.method_23321();

        // World heading rotated into the player's local frame.
        float yawRad = (float) Math.toRadians(player.method_36454());
        double sin = Math.sin(yawRad);
        double cos = Math.cos(yawRad);
        double forward = dz * cos + dx * sin;
        double strafe  = dx * cos - dz * sin;

        double len = Math.sqrt(forward * forward + strafe * strafe);
        if (len < 1.0E-4) {
            this.field_55868 = class_241.field_1340;
            return;
        }
        forward /= len;
        strafe /= len;

        this.field_55868 = new class_241((float) strafe, (float) forward);

        boolean jump = AutoMineHandler.wantsJump();
        this.field_54155 = new class_10185(
            forward > 0.3, forward < -0.3, strafe > 0.3, strafe < -0.3,
            jump, this.field_54155.comp_3164(), false);
    }
}
