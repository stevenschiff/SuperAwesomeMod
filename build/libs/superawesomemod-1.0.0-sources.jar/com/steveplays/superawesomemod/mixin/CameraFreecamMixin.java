package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.FreecamData;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// Higher priority than CameraFreeLookMixin (default 1000) so freecam overrides
// any free-look offsets when both happen to be active.
@Mixin(value = class_4184.class, priority = 1100)
public abstract class CameraFreecamMixin {

    @Shadow protected abstract void setPosition(class_243 pos);
    @Shadow protected abstract void setRotation(float yaw, float pitch);

    @Inject(method = "setup", at = @At("TAIL"))
    private void superawesomemod$applyFreecam(class_1937 level, class_1297 entity, boolean detached,
                                              boolean mirror, float partialTick, CallbackInfo ci) {
        if (!FreecamData.isEnabled()) return;
        // Position is updated at tick rate (20 Hz) — interpolate to render rate so
        // the camera glides between ticks instead of stepping. Rotation is already
        // sampled per-frame inside MouseHandler.turnPlayer, so use it raw.
        setPosition(new class_243(
            FreecamData.getInterpolatedX(partialTick),
            FreecamData.getInterpolatedY(partialTick),
            FreecamData.getInterpolatedZ(partialTick)));
        setRotation(FreecamData.getYaw(), FreecamData.getPitch());
    }
}
