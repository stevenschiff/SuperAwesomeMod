package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.PvpDetectorTracker;
import net.minecraft.class_634;
import net.minecraft.class_8143;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Capture every damage event the client is informed about and forward it to
 * the PvP detector tracker.
 *
 * Injecting at TAIL guarantees we run on the main thread — the vanilla method
 * begins with {@code PacketUtils.ensureRunningOnSameThread} which throws and
 * reschedules when invoked on the netty thread, so TAIL is only reached on
 * the main-thread invocation.
 */
@Mixin(class_634.class)
public abstract class PvpDetectorDamageMixin {

    @Inject(method = "handleDamageEvent", at = @At("TAIL"))
    private void superawesomemod$onDamageEvent(class_8143 packet, CallbackInfo ci) {
        int attackerId = packet.comp_1269();
        if (attackerId < 0) return;
        PvpDetectorTracker.recordHit(attackerId, packet.comp_1267());
    }
}
