package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.FlightData;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Flight: allows the player to fly in survival mode by overriding movement
 * each tick. Applies velocity based on WASD/Space/Shift input and the
 * player's look direction, then zeros out gravity effects.
 */
@Mixin(class_746.class)
public abstract class FlightMixin {

    @Inject(method = "aiStep", at = @At("TAIL"))
    private void superawesomemod$applyFlight(CallbackInfo ci) {
        if (!FlightData.isEnabled()) return;

        class_746 self = (class_746) (Object) this;
        class_310 mc = class_310.method_1551();
        if (mc.field_1755 != null) return;

        class_315 o = mc.field_1690;
        float forward = (o.field_1894.method_1434()    ? 1f : 0f) - (o.field_1881.method_1434()  ? 1f : 0f);
        float strafeR = (o.field_1849.method_1434() ? 1f : 0f) - (o.field_1913.method_1434()  ? 1f : 0f);
        float vert    = (o.field_1903.method_1434()  ? 1f : 0f) - (o.field_1832.method_1434() ? 1f : 0f);

        float yawRad = (float) Math.toRadians(self.method_36454());
        double sinY = Math.sin(yawRad);
        double cosY = Math.cos(yawRad);

        double dx = -forward * sinY - strafeR * cosY;
        double dz =  forward * cosY - strafeR * sinY;

        // Normalize horizontal so diagonal isn't faster
        double horiz = Math.sqrt(dx * dx + dz * dz);
        if (horiz > 1.0) { dx /= horiz; dz /= horiz; }

        float speed = FlightData.getSpeed();
        self.method_18799(new class_243(dx * speed, vert * speed, dz * speed));

        // Prevent fall damage accumulation
        self.field_6017 = 0f;
    }
}
