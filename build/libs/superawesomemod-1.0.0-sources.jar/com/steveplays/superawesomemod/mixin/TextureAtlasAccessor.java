package com.steveplays.superawesomemod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_1058;
import net.minecraft.class_1059;

/** The atlas keeps its sprite list private; we need it to find the animated ones. */
@Mixin(class_1059.class)
public interface TextureAtlasAccessor {

    @Accessor("sprites")
    List<class_1058> superawesomemod$sprites();
}
