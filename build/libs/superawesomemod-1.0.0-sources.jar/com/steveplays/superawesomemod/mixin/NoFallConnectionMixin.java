package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.NoFallData;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Intercepts outgoing movement packets and sets onGround = true
 * so the server never accumulates fall distance for this player.
 */
@Mixin(class_2535.class)
public abstract class NoFallConnectionMixin {

    @Inject(method = "send(Lnet/minecraft/network/protocol/Packet;)V", at = @At("HEAD"))
    private void superawesomemod$noFallPacket(class_2596<?> packet, CallbackInfo ci) {
        if (NoFallData.isEnabled() && packet instanceof class_2828) {
            ((NoFallPacketAccessor) packet).setOnGround(true);
        }
    }
}
