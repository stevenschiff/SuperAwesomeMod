package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.ZoomData;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_757.class)
public abstract class GameRendererZoomMixin {

    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void superawesomemod$applyZoom(class_4184 camera, float partialTick, boolean useFovSetting,
                                            CallbackInfoReturnable<Float> cir) {
        if (!ZoomData.isActive()) return;
        cir.setReturnValue(cir.getReturnValueF() * ZoomData.getMultiplier(partialTick));
    }
}
