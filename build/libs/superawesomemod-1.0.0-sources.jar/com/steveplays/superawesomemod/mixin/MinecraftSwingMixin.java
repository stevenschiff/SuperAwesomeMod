package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.OldPvpData;
import net.minecraft.class_1268;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public abstract class MinecraftSwingMixin {

    @Shadow public class_746 player;
    @Shadow public class_315 options;

    /**
     * Swing while eating / drawing bow: vanilla's handleKeybinds drains all
     * attack clicks when isUsingItem() is true, so startAttack is never called.
     * We intercept at the top of handleKeybinds to consume one attack click
     * per tick and fire the swing animation instead.
     */
    @Inject(method = "handleKeybinds", at = @At("HEAD"))
    private void superawesomemod$swingWhileEating(CallbackInfo ci) {
        if (player == null) return;
        if (!OldPvpData.isSwingWhileUsingEnabled()) return;
        if (!player.method_6115()) return;

        if (options.field_1886.method_1436()) {
            player.method_6104(class_1268.field_5808);
        }
    }

    /**
     * Swing while custom sword blocking: startAttack IS called here because
     * isUsingItem() is false for swords. We fire the swing and cancel the
     * actual attack.
     */
    @Inject(method = "startAttack", at = @At("HEAD"))
    private void superawesomemod$swingWhileBlocking(CallbackInfoReturnable<Boolean> cir) {
        if (player == null) return;
        if (!OldPvpData.isSwingWhileUsingEnabled()) return;

        if (OldPvpData.isCustomBlocking()) {
            player.method_6104(class_1268.field_5808);
            cir.setReturnValue(false);
        }
    }
}
