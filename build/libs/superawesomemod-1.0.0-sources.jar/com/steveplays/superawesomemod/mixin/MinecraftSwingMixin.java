package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.OldPvpData;
import net.minecraft.class_1268;
import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_310.class)
public abstract class MinecraftSwingMixin {

    @Shadow public class_746 player;

    @Inject(method = "startAttack", at = @At("HEAD"))
    private void superawesomemod$swingWhileUsing(CallbackInfoReturnable<Boolean> cir) {
        if (player == null) return;
        if (!OldPvpData.isSwingWhileUsingEnabled()) return;

        // Swing while eating / drawing bow / using any item
        if (player.method_6115()) {
            player.method_6104(class_1268.field_5808);
            return;
        }

        // Swing while custom sword blocking (prevent actual attack)
        if (OldPvpData.isCustomBlocking()) {
            player.method_6104(class_1268.field_5808);
            cir.setReturnValue(false);
        }
    }
}
