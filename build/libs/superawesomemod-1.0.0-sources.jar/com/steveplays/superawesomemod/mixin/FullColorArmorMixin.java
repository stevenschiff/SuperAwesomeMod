package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.FullColorArmorTint;
import com.steveplays.superawesomemod.FullColorTinted;
import net.minecraft.class_10034;
import net.minecraft.class_11659;
import net.minecraft.class_4587;
import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Full Colour, armour half — part one: publishes the tint for the duration of one
 * entity's armour submission.
 *
 * <p>Armour matters rather than being a nice-to-have. A fully kitted player is mostly
 * armour, so tinting only the body would barely show.
 */
@Mixin(class_970.class)
public abstract class FullColorArmorMixin {

    @Inject(
        method = "submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V",
        at = @At("HEAD")
    )
    private void superawesomemod$beginArmourTint(class_4587 poseStack, class_11659 collector,
                                                 int light, class_10034 state,
                                                 float yRot, float xRot, CallbackInfo ci) {
        FullColorArmorTint.set(((FullColorTinted) state).superawesomemod$getFullColorTint());
    }

    @Inject(
        method = "submit(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;ILnet/minecraft/client/renderer/entity/state/HumanoidRenderState;FF)V",
        at = @At("RETURN")
    )
    private void superawesomemod$endArmourTint(class_4587 poseStack, class_11659 collector,
                                               int light, class_10034 state,
                                               float yRot, float xRot, CallbackInfo ci) {
        FullColorArmorTint.clear();
    }
}
