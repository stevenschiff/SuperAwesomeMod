package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.AntiHungerData;
import com.steveplays.superawesomemod.AntiHungerHandler;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2848;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Suppresses vanilla's own sprint reporting so {@link AntiHungerHandler} is the only
 * thing telling the server whether we sprint.
 *
 * <p>Same interception point as {@code NoFallConnectionMixin}. Both sprint actions are
 * dropped, not just START: leaving STOP to vanilla would let it correct the server back
 * to the truth at arbitrary moments and undo the spoof mid-run.
 */
@Mixin(class_2535.class)
public abstract class AntiHungerSprintMixin {

    @Inject(method = "send(Lnet/minecraft/network/protocol/Packet;)V", at = @At("HEAD"), cancellable = true)
    private void superawesomemod$swallowSprintPackets(class_2596<?> packet, CallbackInfo ci) {
        if (!AntiHungerData.isWalkReportActive()) return;
        if (AntiHungerHandler.isSendingOwn()) return;
        if (!(packet instanceof class_2848 command)) return;

        class_2848.class_2849 action = command.method_12365();
        if (action == class_2848.class_2849.field_12981
            || action == class_2848.class_2849.field_12985) {
            ci.cancel();
        }
    }
}
