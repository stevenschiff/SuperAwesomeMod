package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.SchematicData;
import com.steveplays.superawesomemod.SchematicPlacement;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Easy Place mixin: when auto-place is active (both toggles on),
 * prevents placing the wrong block type at a schematic position.
 * This helps the player avoid mistakes during schematic building.
 */
@Mixin(class_636.class)
public abstract class SchematicEasyPlaceMixin {

    @Inject(method = "performUseItemOn", at = @At("HEAD"), cancellable = true)
    private void superawesomemod$onUseItemOn(class_746 player, class_3965 hitResult,
                                              CallbackInfoReturnable<class_1269> cir) {
        if (!SchematicData.isAutoPlaceActive()) return;

        SchematicPlacement placement = SchematicData.getCurrentPlacement();
        if (placement == null) return;

        // Determine where the new block would be placed
        class_2338 placePos = hitResult.method_17777().method_10093(hitResult.method_17780());

        // Check if this position is within the schematic bounds
        if (!placement.containsPos(placePos)) return;

        // Get the expected block at this position
        class_2680 expected = placement.getBlockStateAt(placePos);
        if (expected.method_26215()) return; // Schematic expects air here, allow any placement

        // Check if the player is holding the correct block type
        var mainHand = player.method_6047();
        if (mainHand.method_7960() || !(mainHand.method_7909() instanceof class_1747 blockItem)) {
            return; // Not placing a block, let it through
        }

        class_2248 heldBlock = blockItem.method_7711();
        class_2248 expectedBlock = expected.method_26204();

        // If the held block doesn't match the expected block type, cancel placement
        if (heldBlock != expectedBlock) {
            cir.setReturnValue(class_1269.field_5814);
        }
    }
}
