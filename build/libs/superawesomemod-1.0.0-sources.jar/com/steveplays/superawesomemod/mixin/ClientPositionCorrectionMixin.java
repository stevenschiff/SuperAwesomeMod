package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.PlayerFlyData;
import net.minecraft.class_2535;
import net.minecraft.class_2708;
import net.minecraft.class_2793;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Intercepts the server's rubber-band position correction while mod flight is active.
 *
 * When a survival player flies, the server periodically sends
 * ClientboundPlayerPositionPacket (handled by handleMovePlayer in 1.21.11)
 * to snap the player back to the ground.
 *
 * This mixin:
 *   1. Sends the teleport acknowledgment so the server stops resending the correction.
 *   2. Cancels the actual position/rotation update so the client stays flying.
 */
@Mixin(class_634.class)
public abstract class ClientPositionCorrectionMixin {

    // The underlying network connection — inherited from ClientCommonPacketListenerImpl.
    @Shadow protected class_2535 connection;

    @Inject(method = "handleMovePlayer", at = @At("HEAD"), cancellable = true)
    private void cancelRubberBandWhenFlying(class_2708 packet, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        if (!PlayerFlyData.isEnabled(mc.field_1724.method_5667())) return;

        // Send the teleport acknowledgment so the server considers this correction accepted
        // and stops resending it — but do NOT apply the position change.
        this.connection.method_10743(new class_2793(packet.comp_3133()));
        ci.cancel();
    }
}
