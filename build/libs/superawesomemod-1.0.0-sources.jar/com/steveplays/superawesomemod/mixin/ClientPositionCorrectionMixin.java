package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.PlayerFlyData;
import net.minecraft.class_2708;
import net.minecraft.class_2793;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public abstract class ClientPositionCorrectionMixin {

    @Inject(method = "handleMovePlayer", at = @At("HEAD"), cancellable = true)
    private void cancelRubberBandWhenFlying(class_2708 packet, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || mc.field_1724.field_3944 == null) return;
        if (!PlayerFlyData.isEnabled(mc.field_1724.method_5667())) return;

        // Ack the teleport so the server stops resending, but don't apply the position.
        mc.field_1724.field_3944.method_52787(new class_2793(packet.comp_3133()));
        ci.cancel();
    }
}
