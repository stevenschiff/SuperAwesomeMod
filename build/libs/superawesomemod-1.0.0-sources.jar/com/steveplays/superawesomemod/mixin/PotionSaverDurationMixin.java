package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.PotionSaverData;
import net.minecraft.class_1293;
import net.minecraft.class_4081;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Potion Saver, part two: skips the countdown for beneficial effects on us.
 *
 * <p>Cancelling here rather than restoring the duration afterwards means the timer
 * is never decremented in the first place, so an effect can't expire and be removed
 * mid-loop, and the recursive call this method makes into {@code hiddenEffect}
 * (a weaker same-effect instance waiting underneath, e.g. beacon Speed I sitting
 * under potion Speed II) is skipped along with it.
 *
 * <p>Split by {@link class_4081}, which is what the game already uses to
 * colour effect names in tooltips: only BENEFICIAL is held. HARMFUL runs out
 * normally — a Turtle Master splash keeps its Resistance and drops its Slowness —
 * and so does NEUTRAL, since effects like Glowing aren't a buff worth keeping.
 */
@Mixin(class_1293.class)
public abstract class PotionSaverDurationMixin {

    @Inject(method = "tickDownDuration", at = @At("HEAD"), cancellable = true)
    private void superawesomemod$holdDuration(CallbackInfo ci) {
        if (!PotionSaverData.isEnabled() || !PotionSaverData.isHolding()) return;

        class_1293 self = (class_1293) (Object) this;
        if (self.method_5579().comp_349().method_18792() != class_4081.field_18271) return;

        ci.cancel();
    }
}
