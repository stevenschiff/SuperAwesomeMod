package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.BHopData;
import com.steveplays.superawesomemod.FlightData;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * B Hop: jumps again the moment we land and holds the chosen speed through the arc.
 *
 * <p>Runs at the tail of {@code aiStep}, after this tick's move, so {@code onGround}
 * already reflects the landing — setting jump velocity here launches us on the next
 * tick, which is what makes the hopping continuous. Horizontal velocity is rewritten
 * every tick rather than only on takeoff, so speed carries through the air instead of
 * decaying to vanilla air control.
 */
@Mixin(class_746.class)
public abstract class BHopMixin {

    /** Vanilla jump impulse. Kept low deliberately: hops stay flat and fast. */
    private static final double JUMP_VELOCITY = 0.42;

    @Inject(method = "aiStep", at = @At("TAIL"))
    private void superawesomemod$bhop(CallbackInfo ci) {
        if (!BHopData.isEnabled()) return;
        // Flight writes delta movement at this same point; two features fighting over
        // it would give whichever mixin applied last.
        if (FlightData.isEnabled()) return;

        class_746 self = (class_746) (Object) this;
        class_310 mc = class_310.method_1551();
        if (mc.field_1755 != null) return;
        if (self.method_5765() || self.method_31549().field_7479) return;
        // Water and lava have their own movement rules; overriding them just makes
        // swimming unusable.
        if (self.method_5799() || self.method_5771()) return;

        class_315 o = mc.field_1690;
        float forward = (o.field_1894.method_1434()    ? 1f : 0f) - (o.field_1881.method_1434() ? 1f : 0f);
        float strafeR = (o.field_1849.method_1434() ? 1f : 0f) - (o.field_1913.method_1434() ? 1f : 0f);
        // Standing still should stand still, not hop in place.
        if (forward == 0f && strafeR == 0f) return;

        float yawRad = (float) Math.toRadians(self.method_36454());
        double sinY = Math.sin(yawRad);
        double cosY = Math.cos(yawRad);

        double dx = -forward * sinY - strafeR * cosY;
        double dz =  forward * cosY - strafeR * sinY;

        // Normalise so strafing diagonally isn't faster than running straight.
        double horiz = Math.sqrt(dx * dx + dz * dz);
        if (horiz > 1.0) { dx /= horiz; dz /= horiz; }

        float speed = BHopData.getSpeed();
        class_243 current = self.method_18798();
        double y = self.method_24828()
            ? JUMP_VELOCITY + self.method_37416()
            : current.field_1351;

        self.method_18800(dx * speed, y, dz * speed);
    }
}
