package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.FreeLookData;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4184.class)
public abstract class CameraFreeLookMixin {

    @Shadow public abstract float xRot();
    @Shadow public abstract float yRot();
    @Shadow public abstract class_243 position();
    @Shadow protected abstract void setRotation(float yaw, float pitch);
    @Shadow protected abstract void setPosition(class_243 pos);
    @Shadow protected abstract void move(float forward, float up, float right);

    // Camera manages its own interpolated eye height — shadow it to recompute entity eye pos.
    @Shadow private float eyeHeight;

    @Inject(method = "setup", at = @At("TAIL"))
    private void applyFreeLookOffset(class_1937 level, class_1297 entity, boolean detached, boolean mirror, float partialTick, CallbackInfo ci) {
        float yOff = FreeLookData.getYawOffset();
        float pOff = FreeLookData.getPitchOffset();
        if (yOff == 0f && pOff == 0f) return;

        float finalPitch = class_3532.method_15363(this.xRot() + pOff, -90f, 90f);

        if (detached) {
            // Third-person: the camera has already been moved backward from the entity eye.
            // We need to snap back to the eye position, apply the offset rotation, then
            // re-do the backward move so the camera orbits around the player.

            // Reconstruct entity eye position the same way Camera.setup() does.
            double eyeX = class_3532.method_16436(partialTick, entity.field_6014, entity.method_23317());
            double eyeY = class_3532.method_16436(partialTick, entity.field_6036, entity.method_23318()) + this.eyeHeight;
            double eyeZ = class_3532.method_16436(partialTick, entity.field_5969, entity.method_23321());
            class_243 eyePos = new class_243(eyeX, eyeY, eyeZ);

            // Distance the camera was placed at (already wall-clipped by getMaxZoom).
            float dist = (float) this.position().method_1022(eyePos);

            // Reset to eye, rotate with offset, orbit outward at the same distance.
            setPosition(eyePos);
            setRotation(this.yRot() + yOff, finalPitch);
            move(-dist, 0, 0);
        } else {
            // First-person: rotation alone is sufficient.
            setRotation(this.yRot() + yOff, finalPitch);
        }
    }
}
