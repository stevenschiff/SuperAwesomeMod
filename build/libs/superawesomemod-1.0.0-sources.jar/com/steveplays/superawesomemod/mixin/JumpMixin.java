package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.PlayerJumpData;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Multiplies the player's Y velocity immediately after the vanilla jump
 * impulse is applied, scaling jump height by the stored multiplier.
 *
 * Targets LivingEntity#jumpFromGround — called on both client (for movement
 * prediction) and server (for authoritative physics). In single-player the
 * static PlayerJumpData map is shared across both, so the command and mixin
 * stay in sync without any packet work.
 */
@Mixin(class_1309.class)
public abstract class JumpMixin {

    @Inject(method = "jumpFromGround", at = @At("RETURN"))
    private void onJumpFromGround(CallbackInfo ci) {
        class_1309 self = (class_1309) (Object) this;

        if (!(self instanceof class_1657 player)) return;

        float multiplier = PlayerJumpData.getMultiplier(player.method_5667());
        if (multiplier == PlayerJumpData.DEFAULT) return;

        class_243 velocity = self.method_18798();
        self.method_18800(velocity.field_1352, velocity.field_1351 * multiplier, velocity.field_1350);
    }
}
