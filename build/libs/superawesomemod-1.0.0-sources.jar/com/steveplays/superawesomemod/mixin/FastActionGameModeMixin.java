package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.FastActionData;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Fast Break and Auto Tool.
 *
 * <p>Vanilla parks a 5-tick {@code destroyDelay} after each block, and
 * {@code continueDestroyBlock} burns a tick doing nothing until it drains. That
 * delay is client-side only, so clearing it just removes dead time between blocks.
 * Breaking a single block still takes as long as it takes — the server tracks that
 * progress itself and would reject anything faster.
 */
@Mixin(class_636.class)
public abstract class FastActionGameModeMixin {

    @Shadow private int destroyDelay;

    @Inject(method = "continueDestroyBlock", at = @At("HEAD"))
    private void superawesomemod$fastBreak(class_2338 pos, class_2350 face, CallbackInfoReturnable<Boolean> cir) {
        if (FastActionData.isFastBreak()) {
            this.destroyDelay = 0;
        }
    }

    @Inject(method = "startDestroyBlock", at = @At("HEAD"))
    private void superawesomemod$autoTool(class_2338 pos, class_2350 face, CallbackInfoReturnable<Boolean> cir) {
        if (!FastActionData.isAutoTool()) return;

        class_310 mc = class_310.method_1551();
        class_1657 player = mc.field_1724;
        if (player == null || mc.field_1687 == null) return;

        class_2680 state = mc.field_1687.method_8320(pos);
        if (state.method_26215()) return;

        class_1661 inventory = player.method_31548();
        int bestSlot = inventory.method_67532();
        float bestSpeed = inventory.method_5438(bestSlot).method_7924(state);

        for (int i = 0; i < class_1661.method_7368(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            float speed = stack.method_7924(state);
            if (speed > bestSpeed) {
                bestSpeed = speed;
                bestSlot = i;
            }
        }

        // Only switch on a strict improvement, so an empty hand or an equally good
        // tool doesn't yank the selected slot around while building.
        if (bestSlot != inventory.method_67532()) {
            inventory.method_61496(bestSlot);
        }
    }
}
