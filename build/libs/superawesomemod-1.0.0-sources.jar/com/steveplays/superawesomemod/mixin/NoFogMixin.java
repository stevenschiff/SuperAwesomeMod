package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.NoFogData;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * Disables world fog by replacing the WORLD fog mode with NONE
 * when the No Fog feature is enabled.
 */
@Mixin(class_758.class)
public class NoFogMixin {

    @ModifyVariable(method = "getBuffer", at = @At("HEAD"), argsOnly = true)
    private class_758.class_4596 superawesomemod$noFog(class_758.class_4596 mode) {
        if (NoFogData.isEnabled() && mode == class_758.class_4596.field_60102) {
            return class_758.class_4596.field_60101;
        }
        return mode;
    }
}
