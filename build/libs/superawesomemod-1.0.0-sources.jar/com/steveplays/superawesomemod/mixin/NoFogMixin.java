package com.steveplays.superawesomemod.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import com.steveplays.superawesomemod.NoFogData;
import net.minecraft.class_757;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Disables world fog (underwater, nether, etc.) by replacing the WORLD fog
 * buffer with the NONE fog buffer when the No Fog feature is enabled.
 */
@Mixin(class_757.class)
public class NoFogMixin {

    @Redirect(
        method = "updateCamera",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/renderer/fog/FogRenderer;getBuffer(Lnet/minecraft/client/renderer/fog/FogRenderer$FogMode;)Lcom/mojang/blaze3d/buffers/GpuBufferSlice;",
            ordinal = 0
        )
    )
    private GpuBufferSlice superawesomemod$noFog(class_758 renderer, class_758.class_4596 mode) {
        if (NoFogData.isEnabled()) {
            return renderer.method_71109(class_758.class_4596.field_60101);
        }
        return renderer.method_71109(mode);
    }
}
