package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.InvincibilityData;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Invincibility: refuses damage aimed at us.
 *
 * <p>{@code hurtServer(ServerLevel, ...)} is the only place damage is resolved — the
 * signature demands a {@code ServerLevel}, so this is real exactly where our own
 * integrated server runs it and nowhere else. On someone else's server this method is
 * never ours to cancel, and no client-side alternative exists: refusing damage locally
 * would leave a full health bar on screen while the server killed us, which is worse
 * than the feature being absent.
 *
 * <p>Returning false rather than true matters — false is vanilla's "the damage did not
 * apply", which is what stops knockback, hurt animation and death from following.
 */
@Mixin(class_1309.class)
public abstract class InvincibilityMixin {

    @Inject(method = "hurtServer", at = @At("HEAD"), cancellable = true)
    private void superawesomemod$refuseDamage(class_3218 level, class_1282 source,
                                              float amount, CallbackInfoReturnable<Boolean> cir) {
        if (!InvincibilityData.isEnabled()) return;

        class_1309 self = (class_1309) (Object) this;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || !mc.field_1724.method_5667().equals(self.method_5667())) return;

        cir.setReturnValue(false);
    }
}
