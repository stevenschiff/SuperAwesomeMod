package com.steveplays.superawesomemod.mixin;

import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Accessor to mutate the onGround flag on outgoing movement packets.
 */
@Mixin(class_2828.class)
public interface NoFallPacketAccessor {
    @Accessor("onGround")
    @Mutable
    void setOnGround(boolean onGround);
}
