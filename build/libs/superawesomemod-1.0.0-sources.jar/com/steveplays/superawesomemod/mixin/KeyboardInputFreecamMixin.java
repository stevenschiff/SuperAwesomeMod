package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.FreecamData;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_743;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_743.class)
public abstract class KeyboardInputFreecamMixin {

    @Shadow public class_10185 keyPresses;
    @Shadow protected class_241 moveVector;

    @Inject(method = "tick", at = @At("TAIL"))
    private void superawesomemod$suppressInputDuringFreecam(CallbackInfo ci) {
        if (!FreecamData.isEnabled()) return;
        this.keyPresses = class_10185.field_54098;
        this.moveVector = class_241.field_1340;
    }
}
