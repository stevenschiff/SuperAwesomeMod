package com.steveplays.superawesomemod.mixin;

import com.steveplays.superawesomemod.FreecamData;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Suppresses local player movement input while freecam is active so the body
 * stays put while the camera flies free. The Input record is replaced with
 * EMPTY (all-false) and the move vector is zeroed.
 */
@Mixin(class_743.class)
public abstract class KeyboardInputFreecamMixin extends class_744 {

    @Shadow protected class_241 moveVector;

    @Inject(method = "tick", at = @At("TAIL"))
    private void superawesomemod$suppressInputDuringFreecam(CallbackInfo ci) {
        if (!FreecamData.isEnabled()) return;
        this.field_54155 = class_10185.field_54098;
        this.field_55868 = class_241.field_1340;
    }
}
