package com.steveplays.superawesomemod.mixin;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Accessor for Entity's eyeHeight field, used to sync the entity's
 * eye height with the higher-crouch camera position so raycasts match the camera.
 */
@Mixin(class_1297.class)
public interface EntityEyeHeightAccessor {

    @Accessor("eyeHeight")
    float superawesomemod$getEyeHeight();

    @Accessor("eyeHeight")
    void superawesomemod$setEyeHeight(float eyeHeight);
}
