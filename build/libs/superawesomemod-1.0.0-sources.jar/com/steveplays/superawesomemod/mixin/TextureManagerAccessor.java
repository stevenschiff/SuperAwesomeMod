package com.steveplays.superawesomemod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_1060;
import net.minecraft.class_1061;

/**
 * The set of textures Minecraft ticks. Every {@code TextureAtlas} is in here, which is a
 * shorter route to them than going through {@code ModelManager}'s private atlas manager.
 */
@Mixin(class_1060.class)
public interface TextureManagerAccessor {

    @Accessor("tickableTextures")
    Set<class_1061> superawesomemod$tickableTextures();
}
