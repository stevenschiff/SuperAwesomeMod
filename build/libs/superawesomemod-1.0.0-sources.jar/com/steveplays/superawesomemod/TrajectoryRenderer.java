package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Trajectory Preview: draws where the thing in your hand will land.
 *
 * <p>Steps the same maths the real projectile will use — the launch direction from
 * {@code Projectile.shootFromRotation}, then per tick {@code pos += velocity},
 * {@code velocity *= drag}, {@code velocity.y -= gravity} — with the constants read
 * out of the 1.21.11 classes rather than guessed, so the arc matches the shot
 * instead of merely resembling one. Purely local: nothing is sent, nothing changes.
 */
public final class TrajectoryRenderer {

    private static final int MAX_STEPS = 300;
    private static final float AIR_DRAG = 0.99F;

    private TrajectoryRenderer() {}

    /** Launch parameters for one kind of throwable. */
    private record Launch(float power, double gravity, float pitchOffset) {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(TrajectoryRenderer::onAfterEntities);
    }

    private static void onAfterEntities(WorldRenderContext ctx) {
        if (!TrajectoryData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        class_638 level = mc.field_1687;
        if (player == null || level == null) return;

        class_4597 consumers = ctx.consumers();
        if (consumers == null) return;

        Launch launch = launchFor(player);
        if (launch == null || launch.power() <= 0.0F) return;

        List<class_243> path = new ArrayList<>();
        class_243 impact = simulate(player, level, launch, path);
        if (path.size() < 2) return;

        class_4184 camera = ctx.gameRenderer().method_19418();
        class_243 camPos = camera.method_71156();
        class_4587.class_4665 pose = ctx.matrices().method_23760();
        Matrix4f matrix = pose.method_23761();
        class_4588 buf = consumers.method_73477(XrayLineRenderType.LINES_XRAY);

        for (int i = 0; i < path.size() - 1; i++) {
            line(buf, matrix, pose, path.get(i), path.get(i + 1), camPos, 1.0F, 1.0F, 1.0F);
        }

        if (impact != null) {
            drawMarker(buf, matrix, pose, impact, camPos);
        }
    }

    /** Which projectile the held items describe, or null if none of them throw anything. */
    private static Launch launchFor(class_746 player) {
        class_1799 main = player.method_6047();
        class_1799 off = player.method_6079();

        Launch fromMain = launchFor(player, main);
        return fromMain != null ? fromMain : launchFor(player, off);
    }

    private static Launch launchFor(class_746 player, class_1799 stack) {
        if (stack.method_7960()) return null;

        if (stack.method_31574(class_1802.field_8102)) {
            // While drawing, preview the shot we'd actually get; at rest, preview a
            // full-power shot rather than a zero-length stub.
            float power = player.method_6115() && player.method_6030() == stack
                ? class_1753.method_7722(player.method_6048()) * 3.0F
                : 3.0F;
            return new Launch(power, 0.05, 0.0F);
        }
        if (stack.method_31574(class_1802.field_8399))                     return new Launch(3.15F, 0.05, 0.0F);
        if (stack.method_31574(class_1802.field_8547))                      return new Launch(2.5F,  0.05, 0.0F);
        if (stack.method_31574(class_1802.field_8634)
            || stack.method_31574(class_1802.field_8543)
            || stack.method_31574(class_1802.field_8803))                       return new Launch(1.5F,  0.03, 0.0F);
        if (stack.method_31574(class_1802.field_8436)
            || stack.method_31574(class_1802.field_8150))          return new Launch(0.5F,  0.05, -20.0F);

        return null;
    }

    /**
     * Walks the projectile forward, filling {@code path}. Returns the impact point,
     * or null if it never hit anything within the step budget.
     */
    private static class_243 simulate(class_746 player, class_638 level, Launch launch, List<class_243> path) {
        float xRot = player.method_36455() + launch.pitchOffset();
        float yRot = player.method_36454();

        // Same direction maths as Projectile.shootFromRotation.
        float dx = -class_3532.method_15374(yRot * (float) (Math.PI / 180.0)) * class_3532.method_15362(xRot * (float) (Math.PI / 180.0));
        float dy = -class_3532.method_15374(xRot * (float) (Math.PI / 180.0));
        float dz =  class_3532.method_15362(yRot * (float) (Math.PI / 180.0)) * class_3532.method_15362(xRot * (float) (Math.PI / 180.0));

        class_243 velocity = new class_243(dx, dy, dz).method_1029().method_1021(launch.power());

        // Projectiles inherit the shooter's motion, vertical only when airborne.
        class_243 shooter = player.method_60478();
        velocity = velocity.method_1031(shooter.field_1352, player.method_24828() ? 0.0 : shooter.field_1351, shooter.field_1350);

        class_243 pos = player.method_33571().method_1023(0.0, 0.1, 0.0);
        path.add(pos);

        for (int step = 0; step < MAX_STEPS; step++) {
            class_243 next = pos.method_1019(velocity);

            class_3965 blockHit = level.method_17742(new class_3959(
                pos, next, class_3959.class_3960.field_17558, class_3959.class_242.field_1348, player));
            if (blockHit.method_17783() != class_239.class_240.field_1333) {
                path.add(blockHit.method_17784());
                return blockHit.method_17784();
            }

            class_243 entityHit = clipEntities(player, level, pos, next);
            if (entityHit != null) {
                path.add(entityHit);
                return entityHit;
            }

            pos = next;
            path.add(pos);

            if (pos.field_1351 < level.method_31607() - 8) return null;

            velocity = velocity.method_1021(AIR_DRAG);
            velocity = velocity.method_1023(0.0, launch.gravity(), 0.0);
        }
        return null;
    }

    /** Nearest entity struck by the segment, or null. */
    private static class_243 clipEntities(class_746 player, class_638 level, class_243 from, class_243 to) {
        class_238 sweep = new class_238(from, to).method_1014(1.0);
        class_243 best = null;
        double bestDist = Double.MAX_VALUE;

        for (class_1297 entity : level.method_8333(player, sweep, e -> !e.method_7325() && e.method_5863())) {
            class_238 box = entity.method_5829().method_1014(0.3);
            class_243 hit = box.method_992(from, to).orElse(null);
            if (hit == null) continue;

            double dist = from.method_1025(hit);
            if (dist < bestDist) {
                bestDist = dist;
                best = hit;
            }
        }
        return best;
    }

    private static void drawMarker(class_4588 buf, Matrix4f mat, class_4587.class_4665 pose,
                                   class_243 at, class_243 camPos) {
        double s = 0.25;
        line(buf, mat, pose, at.method_1031(-s, 0, 0), at.method_1031(s, 0, 0), camPos, 1.0F, 0.3F, 0.3F);
        line(buf, mat, pose, at.method_1031(0, -s, 0), at.method_1031(0, s, 0), camPos, 1.0F, 0.3F, 0.3F);
        line(buf, mat, pose, at.method_1031(0, 0, -s), at.method_1031(0, 0, s), camPos, 1.0F, 0.3F, 0.3F);
    }

    private static void line(class_4588 buf, Matrix4f mat, class_4587.class_4665 pose,
                             class_243 from, class_243 to, class_243 camPos, float r, float g, float b) {
        float x1 = (float) (from.field_1352 - camPos.field_1352);
        float y1 = (float) (from.field_1351 - camPos.field_1351);
        float z1 = (float) (from.field_1350 - camPos.field_1350);
        float x2 = (float) (to.field_1352 - camPos.field_1352);
        float y2 = (float) (to.field_1351 - camPos.field_1351);
        float z2 = (float) (to.field_1350 - camPos.field_1350);

        float nx = x2 - x1, ny = y2 - y1, nz = z2 - z1;
        float len = class_3532.method_15355(nx * nx + ny * ny + nz * nz);
        if (len < 1.0E-5F) return;
        nx /= len; ny /= len; nz /= len;

        buf.method_22918(mat, x1, y1, z1).method_22915(r, g, b, 1.0F).method_60831(pose, nx, ny, nz).method_75298(2.0F);
        buf.method_22918(mat, x2, y2, z2).method_22915(r, g, b, 1.0F).method_60831(pose, nx, ny, nz).method_75298(2.0F);
    }
}
