package com.steveplays.superawesomemod;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_746;

/**
 * Scrollable material list showing blocks required for the loaded schematic.
 * Follows the same scrollable list pattern as {@link XrayScreen}.
 */
public class SchematicMaterialListScreen extends class_437 {

    private final class_437 parent;
    private class_342 searchBox;
    private String searchText = "";
    private int scrollOffset = 0;
    private List<MaterialEntry> filteredEntries = new ArrayList<>();
    private List<MaterialEntry> allEntries = new ArrayList<>();

    private static final int BTN_W = 260;
    private static final int ROW_HEIGHT = 20;
    private static final int VISIBLE_ROWS = 8;

    private record MaterialEntry(String name, class_2248 block, int required, int inventory) {}

    public SchematicMaterialListScreen(class_437 parent) {
        super(class_2561.method_43470("Material List"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 100;

        // Build material list from schematic
        buildMaterialList();

        // Search box
        searchBox = new class_342(this.field_22793, cx - BTN_W / 2, topY, BTN_W, 20,
            class_2561.method_43470("Search"));
        searchBox.method_47404(class_2561.method_43470("Search blocks..."));
        searchBox.method_1852(searchText);
        searchBox.method_1863(text -> {
            searchText = text;
            scrollOffset = 0;
            rebuildFilteredList();
            this.method_41843();
        });
        this.method_37063(searchBox);

        rebuildFilteredList();

        // Back button
        int listStartY = topY + 28;
        int backY = listStartY + VISIBLE_ROWS * ROW_HEIGHT + 8;
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, backY, 100, 20).method_46431());
    }

    private void buildMaterialList() {
        allEntries.clear();

        SchematicPlacement placement = SchematicData.getCurrentPlacement();
        if (placement == null) return;

        Map<class_2680, Integer> counts = placement.getSchematic().countBlocks();

        // Group by block (ignoring state variants for the count)
        Map<class_2248, Integer> blockCounts = new java.util.LinkedHashMap<>();
        for (var entry : counts.entrySet()) {
            class_2248 block = entry.getKey().method_26204();
            blockCounts.merge(block, entry.getValue(), Integer::sum);
        }

        // Count player inventory
        Map<class_2248, Integer> inventoryCounts = new java.util.LinkedHashMap<>();
        class_746 player = class_310.method_1551().field_1724;
        if (player != null) {
            for (int i = 0; i < player.method_31548().method_5439(); i++) {
                class_1799 stack = player.method_31548().method_5438(i);
                if (!stack.method_7960()) {
                    class_2248 block = class_2248.method_9503(stack.method_7909());
                    if (block != null) {
                        inventoryCounts.merge(block, stack.method_7947(), Integer::sum);
                    }
                }
            }
        }

        for (var entry : blockCounts.entrySet()) {
            class_2248 block = entry.getKey();
            String name = block.method_9518().getString();
            int required = entry.getValue();
            int inventory = inventoryCounts.getOrDefault(block, 0);
            allEntries.add(new MaterialEntry(name, block, required, inventory));
        }

        // Sort by required count descending
        allEntries.sort(Comparator.comparingInt(MaterialEntry::required).reversed());
    }

    private void rebuildFilteredList() {
        String query = searchText.toLowerCase().trim();
        filteredEntries.clear();
        for (MaterialEntry entry : allEntries) {
            if (query.isEmpty() || entry.name.toLowerCase().contains(query)) {
                filteredEntries.add(entry);
            }
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY,
                                  double scrollX, double scrollY) {
        int maxOffset = Math.max(0, filteredEntries.size() - VISIBLE_ROWS);
        scrollOffset = Math.clamp((long) (scrollOffset - (int) scrollY), 0, maxOffset);
        this.method_41843();
        return true;
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 100;

        graphics.method_27534(this.field_22793, this.field_22785, cx, topY - 16, 0xFFFFFF);

        // Column headers
        int listStartY = topY + 28;
        int leftX = cx - BTN_W / 2;
        graphics.method_25303(this.field_22793, "Block", leftX, listStartY - 10, 0xAAAAAA);
        graphics.method_25303(this.field_22793, "Need", leftX + 160, listStartY - 10, 0xAAAAAA);
        graphics.method_25303(this.field_22793, "Have", leftX + 200, listStartY - 10, 0xAAAAAA);

        // Render material rows
        int end = Math.min(scrollOffset + VISIBLE_ROWS, filteredEntries.size());
        for (int i = scrollOffset; i < end; i++) {
            MaterialEntry entry = filteredEntries.get(i);
            int rowY = listStartY + (i - scrollOffset) * ROW_HEIGHT;

            // Truncate long names
            String displayName = entry.name;
            if (displayName.length() > 22) {
                displayName = displayName.substring(0, 19) + "...";
            }

            // Color: green if have enough, red if not
            int color = entry.inventory >= entry.required ? 0x55FF55 : 0xFF5555;

            graphics.method_25303(this.field_22793, displayName, leftX, rowY + 4, 0xFFFFFF);
            graphics.method_25303(this.field_22793, String.valueOf(entry.required), leftX + 160, rowY + 4, 0xFFFFFF);
            graphics.method_25303(this.field_22793, String.valueOf(entry.inventory), leftX + 200, rowY + 4, color);
        }

        // Scroll indicator
        if (filteredEntries.size() > VISIBLE_ROWS) {
            String scrollText = (scrollOffset + 1) + "-"
                + Math.min(scrollOffset + VISIBLE_ROWS, filteredEntries.size())
                + " of " + filteredEntries.size();
            graphics.method_27534(this.field_22793,
                class_2561.method_43470(scrollText),
                cx, listStartY + VISIBLE_ROWS * ROW_HEIGHT - 6, 0x888888);
        }

        if (filteredEntries.isEmpty()) {
            graphics.method_27534(this.field_22793,
                class_2561.method_43470("No blocks in schematic"),
                cx, listStartY + 40, 0xFF5555);
        }

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
