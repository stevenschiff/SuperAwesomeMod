package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ArmorHudScreen extends class_437 {

    private final class_437 parent;

    public ArmorHudScreen(class_437 parent) {
        super(class_2561.method_43470("Armor HUD"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789 / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                ArmorHudData.setEnabled(!ArmorHudData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        // Size slider (1-5)
        this.method_37063(new ScaleSlider(cx - btnW / 2, cy - 10, btnW, btnH,
                ArmorHudData.getScale()));

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(ArmorHudData.isEnabled() ? "Armor HUD: Enabled" : "Armor HUD: Disabled");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Shows armor with exact durability numbers"),
            cx, cy - 56, 0xAAAAAA);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class ScaleSlider extends class_357 {
        private static final int MIN = 1;
        private static final int MAX = 5;

        ScaleSlider(int x, int y, int w, int h, int initial) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.method_25346();
        }

        private static double normalize(int v) {
            return (double) (v - MIN) / (MAX - MIN);
        }

        private int denormalize() {
            return (int) Math.round(this.field_22753 * (MAX - MIN) + MIN);
        }

        @Override
        protected void method_25346() {
            this.method_25355(class_2561.method_43470("Size: " + denormalize()));
        }

        @Override
        protected void method_25344() {
            ArmorHudData.setScale(denormalize());
        }
    }
}
