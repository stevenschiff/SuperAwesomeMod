package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ArmorHudScreen extends class_437 {

    private final class_437 parent;

    public ArmorHudScreen(class_437 parent) {
        super(class_2561.method_43470("Armor HUD"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789 / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                ArmorHudData.setEnabled(!ArmorHudData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 68, btnW, btnH).method_46431());

        // Icon size slider (0.5 – 5.0 in 0.1 steps)
        this.method_37063(new ScaleSlider(cx - btnW / 2, cy - 43, btnW, btnH,
                ArmorHudData.getScale()));

        // Text size slider (0.5 – 3.0 in 0.1 steps)
        this.method_37063(new TextScaleSlider(cx - btnW / 2, cy - 18, btnW, btnH,
                ArmorHudData.getTextScale()));

        // Durability height offset slider (0 – 30)
        this.method_37063(new HeightSlider(cx - btnW / 2, cy + 7, btnW, btnH,
                ArmorHudData.getDurabilityHeight()));

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 37, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(ArmorHudData.isEnabled() ? "Armor HUD: Enabled" : "Armor HUD: Disabled");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 85, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Shows armor with exact durability numbers"),
            cx, cy - 71, 0xAAAAAA);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    // ---- Size slider: 0.5 to 5.0 in 0.1 increments ----
    private static final class ScaleSlider extends class_357 {
        private static final float MIN = 0.5f;
        private static final float MAX = 5.0f;

        ScaleSlider(int x, int y, int w, int h, float initial) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.method_25346();
        }

        private static double normalize(float v) {
            return (v - MIN) / (MAX - MIN);
        }

        private float denormalize() {
            float raw = (float) (this.field_22753 * (MAX - MIN) + MIN);
            return Math.round(raw * 10.0f) / 10.0f; // snap to 0.1
        }

        @Override
        protected void method_25346() {
            this.method_25355(class_2561.method_43470("Size: " + String.format("%.1f", denormalize())));
        }

        @Override
        protected void method_25344() {
            ArmorHudData.setScale(denormalize());
        }
    }

    // ---- Text size slider: 0.5 to 3.0 in 0.1 increments ----
    private static final class TextScaleSlider extends class_357 {
        private static final float MIN = 0.5f;
        private static final float MAX = 3.0f;

        TextScaleSlider(int x, int y, int w, int h, float initial) {
            super(x, y, w, h, class_2561.method_43473(), normalize(initial));
            this.method_25346();
        }

        private static double normalize(float v) {
            return (v - MIN) / (MAX - MIN);
        }

        private float denormalize() {
            float raw = (float) (this.field_22753 * (MAX - MIN) + MIN);
            return Math.round(raw * 10.0f) / 10.0f;
        }

        @Override
        protected void method_25346() {
            this.method_25355(class_2561.method_43470("Text Size: " + String.format("%.1f", denormalize())));
        }

        @Override
        protected void method_25344() {
            ArmorHudData.setTextScale(denormalize());
        }
    }

    // ---- Durability height slider: 0 to 30 pixels ----
    private static final class HeightSlider extends class_357 {
        private static final int MIN = 0;
        private static final int MAX = 30;

        HeightSlider(int x, int y, int w, int h, int initial) {
            super(x, y, w, h, class_2561.method_43473(), (double) (initial - MIN) / (MAX - MIN));
            this.method_25346();
        }

        private int denormalize() {
            return (int) Math.round(this.field_22753 * (MAX - MIN) + MIN);
        }

        @Override
        protected void method_25346() {
            this.method_25355(class_2561.method_43470("Durability Height: " + denormalize()));
        }

        @Override
        protected void method_25344() {
            ArmorHudData.setDurabilityHeight(denormalize());
        }
    }
}
