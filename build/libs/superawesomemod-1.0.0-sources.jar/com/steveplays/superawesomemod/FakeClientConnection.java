package com.steveplays.superawesomemod;

import com.steveplays.superawesomemod.mixin.ConnectionAccessor;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_2598;
import net.minecraft.class_9127;

/**
 * A no-op {@link class_2535} for fake players.
 * <p>
 * Uses an {@link EmbeddedChannel} so that {@code isConnected()} returns
 * {@code true}, but all outgoing packets are silently discarded.
 */
public class FakeClientConnection extends class_2535 {

    public FakeClientConnection() {
        super(class_2598.field_11941);
        ((ConnectionAccessor) this).setChannel(new EmbeddedChannel());
    }

    @Override
    public void method_10743(class_2596<?> packet) {
        // Silently discard — there is no real client.
    }

    @Override
    public void method_10752(class_2596<?> packet, ChannelFutureListener listener) {
        // Silently discard.
    }

    @Override
    public void method_52906(class_2596<?> packet, ChannelFutureListener listener, boolean flush) {
        // Silently discard.
    }

    @Override
    public void method_10768() {
        // No-op: nothing to clean up.
    }

    @Override
    public void method_10757() {
        // No-op: prevent channel state changes.
    }

    @Override
    public void method_52912(class_2547 listener) {
        // No-op: no handshake for fake players.
    }

    @Override
    public <T extends class_2547> void method_56330(class_9127<T> info, T listener) {
        // No-op: placeNewPlayer calls this to configure the channel pipeline.
    }
}
