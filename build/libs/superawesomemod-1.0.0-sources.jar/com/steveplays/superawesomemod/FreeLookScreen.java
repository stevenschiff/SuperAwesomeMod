package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class FreeLookScreen extends GabeOptionScreen {

    public FreeLookScreen(class_437 parent) {
        super(parent, "Free Look");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", FreeLookData::isEnabled, FreeLookData::setEnabled);
        info("Active in third person only (F5)");
        info("Look around without turning");
    }
}
