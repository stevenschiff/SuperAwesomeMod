package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5498;
import net.minecraft.class_746;
import net.minecraft.class_7833;
import org.joml.Matrix4f;

public final class NametagRenderer {

    private NametagRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(NametagRenderer::onAfterEntities);
    }

    private static void onAfterEntities(WorldRenderContext ctx) {
        if (!NametagData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        class_746 self = mc.field_1724;
        if (self == null) return;

        // Only show in third person (F5)
        if (mc.field_1690.method_31044() == class_5498.field_26664) return;

        class_4184 camera = ctx.gameRenderer().method_19418();
        float partialTick = mc.method_61966().method_60637(true);

        renderNametag(self, ctx.matrices(), camera, partialTick, mc);
    }

    private static void renderNametag(class_746 player, class_4587 poseStack,
                                       class_4184 camera, float partialTick,
                                       class_310 mc) {
        class_327 font = mc.field_1772;
        class_243 camPos = camera.method_71156();

        double x = class_3532.method_16436(partialTick, player.field_6014, player.method_23317());
        double y = class_3532.method_16436(partialTick, player.field_6036, player.method_23318());
        double z = class_3532.method_16436(partialTick, player.field_5969, player.method_23321());

        float entityHeight = player.method_17682();
        class_2561 name = player.method_5476();

        poseStack.method_22903();
        poseStack.method_46416(
            (float)(x - camPos.field_1352),
            (float)(y - camPos.field_1351) + entityHeight + 0.5f,
            (float)(z - camPos.field_1350)
        );

        // Billboard rotation: always face the camera
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));

        float scale = 0.025f;
        poseStack.method_22905(-scale, -scale, scale);

        float textWidth = font.method_27525(name);
        Matrix4f matrix = poseStack.method_23760().method_23761();

        class_4597.class_4598 bufferSource = mc.method_22940().method_23000();

        // Draw with semi-transparent background (matches vanilla nametag style)
        font.method_27522(
            name,
            -textWidth / 2f, 0,
            0xFFFFFFFF,
            false,
            matrix,
            bufferSource,
            class_327.class_6415.field_33994,
            0x40000000,
            15728880
        );
        bufferSource.method_22993();

        poseStack.method_22909();
    }
}
