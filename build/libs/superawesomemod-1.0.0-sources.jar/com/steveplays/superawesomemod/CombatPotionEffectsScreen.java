package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class CombatPotionEffectsScreen extends GabeOptionScreen {

    public CombatPotionEffectsScreen(class_437 parent) {
        super(parent, "Potion Effects");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", CombatPotionEffectsData::isEnabled, CombatPotionEffectsData::setEnabled);
        info("Compact effect list with timers");
    }
}
