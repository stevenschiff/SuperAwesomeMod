package com.steveplays.superawesomemod;

import net.minecraft.class_1799;
import net.minecraft.class_1802;

public final class QuickThrowData {

    private static boolean enabled = false;

    private QuickThrowData() {}

    public static boolean isEnabled()           { return enabled; }
    public static void    setEnabled(boolean e) { enabled = e; }

    /**
     * Items whose throw or eat rate is worth freeing from the client's own cooldown.
     * Deliberately a list rather than "everything": clearing the delay for blocks and
     * tools is Fast Actions' job, and doing it here too would make that toggle a lie.
     */
    public static boolean isQuickItem(class_1799 stack) {
        if (stack.method_7960()) return false;
        return stack.method_31574(class_1802.field_8634)
            || stack.method_31574(class_1802.field_49098)
            || stack.method_31574(class_1802.field_8543)
            || stack.method_31574(class_1802.field_8803)
            || stack.method_31574(class_1802.field_8436)
            || stack.method_31574(class_1802.field_8150)
            || stack.method_31574(class_1802.field_8287)
            || stack.method_31574(class_1802.field_8639)
            || stack.method_31574(class_1802.field_8463)
            || stack.method_31574(class_1802.field_8367);
    }
}
