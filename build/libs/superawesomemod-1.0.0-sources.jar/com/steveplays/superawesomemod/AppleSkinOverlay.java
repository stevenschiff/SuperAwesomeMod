package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1702;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;

/**
 * Renders an AppleSkin-style saturation overlay on the vanilla hunger bar.
 * Each food icon gets a gold-tinted highlight proportional to how much
 * saturation is currently backing that slice of the hunger meter.
 */
@SuppressWarnings("deprecation")
public final class AppleSkinOverlay {

    // Hunger icon geometry (matches vanilla Gui.renderHunger)
    private static final int ICON_W = 9;
    private static final int ICON_GAP = 8;
    private static final int RIGHT_OFFSET = 91;
    private static final int Y_FROM_BOTTOM = 39;

    // Translucent saturation overlay color (gold). Top byte is alpha.
    private static final int OVERLAY_COLOR = 0xC0FFC840;

    private AppleSkinOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(AppleSkinOverlay::onHudRender);
    }

    private static void onHudRender(class_332 g, class_9779 tickCounter) {
        if (!AppleSkinData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;

        class_746 p = mc.field_1724;
        if (p == null) return;
        // Vanilla hides the hunger bar in creative/spectator — match that.
        if (p.method_68878() || p.method_7325()) return;

        class_1702 fd = p.method_7344();
        float sat = fd.method_7589();
        if (sat <= 0f) return;

        int guiW = g.method_51421();
        int guiH = g.method_51443();
        int top = guiH - Y_FROM_BOTTOM;
        int rightEdge = guiW / 2 + RIGHT_OFFSET;

        for (int i = 0; i < 10; i++) {
            float satOverIcon = (float) Math.clamp(sat - i * 2f, 0f, 2f);
            if (satOverIcon <= 0f) break;

            int iconX = rightEdge - i * ICON_GAP - ICON_W;
            // Width 0..9 px, right-aligned within the icon to match vanilla's
            // half-icon convention (the empty side of a half-icon is the left).
            int fillW = Math.round(satOverIcon * (ICON_W / 2f));
            int x0 = iconX + ICON_W - fillW;

            // 7-pixel-tall band, inset by 1px top/bottom so the icon outline
            // still reads through.
            g.method_25294(x0, top + 1, iconX + ICON_W, top + 8, OVERLAY_COLOR);
        }
    }
}
