package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_10799;
import net.minecraft.class_1702;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_746;
import net.minecraft.class_9779;

@SuppressWarnings("deprecation")
public final class AppleSkinOverlay {

    private static final int ICON_W = 9;
    private static final int ICON_H = 9;
    private static final int ICON_GAP = 8;
    private static final int RIGHT_OFFSET = 91;
    private static final int Y_FROM_BOTTOM = 39;

    private static final class_2960 SAT_FULL_SPRITE =
        class_2960.method_60655("superawesomemod", "hud/saturation_full");
    private static final class_2960 SAT_HALF_SPRITE =
        class_2960.method_60655("superawesomemod", "hud/saturation_half");

    private AppleSkinOverlay() {}

    public static void register() {
        HudRenderCallback.EVENT.register(AppleSkinOverlay::onHudRender);
    }

    private static void onHudRender(class_332 g, class_9779 tickCounter) {
        if (!AppleSkinData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1690.field_1842) return;

        class_746 p = mc.field_1724;
        if (p == null) return;
        if (p.method_68878() || p.method_7325()) return;

        class_1702 fd = p.method_7344();
        float sat = fd.method_7589();
        if (sat <= 0f) return;

        int guiW = g.method_51421();
        int guiH = g.method_51443();
        int top = guiH - Y_FROM_BOTTOM;
        int rightEdge = guiW / 2 + RIGHT_OFFSET;

        // Mirror vanilla half/full icon convention: each icon represents 2 saturation
        // points, right-to-left. Renders golden drumstick sprites on top of the
        // vanilla food bar to indicate saturation backing.
        for (int i = 0; i < 10; i++) {
            float satOverIcon = sat - i * 2f;
            if (satOverIcon <= 0f) break;

            int iconX = rightEdge - i * ICON_GAP - ICON_W;
            class_2960 sprite = satOverIcon >= 2f ? SAT_FULL_SPRITE : SAT_HALF_SPRITE;
            g.method_52707(class_10799.field_56883, sprite, iconX, top, ICON_W, ICON_H, 0xFFFFFFFF);
        }
    }
}
