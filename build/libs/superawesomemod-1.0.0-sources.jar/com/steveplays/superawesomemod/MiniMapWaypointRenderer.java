package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_746;
import org.joml.Matrix4f;

public final class MiniMapWaypointRenderer {

    private MiniMapWaypointRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(MiniMapWaypointRenderer::onAfterEntities);
    }

    private static void onAfterEntities(WorldRenderContext ctx) {
        if (!MiniMapData.isEnabled()) return;
        if (MiniMapData.getVisibleWaypoints().isEmpty()) return;

        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null || mc.field_1687 == null) return;

        class_4184 camera = ctx.gameRenderer().method_19418();
        class_243 camPos = camera.method_71156();
        class_4587.class_4665 pose = ctx.matrices().method_23760();
        Matrix4f matrix = pose.method_23761();

        // Maximum distance to render geometry (stay within the frustum far plane).
        // Use 80% of render distance in blocks so we're safely inside the clip plane.
        float maxRenderDist = mc.field_1690.method_42503().method_41753() * 16 * 0.8f;

        // --- Pass 1: Render all line geometry ---
        class_4597.class_4598 bufferSource = mc.method_22940().method_23000();
        class_4588 buf = bufferSource.method_73477(WaypointLineRenderType.LINES_WAYPOINT);

        for (MiniMapWaypoint wp : MiniMapData.getVisibleWaypoints()) {
            float rawX = (float) (wp.x() + 0.5 - camPos.field_1352);
            float rawZ = (float) (wp.z() + 0.5 - camPos.field_1350);

            // Clamp distant waypoints to maxRenderDist while preserving direction
            float dist = (float) Math.sqrt(rawX * rawX + rawZ * rawZ);
            float wx, wz;
            if (dist > maxRenderDist && dist > 0) {
                float scale = maxRenderDist / dist;
                wx = rawX * scale;
                wz = rawZ * scale;
            } else {
                wx = rawX;
                wz = rawZ;
            }

            float yBot = (float) (64 - camPos.field_1351);
            float yTop = (float) (320 - camPos.field_1351);

            float r = wp.r();
            float g = wp.g();
            float b = wp.b();

            // Vertical pillar line
            edge(buf, matrix, pose, wx, yBot, wz, wx, yTop, wz, r, g, b, 1f, 0, 1, 0);

            // Cross at player Y level + 20
            float crossY = (float) (player.method_23318() + 20 - camPos.field_1351);
            float crossSize = 1.0f;
            edge(buf, matrix, pose, wx - crossSize, crossY, wz, wx + crossSize, crossY, wz, r, g, b, 1f, 1, 0, 0);
            edge(buf, matrix, pose, wx, crossY, wz - crossSize, wx, crossY, wz + crossSize, r, g, b, 1f, 0, 0, 1);
        }

        // Flush lines before rendering text
        bufferSource.method_22994(WaypointLineRenderType.LINES_WAYPOINT);

        // --- Pass 2: Render all text labels ---
        for (MiniMapWaypoint wp : MiniMapData.getVisibleWaypoints()) {
            double distXZ = Math.sqrt(
                Math.pow(wp.x() + 0.5 - player.method_23317(), 2) +
                Math.pow(wp.z() + 0.5 - player.method_23321(), 2)
            );
            renderLabel(ctx, camera, camPos, wp, distXZ, mc, maxRenderDist);
        }
    }

    private static void renderLabel(WorldRenderContext ctx, class_4184 camera, class_243 camPos,
                                     MiniMapWaypoint wp, double distance, class_310 mc,
                                     float maxRenderDist) {
        class_4587 poseStack = ctx.matrices();
        poseStack.method_22903();

        // Position the label above the waypoint at player eye level + 20
        double labelY = mc.field_1724.method_23318() + 20;
        float rawX = (float) (wp.x() + 0.5 - camPos.field_1352);
        float rawZ = (float) (wp.z() + 0.5 - camPos.field_1350);

        // Clamp distant labels to maxRenderDist while preserving direction
        float dist = (float) Math.sqrt(rawX * rawX + rawZ * rawZ);
        float wx, wz;
        if (dist > maxRenderDist && dist > 0) {
            float scale = maxRenderDist / dist;
            wx = rawX * scale;
            wz = rawZ * scale;
        } else {
            wx = rawX;
            wz = rawZ;
        }
        float wy = (float) (labelY - camPos.field_1351);

        poseStack.method_22904(wx, wy + 1.5, wz);

        // Billboard rotation: face the camera
        float camYaw = camera.method_19330();
        float camPitch = camera.method_19329();
        poseStack.method_22907(net.minecraft.class_7833.field_40716.rotationDegrees(-camYaw));
        poseStack.method_22907(net.minecraft.class_7833.field_40714.rotationDegrees(camPitch));

        // Scale based on distance (stays readable from far away)
        float scale = (float) Math.max(0.025f, Math.min(0.15f, distance * 0.005));
        poseStack.method_22905(-scale, -scale, scale);

        // Draw name and distance
        String label = wp.name() + " (" + (int) distance + "m)";
        int textColor = 0xFF000000 | wp.color();
        Matrix4f textMatrix = poseStack.method_23760().method_23761();

        class_4597.class_4598 bufferSource = mc.method_22940().method_23000();
        mc.field_1772.method_27522(
            class_2561.method_43470(label),
            -mc.field_1772.method_1727(label) / 2f, 0,
            textColor,
            false,
            textMatrix,
            bufferSource,
            net.minecraft.class_327.class_6415.field_33994,
            0x40000000,
            15728880
        );
        bufferSource.method_22993();

        poseStack.method_22909();
    }

    private static void edge(class_4588 buf, Matrix4f mat, class_4587.class_4665 pose,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float r, float g, float b, float a,
                              float nx, float ny, float nz) {
        buf.method_22918(mat, x1, y1, z1).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz).method_75298(2.0f);
        buf.method_22918(mat, x2, y2, z2).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz).method_75298(2.0f);
    }
}
