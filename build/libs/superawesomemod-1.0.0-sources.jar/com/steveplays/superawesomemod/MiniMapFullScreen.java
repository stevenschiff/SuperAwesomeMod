package com.steveplays.superawesomemod;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_10799;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_638;
import net.minecraft.class_746;

public class MiniMapFullScreen extends class_437 {

    private double panX, panZ; // world coordinates of map center
    private float zoom = 1.0f; // pixels per block
    private boolean showLegend = false;

    private static final float MIN_ZOOM = 0.0001f; // effectively no cap
    private static final float MAX_ZOOM = 8.0f;
    private static final float PAN_SPEED = 10.0f;

    // Mouse drag tracking
    private boolean dragging = false;
    private double lastMouseX, lastMouseY;

    // Texture-based rendering for performance
    private static class_1043 fsTexture;
    private static class_1011 fsImage;
    private static class_2960 fsTextureId;
    private static int fsTexW, fsTexH;
    private static double lastFsPanX = Double.NaN, lastFsPanZ = Double.NaN;
    private static float lastFsZoom = Float.NaN;
    private static boolean fsNeedsUpdate = true;

    public MiniMapFullScreen() {
        super(class_2561.method_43470("Map"));
    }

    @Override
    protected void method_25426() {
        // Initialize pan to player position
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && panX == 0 && panZ == 0) {
            panX = mc.field_1724.method_23317();
            panZ = mc.field_1724.method_23321();
        }

        int btnY = this.field_22790 - 24;
        int btnH = 20;

        // Create Waypoint button
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Create Waypoint"),
            btn -> this.field_22787.method_1507(new MiniMapWaypointScreen(this))
        ).method_46434(4, btnY, 110, btnH).method_46431());

        // Legend toggle
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470(showLegend ? "Legend: On" : "Legend: Off"),
            btn -> {
                showLegend = !showLegend;
                btn.method_25355(class_2561.method_43470(showLegend ? "Legend: On" : "Legend: Off"));
            }
        ).method_46434(118, btnY, 80, btnH).method_46431());

        // Close button
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Close"),
            btn -> this.method_25419()
        ).method_46434(this.field_22789 - 54, btnY, 50, btnH).method_46431());
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        // Handle mouse drag panning (poll left button state directly)
        long window = GLFW.glfwGetCurrentContext();
        boolean leftDown = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (leftDown && dragging) {
            double dx = mouseX - lastMouseX;
            double dy = mouseY - lastMouseY;
            if (dx != 0 || dy != 0) {
                panX -= dx / zoom;
                panZ -= dy / zoom;
            }
        }
        dragging = leftDown;
        lastMouseX = mouseX;
        lastMouseY = mouseY;

        // Texture-based terrain rendering
        int w = this.field_22789;
        int h = this.field_22790;
        ensureFullscreenTexture(w, h);

        boolean viewChanged = Double.isNaN(lastFsPanX)
            || panX != lastFsPanX || panZ != lastFsPanZ || zoom != lastFsZoom;
        if (viewChanged || fsNeedsUpdate) {
            regenerateFullscreenImage(w, h);
            fsTexture.method_4524();
            lastFsPanX = panX;
            lastFsPanZ = panZ;
            lastFsZoom = zoom;
            fsNeedsUpdate = false;
        }

        graphics.method_25290(class_10799.field_56883, fsTextureId, 0, 0, 0.0f, 0.0f, w, h, w, h);

        // Draw world border (15000x15000 box, overworld only)
        if ("overworld".equals(MiniMapData.getCurrentDimension())) {
            int borderHalf = 7500;
            int bx1 = worldToScreenX(-borderHalf);
            int bz1 = worldToScreenZ(-borderHalf);
            int bx2 = worldToScreenX(borderHalf);
            int bz2 = worldToScreenZ(borderHalf);
            int borderColor = 0xFFFF0000;
            // Top edge
            if (bz1 >= 0 && bz1 < this.field_22790) graphics.method_25294(Math.max(0, bx1), bz1, Math.min(this.field_22789, bx2), bz1 + 1, borderColor);
            // Bottom edge
            if (bz2 >= 0 && bz2 < this.field_22790) graphics.method_25294(Math.max(0, bx1), bz2, Math.min(this.field_22789, bx2), bz2 + 1, borderColor);
            // Left edge
            if (bx1 >= 0 && bx1 < this.field_22789) graphics.method_25294(bx1, Math.max(0, bz1), bx1 + 1, Math.min(this.field_22790, bz2), borderColor);
            // Right edge
            if (bx2 >= 0 && bx2 < this.field_22789) graphics.method_25294(bx2, Math.max(0, bz1), bx2 + 1, Math.min(this.field_22790, bz2), borderColor);
        }

        // Draw waypoints
        for (MiniMapWaypoint wp : MiniMapData.getVisibleWaypoints()) {
            int sx = worldToScreenX(wp.x());
            int sy = worldToScreenZ(wp.z());

            if (sx < -10 || sx > this.field_22789 + 10 || sy < -10 || sy > this.field_22790 + 10) continue;

            int c = wp.color() | 0xFF000000;

            // Diamond marker (7x7)
            graphics.method_25294(sx - 3, sy, sx + 4, sy + 1, c);
            graphics.method_25294(sx - 2, sy - 1, sx + 3, sy + 2, c);
            graphics.method_25294(sx - 1, sy - 2, sx + 2, sy + 3, c);
            graphics.method_25294(sx, sy - 3, sx + 1, sy + 4, c);

            // Name label
            graphics.method_51433(this.field_22793, wp.name(), sx + 6, sy - 4, 0xFFFFFF, true);
        }

        // Draw entities based on mode
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 != null && mc.field_1724 != null) {
            class_638 level = mc.field_1687;
            int entityMode = MiniMapData.getEntityMode();

            if (entityMode >= 2) {
                // Draw living entities (orange small dot)
                for (class_1297 entity : level.method_18112()) {
                    if (entity instanceof class_1657) continue;
                    if (!(entity instanceof class_1309)) continue;
                    int sx = worldToScreenX((int) entity.method_23317());
                    int sy = worldToScreenZ((int) entity.method_23321());
                    if (sx < 0 || sx > this.field_22789 || sy < 0 || sy > this.field_22790) continue;
                    graphics.method_25294(sx - 1, sy - 1, sx + 2, sy + 2, 0xFFFF8800);
                }
            }

            if (entityMode >= 1) {
                // Get all players - use server player list in singleplayer for unlimited range
                List<PlayerPos> playerPositions = getAllPlayerPositions(mc);

                for (PlayerPos pp : playerPositions) {
                    int sx = worldToScreenX((int) pp.x);
                    int sy = worldToScreenZ((int) pp.z);
                    if (sx < 0 || sx > this.field_22789 || sy < 0 || sy > this.field_22790) continue;

                    // Cyan filled diamond
                    graphics.method_25294(sx - 2, sy, sx + 3, sy + 1, 0xFF00FFFF);
                    graphics.method_25294(sx - 1, sy - 1, sx + 2, sy + 2, 0xFF00FFFF);
                    graphics.method_25294(sx, sy - 2, sx + 1, sy + 3, 0xFF00FFFF);
                    // White border
                    graphics.method_25294(sx - 3, sy, sx - 2, sy + 1, 0xFFFFFFFF);
                    graphics.method_25294(sx + 3, sy, sx + 4, sy + 1, 0xFFFFFFFF);
                    graphics.method_25294(sx, sy - 3, sx + 1, sy - 2, 0xFFFFFFFF);
                    graphics.method_25294(sx, sy + 3, sx + 1, sy + 4, 0xFFFFFFFF);
                    // Name tag
                    graphics.method_51433(this.field_22793, pp.name, sx + 6, sy - 4, 0xFF00FFFF, true);
                }
            }

            // Draw self marker (green arrow)
            class_746 player = mc.field_1724;
            int selfX = worldToScreenX((int) player.method_23317());
            int selfZ = worldToScreenZ((int) player.method_23321());
            graphics.method_25294(selfX - 2, selfZ - 2, selfX + 3, selfZ + 3, 0xFF00FF00);

            // Direction indicator
            float yawRad = (float) Math.toRadians(player.method_36454());
            int arrowLen = 6;
            int ax = (int) (-Math.sin(yawRad) * arrowLen);
            int ay = (int) (Math.cos(yawRad) * arrowLen);
            drawLine(graphics, selfX, selfZ, selfX + ax, selfZ + ay, 0xFF00FF00);
        }

        // Coordinates at top-center (from mouse position)
        double mouseWorldX = screenToWorldX(mouseX);
        double mouseWorldZ = screenToWorldZ(mouseY);
        String coords = String.format("X: %d, Z: %d", (int) Math.floor(mouseWorldX), (int) Math.floor(mouseWorldZ));
        int coordsW = this.field_22793.method_1727(coords) + 12;
        int boxX = this.field_22789 / 2 - coordsW / 2;
        graphics.method_25294(boxX, 2, boxX + coordsW, 18, 0xFFFFFFFF);
        graphics.method_25300(this.field_22793, coords, this.field_22789 / 2, 6, 0xFF000000);

        // Zoom indicator
        String zoomText = zoom >= 0.1f ? String.format("Zoom: %.1fx", zoom)
                                       : String.format("Zoom: %.3fx", zoom);
        int zoomW = this.field_22793.method_1727(zoomText) + 6;
        graphics.method_25294(2, 2, zoomW + 2, 16, 0xAA000000);
        graphics.method_51433(this.field_22793, zoomText, 4, 5, 0xAAAAAA, false);

        // Legend panel
        if (showLegend) {
            int legendX = this.field_22789 - 108;
            int legendY = 20;
            MiniMapLegend.render(graphics, this.field_22793, legendX, legendY);
        }

        // Render buttons on top
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    // --- Input handling ---

    @Override
    public void method_25393() {
        super.method_25393();
        // WASD panning via key state polling
        long window = GLFW.glfwGetCurrentContext();
        float panAmount = PAN_SPEED / zoom;
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_W) == GLFW.GLFW_PRESS) panZ -= panAmount;
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_S) == GLFW.GLFW_PRESS) panZ += panAmount;
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_A) == GLFW.GLFW_PRESS) panX -= panAmount;
        if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_D) == GLFW.GLFW_PRESS) panX += panAmount;
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (scrollY > 0) {
            zoom = Math.min(MAX_ZOOM, zoom * 1.3f);
        } else if (scrollY < 0) {
            zoom = Math.max(MIN_ZOOM, zoom / 1.3f);
        }
        return true;
    }


    @Override
    public boolean method_25421() {
        return false;
    }

    // --- Texture helpers ---

    private static void ensureFullscreenTexture(int w, int h) {
        if (fsImage != null && fsTexW == w && fsTexH == h) return;

        if (fsTexture != null) {
            fsTexture.close();
        }
        if (fsTextureId != null) {
            class_310.method_1551().method_1531().method_4615(fsTextureId);
            fsTextureId = null;
        }

        // Use size constructor so getPixels() returns the internal image
        fsTexture = new class_1043(() -> "superawesomemod_minimap_fs", w, h, false);
        fsImage = fsTexture.method_4525();
        fsTextureId = class_2960.method_60655("superawesomemod", "minimap_fs");
        class_310.method_1551().method_1531().method_4616(fsTextureId, fsTexture);
        fsTexW = w;
        fsTexH = h;
        fsNeedsUpdate = true;
    }

    private void regenerateFullscreenImage(int w, int h) {
        double halfW = w / 2.0;
        double halfH = h / 2.0;
        double invZoom = 1.0 / zoom;

        for (int px = 0; px < w; px++) {
            double worldX = panX + (px - halfW) * invZoom;
            int bx = (int) Math.floor(worldX);
            int chunkX = bx >> 4;
            int lx = bx & 15;

            int lastChunkZ = Integer.MIN_VALUE;
            int[] colors = null;

            for (int py = 0; py < h; py++) {
                double worldZ = panZ + (py - halfH) * invZoom;
                int bz = (int) Math.floor(worldZ);
                int cz = bz >> 4;

                if (cz != lastChunkZ) {
                    colors = MiniMapChunkCache.get(chunkX, cz);
                    lastChunkZ = cz;
                }

                int color;
                if (colors != null) {
                    int lz = bz & 15;
                    color = colors[lx * 16 + lz];
                } else {
                    color = 0xFF000000;
                }
                fsImage.method_4305(px, py, argbToAbgr(color));
            }
        }
    }

    private static int argbToAbgr(int argb) {
        int a = (argb >> 24) & 0xFF;
        int r = (argb >> 16) & 0xFF;
        int g = (argb >> 8) & 0xFF;
        int b = argb & 0xFF;
        return (a << 24) | (b << 16) | (g << 8) | r;
    }

    // --- Coordinate conversion helpers ---

    private double screenToWorldX(double screenX) {
        return panX + (screenX - this.field_22789 / 2.0) / zoom;
    }

    private double screenToWorldZ(double screenY) {
        return panZ + (screenY - this.field_22790 / 2.0) / zoom;
    }

    private int worldToScreenX(double worldX) {
        return (int) ((worldX - panX) * zoom + this.field_22789 / 2.0);
    }

    private int worldToScreenZ(double worldZ) {
        return (int) ((worldZ - panZ) * zoom + this.field_22790 / 2.0);
    }

    // --- Player position helpers (for showing players from any distance) ---

    private record PlayerPos(String name, double x, double z) {}

    private static List<PlayerPos> getAllPlayerPositions(class_310 mc) {
        List<PlayerPos> positions = new ArrayList<>();

        // In singleplayer, access the integrated server's player list for all player positions
        if (mc.method_1576() != null) {
            for (class_3222 sp : mc.method_1576().method_3760().method_14571()) {
                if (sp.method_5667().equals(mc.field_1724.method_5667())) continue;
                positions.add(new PlayerPos(sp.method_5477().getString(), sp.method_23317(), sp.method_23321()));
            }
        } else {
            // Multiplayer: use loaded players from client level (limited to server tracking range)
            for (class_1657 p : mc.field_1687.method_18456()) {
                if (p == mc.field_1724) continue;
                positions.add(new PlayerPos(p.method_5477().getString(), p.method_23317(), p.method_23321()));
            }
        }

        return positions;
    }

    private static void drawLine(class_332 graphics, int x0, int y0, int x1, int y1, int color) {
        int dx = Math.abs(x1 - x0);
        int dy = Math.abs(y1 - y0);
        int sx = x0 < x1 ? 1 : -1;
        int sy = y0 < y1 ? 1 : -1;
        int err = dx - dy;

        while (true) {
            graphics.method_25294(x0, y0, x0 + 1, y0 + 1, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 > -dy) { err -= dy; x0 += sx; }
            if (e2 < dx) { err += dx; y0 += sy; }
        }
    }
}
