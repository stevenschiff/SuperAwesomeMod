package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class AutoclickerScreen extends class_437 {

    private final class_437 parent;

    public AutoclickerScreen(class_437 parent) {
        super(class_2561.method_43470("Autoclicker"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        // Toggle on/off
        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                AutoclickerData.setEnabled(!AutoclickerData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 50, btnW, btnH).method_46431());

        // Left / Right click selector — two side-by-side buttons
        int half = (btnW - 4) / 2;
        class_4185 leftBtn = class_4185.method_46430(
            buttonLabel(AutoclickerData.Button.LEFT),
            btn -> {
                AutoclickerData.setButton(AutoclickerData.Button.LEFT);
                this.method_41843();
            }
        ).method_46434(cx - btnW / 2, cy - 24, half, btnH).method_46431();
        this.method_37063(leftBtn);

        class_4185 rightBtn = class_4185.method_46430(
            buttonLabel(AutoclickerData.Button.RIGHT),
            btn -> {
                AutoclickerData.setButton(AutoclickerData.Button.RIGHT);
                this.method_41843();
            }
        ).method_46434(cx - btnW / 2 + half + 4, cy - 24, half, btnH).method_46431();
        this.method_37063(rightBtn);

        // CPS slider 1..100
        this.method_37063(new CpsSlider(cx - btnW / 2, cy + 2, btnW, btnH, AutoclickerData.getCps()));

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 36, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(AutoclickerData.isEnabled() ? "Autoclicker: Enabled" : "Autoclicker: Disabled");
    }

    private class_2561 buttonLabel(AutoclickerData.Button b) {
        boolean selected = AutoclickerData.getButton() == b;
        String name = b == AutoclickerData.Button.LEFT ? "Left Click" : "Right Click";
        return class_2561.method_43470((selected ? "[ " : "  ") + name + (selected ? " ]" : "  "));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 78, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Only fires while no menu is open"),
            cx, cy - 66, 0xAAAAAA);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class CpsSlider extends class_357 {
        CpsSlider(int x, int y, int w, int h, int initialCps) {
            super(x, y, w, h, class_2561.method_43473(),
                normalize(initialCps));
            this.method_25346();
        }

        private static double normalize(int cps) {
            return (double) (cps - AutoclickerData.MIN_CPS)
                 / (double) (AutoclickerData.MAX_CPS - AutoclickerData.MIN_CPS);
        }

        @Override
        protected void method_25346() {
            int cps = (int) Math.round(this.field_22753
                * (AutoclickerData.MAX_CPS - AutoclickerData.MIN_CPS)
                + AutoclickerData.MIN_CPS);
            this.method_25355(class_2561.method_43470("CPS: " + cps));
        }

        @Override
        protected void method_25344() {
            int cps = (int) Math.round(this.field_22753
                * (AutoclickerData.MAX_CPS - AutoclickerData.MIN_CPS)
                + AutoclickerData.MIN_CPS);
            AutoclickerData.setCps(cps);
        }
    }
}
