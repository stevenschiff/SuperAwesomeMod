package com.steveplays.superawesomemod;

import com.mojang.brigadier.arguments.FloatArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class ModCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(
                class_2170.method_9247("jumpheight")
                    .requires(source -> true)  // allow all players, cheats not required
                    // /jumpheight  — show current value
                    .executes(ctx -> {
                        if (ctx.getSource().method_9228() instanceof class_3222 player) {
                            float current = PlayerJumpData.getMultiplier(player.method_5667());
                            player.method_64398(class_2561.method_43470(
                                "[SuperAwesomeMod] Jump multiplier: " + current + "x  (range " +
                                PlayerJumpData.MIN + " – " + PlayerJumpData.MAX + ")"
                            ));
                        }
                        return 1;
                    })
                    // /jumpheight <value>  — set to value
                    .then(class_2170.method_9244("multiplier",
                            FloatArgumentType.floatArg(PlayerJumpData.MIN, PlayerJumpData.MAX))
                        .executes(ctx -> {
                            if (ctx.getSource().method_9228() instanceof class_3222 player) {
                                float value = FloatArgumentType.getFloat(ctx, "multiplier");
                                PlayerJumpData.setMultiplier(player.method_5667(), value);
                                player.method_64398(class_2561.method_43470(
                                    "[SuperAwesomeMod] Jump height set to " + value + "x"
                                ));
                            }
                            return 1;
                        })
                    )
            )
        );
    }
}
