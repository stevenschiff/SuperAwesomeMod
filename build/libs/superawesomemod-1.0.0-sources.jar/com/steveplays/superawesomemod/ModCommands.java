package com.steveplays.superawesomemod;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2287;
import net.minecraft.class_2290;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import java.util.Collection;

public class ModCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            // --- /npc ---
            dispatcher.register(
                class_2170.method_9247("npc")
                    .requires(class_2170.method_71774(class_2170.field_31839))

                    // /npc summon <name>
                    .then(class_2170.method_9247("summon")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .executes(ModCommands::npcSummon)))

                    // /npc remove <name>
                    .then(class_2170.method_9247("remove")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests((ctx, builder) -> class_2172.method_9265(
                                FakePlayerManager.getNames(), builder))
                            .executes(ModCommands::npcRemove)))

                    // /npc removeall
                    .then(class_2170.method_9247("removeall")
                        .executes(ModCommands::npcRemoveAll))

                    // /npc list
                    .then(class_2170.method_9247("list")
                        .executes(ModCommands::npcList))

                    // /npc give <name> mainhand|offhand <item>
                    .then(class_2170.method_9247("give")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests((ctx, builder) -> class_2172.method_9265(
                                FakePlayerManager.getNames(), builder))
                            .then(class_2170.method_9247("mainhand")
                                .then(class_2170.method_9244("item", class_2287.method_9776(registryAccess))
                                    .executes(ctx -> npcGive(ctx, class_1268.field_5808))))
                            .then(class_2170.method_9247("offhand")
                                .then(class_2170.method_9244("item", class_2287.method_9776(registryAccess))
                                    .executes(ctx -> npcGive(ctx, class_1268.field_5810))))))

                    // /npc use <name> mainhand|offhand
                    .then(class_2170.method_9247("use")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests((ctx, builder) -> class_2172.method_9265(
                                FakePlayerManager.getNames(), builder))
                            .then(class_2170.method_9247("mainhand")
                                .executes(ctx -> npcUse(ctx, class_1268.field_5808)))
                            .then(class_2170.method_9247("offhand")
                                .executes(ctx -> npcUse(ctx, class_1268.field_5810)))))

                    // /npc shielddelay <name> [ticks]
                    .then(class_2170.method_9247("shielddelay")
                        .then(class_2170.method_9244("name", StringArgumentType.word())
                            .suggests((ctx, builder) -> class_2172.method_9265(
                                FakePlayerManager.getNames(), builder))
                            .executes(ModCommands::npcShieldDelayGet)
                            .then(class_2170.method_9244("ticks", IntegerArgumentType.integer(0))
                                .executes(ModCommands::npcShieldDelaySet))))
            );
        });
    }

    // ------------------------------------------------------------------
    // NPC command handlers
    // ------------------------------------------------------------------

    private static int npcSummon(CommandContext<class_2168> ctx) {
        String name = StringArgumentType.getString(ctx, "name");
        class_2168 source = ctx.getSource();

        if (FakePlayerManager.exists(name)) {
            source.method_9213(class_2561.method_43470("[NPC] '" + name + "' already exists"));
            return 0;
        }

        class_3218 level = source.method_9225();
        class_243 pos = source.method_9222();
        class_241 rot = source.method_9210();

        FakePlayer npc = FakePlayer.spawn(
            source.method_9211(), level, name,
            pos.field_1352, pos.field_1351, pos.field_1350, rot.field_1342, rot.field_1343
        );
        FakePlayerManager.add(name, npc);

        source.method_9226(() -> class_2561.method_43470("[NPC] Spawned '" + name + "'"), true);
        return 1;
    }

    private static int npcRemove(CommandContext<class_2168> ctx) {
        String name = StringArgumentType.getString(ctx, "name");
        if (FakePlayerManager.remove(name)) {
            ctx.getSource().method_9226(
                () -> class_2561.method_43470("[NPC] Removed '" + name + "'"), true);
            return 1;
        }
        ctx.getSource().method_9213(class_2561.method_43470("[NPC] '" + name + "' not found"));
        return 0;
    }

    private static int npcRemoveAll(CommandContext<class_2168> ctx) {
        int count = FakePlayerManager.getAll().size();
        FakePlayerManager.removeAll();
        ctx.getSource().method_9226(
            () -> class_2561.method_43470("[NPC] Removed " + count + " NPC(s)"), true);
        return count;
    }

    private static int npcList(CommandContext<class_2168> ctx) {
        Collection<FakePlayer> npcs = FakePlayerManager.getAll();
        if (npcs.isEmpty()) {
            ctx.getSource().method_9226(
                () -> class_2561.method_43470("[NPC] No active NPCs"), false);
            return 0;
        }
        for (FakePlayer npc : npcs) {
            ctx.getSource().method_9226(() -> class_2561.method_43470(
                String.format("[NPC] %s at (%.1f, %.1f, %.1f)",
                    npc.method_7334().name(),
                    npc.method_23317(), npc.method_23318(), npc.method_23321())), false);
        }
        return npcs.size();
    }

    private static int npcGive(CommandContext<class_2168> ctx, class_1268 hand)
            throws CommandSyntaxException {
        String name = StringArgumentType.getString(ctx, "name");
        FakePlayer npc = FakePlayerManager.get(name);
        if (npc == null) {
            ctx.getSource().method_9213(class_2561.method_43470("[NPC] '" + name + "' not found"));
            return 0;
        }

        class_2290 itemInput = class_2287.method_9777(ctx, "item");
        class_1799 stack = itemInput.method_9781(1, false);
        npc.method_6122(hand, stack);

        String handName = hand == class_1268.field_5808 ? "main hand" : "off hand";
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "[NPC] Gave " + stack.method_7954().getString() + " to " + name +
            " (" + handName + ")"), true);
        return 1;
    }

    private static int npcShieldDelayGet(CommandContext<class_2168> ctx) {
        String name = StringArgumentType.getString(ctx, "name");
        FakePlayer npc = FakePlayerManager.get(name);
        if (npc == null) {
            ctx.getSource().method_9213(class_2561.method_43470("[NPC] '" + name + "' not found"));
            return 0;
        }
        int ticks = npc.getShieldDisableDuration();
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "[NPC] " + name + " shield disable delay: " + ticks + " ticks (" +
            String.format("%.1f", ticks / 20.0) + "s)"), false);
        return 1;
    }

    private static int npcShieldDelaySet(CommandContext<class_2168> ctx) {
        String name = StringArgumentType.getString(ctx, "name");
        FakePlayer npc = FakePlayerManager.get(name);
        if (npc == null) {
            ctx.getSource().method_9213(class_2561.method_43470("[NPC] '" + name + "' not found"));
            return 0;
        }
        int ticks = IntegerArgumentType.getInteger(ctx, "ticks");
        npc.setShieldDisableDuration(ticks);
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "[NPC] " + name + " shield disable delay set to " + ticks + " ticks (" +
            String.format("%.1f", ticks / 20.0) + "s)"), true);
        return 1;
    }

    private static int npcUse(CommandContext<class_2168> ctx, class_1268 hand) {
        String name = StringArgumentType.getString(ctx, "name");
        FakePlayer npc = FakePlayerManager.get(name);
        if (npc == null) {
            ctx.getSource().method_9213(class_2561.method_43470("[NPC] '" + name + "' not found"));
            return 0;
        }

        boolean wasUsing = npc.isContinuousUse(hand);
        npc.setContinuousUse(hand, !wasUsing);

        String handName = hand == class_1268.field_5808 ? "main hand" : "off hand";
        String state = wasUsing ? "stopped" : "started";
        ctx.getSource().method_9226(() -> class_2561.method_43470(
            "[NPC] " + name + " " + state + " using " + handName), true);
        return 1;
    }
}
