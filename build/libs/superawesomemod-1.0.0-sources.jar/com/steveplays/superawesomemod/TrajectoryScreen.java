package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class TrajectoryScreen extends class_437 {

    private final class_437 parent;

    public TrajectoryScreen(class_437 parent) {
        super(class_2561.method_43470("Trajectory Preview"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                TrajectoryData.setEnabled(!TrajectoryData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(TrajectoryData.isEnabled()
            ? "Disable Trajectory Preview" : "Enable Trajectory Preview");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);

        boolean on = TrajectoryData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 58, on ? 0x55FF55 : 0xFF5555);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Bow, crossbow, trident, pearl, snowball, egg, potions"),
            cx, cy - 10, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Bow arc follows your draw  |  red cross marks impact"),
            cx, cy + 46, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Nothing is sent to the server  |  works anywhere"),
            cx, cy + 58, 0xAAAAAA);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
