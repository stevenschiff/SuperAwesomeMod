package com.steveplays.superawesomemod;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_7919;

public class PvpDetectorScreen extends class_437 {

    private final class_437 parent;

    private static final int LEGEND_LABEL_W = 60;

    private record LegendRow(String label, String oneLine, List<class_2561> tooltip) {}

    private static List<class_2561> lines(String... ls) {
        List<class_2561> out = new ArrayList<>(ls.length);
        for (String s : ls) out.add(class_2561.method_43470(s));
        return out;
    }

    private static final LegendRow[] LEGEND = new LegendRow[] {
        new LegendRow(
            "Ping",
            "server latency for that player (ms)",
            lines(
                "Round-trip latency between the server and that player.",
                "Green <100ms, yellow <250ms, red beyond.",
                "High ping dampens the suspicion score, since lag can",
                "make a legitimate hit look like extra reach.")),
        new LegendRow(
            "H:",
            "hits landed in the last 60 seconds",
            lines(
                "Number of attacks this player has landed (on anyone)",
                "inside a rolling 60-second window. Old hits expire",
                "and drop out automatically.")),
        new LegendRow(
            "Sus:",
            "times this player was flagged this session",
            lines(
                "Cumulative count of attacks this player has landed",
                "this session that scored above zero suspicion —",
                "long reach (>3.5 blocks) or through-wall hits.",
                "",
                "Unlike H: and Max:, this counter does NOT decay with",
                "the 60-second window. It's the at-a-glance answer to",
                "\"how many times has this user been suspected of",
                "cheating?\". Color-coded: gray=0, yellow 1-2,",
                "orange 3-5, red 6+.",
                "",
                "Use the Reset Stats button to zero it out.")),
        new LegendRow(
            "Max:",
            "longest reach distance observed (blocks)",
            lines(
                "Greatest hit distance recorded for this player, in blocks,",
                "measured from their eye to the nearest point of the",
                "victim's hitbox.",
                "",
                "Vanilla reach is 3.0. Anything past ~3.5 starts adding",
                "to the suspicion score. 5.5+ is almost certainly cheating.")),
        new LegendRow(
            "Band",
            "suspicion level: NONE / LOW / MED / HIGH",
            lines(
                "Rolling suspicion score over the last 60 seconds:",
                "  gray   NONE — score <5    (clean)",
                "  yellow LOW  — score 5-15  (one-off odd hit)",
                "  orange MED  — score 15-30 (sustained reach)",
                "  red    HIGH — score 30+   (likely cheating)",
                "",
                "Through-wall hits add +5. High ping dampens the score."))
    };

    public PvpDetectorScreen(class_437 parent) {
        super(class_2561.method_43470("PvP Cheat Detector"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789 / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        class_4185 toggle = class_4185.method_46430(
            toggleLabel(),
            btn -> {
                PvpDetectorData.setEnabled(!PvpDetectorData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 30, btnW, btnH).method_46431();
        toggle.method_47400(class_7919.method_47407(class_2561.method_43470(
            "Turn the top-right HUD on or off. When on, every PvP hit you\n"
            + "witness is recorded for 60 seconds and scored for suspicion.")));
        this.method_37063(toggle);

        class_4185 reset = class_4185.method_46430(
            class_2561.method_43470("Reset Stats"),
            btn -> PvpDetectorTracker.clear()
        ).method_46434(cx - btnW / 2, cy, btnW, btnH).method_46431();
        reset.method_47400(class_7919.method_47407(class_2561.method_43470(
            "Drop all currently-tracked players and their hit history.\n"
            + "Useful after a fight or when changing servers.")));
        this.method_37063(reset);

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 30, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(PvpDetectorData.isEnabled()
            ? "PvP Detector: Enabled"
            : "PvP Detector: Disabled");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 80, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Watches other players' attack reach, ping, and line-of-sight."),
            cx, cy - 66, 0xAAAAAA);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Heuristic — long reach + many hits raises the suspicion band."),
            cx, cy - 54, 0xAAAAAA);

        super.method_25394(graphics, mouseX, mouseY, delta);

        // Legend below the buttons. Hover any row to see a longer tooltip.
        int legendW = 280;
        int legendX = cx - legendW / 2;
        int legendY = cy + 60;
        int rowH    = 11;

        graphics.method_51439(this.field_22793,
            class_2561.method_43470("HUD legend (hover for details):"),
            legendX, legendY, 0xCCCCCC, false);

        List<class_2561> hoverTooltip = null;
        int rowY = legendY + 14;
        for (LegendRow row : LEGEND) {
            graphics.method_51439(this.field_22793,
                class_2561.method_43470(row.label()),
                legendX, rowY, 0xFFFFFF, false);
            graphics.method_51439(this.field_22793,
                class_2561.method_43470(row.oneLine()),
                legendX + LEGEND_LABEL_W, rowY, 0xAAAAAA, false);

            if (mouseY >= rowY - 1 && mouseY < rowY + rowH - 1
                && mouseX >= legendX && mouseX < legendX + legendW) {
                hoverTooltip = row.tooltip();
            }
            rowY += rowH;
        }

        if (hoverTooltip != null) {
            graphics.method_51434(this.field_22793, hoverTooltip, mouseX, mouseY);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
