package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class PvpDetectorScreen extends class_437 {

    private final class_437 parent;

    public PvpDetectorScreen(class_437 parent) {
        super(class_2561.method_43470("PvP Cheat Detector"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789 / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                PvpDetectorData.setEnabled(!PvpDetectorData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 30, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Reset Stats"),
            btn -> PvpDetectorTracker.clear()
        ).method_46434(cx - btnW / 2, cy, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 30, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(PvpDetectorData.isEnabled()
            ? "PvP Detector: Enabled"
            : "PvP Detector: Disabled");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Watches other players' attack reach, ping, and line-of-sight."),
            cx, cy - 56, 0xAAAAAA);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Heuristic — long reach + many hits raises the suspicion band."),
            cx, cy - 44, 0xAAAAAA);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
