package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_3222;

public class ModEvents {

    public static void register() {
        // Fires on the server side whenever a living entity takes damage.
        // Return false to cancel the damage; return true to allow it.
        ServerLivingEntityEvents.ALLOW_DAMAGE.register(
            (class_1309 entity, class_1282 source, float amount) -> {

                if (entity instanceof class_3222 player) {
                    player.method_64398(
                        class_2561.method_43470("Ouch! You took " + amount + " damage from " + source.method_48793().method_55840() + "!")
                    );
                }

                return true; // allow the damage to proceed
            }
        );
    }
}
