package com.steveplays.superawesomemod;

import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

public record XrayOreEntry(String name, int color, List<class_2248> blocks) {

    public static final List<XrayOreEntry> ALL = List.of(
        new XrayOreEntry("Coal",           0x4D4D4D, List.of(class_2246.field_10418, class_2246.field_29219)),
        new XrayOreEntry("Iron",           0xD8AF93, List.of(class_2246.field_10212, class_2246.field_29027)),
        new XrayOreEntry("Copper",         0xBF6B3A, List.of(class_2246.field_27120, class_2246.field_29221)),
        new XrayOreEntry("Gold",           0xFCDB00, List.of(class_2246.field_10571, class_2246.field_29026, class_2246.field_23077)),
        new XrayOreEntry("Redstone",       0xFF0000, List.of(class_2246.field_10080, class_2246.field_29030)),
        new XrayOreEntry("Lapis Lazuli",   0x345EC3, List.of(class_2246.field_10090, class_2246.field_29028)),
        new XrayOreEntry("Diamond",        0x5DECF5, List.of(class_2246.field_10442, class_2246.field_29029)),
        new XrayOreEntry("Emerald",        0x41F384, List.of(class_2246.field_10013, class_2246.field_29220)),
        new XrayOreEntry("Nether Quartz",  0xE3D5C9, List.of(class_2246.field_10213)),
        new XrayOreEntry("Ancient Debris", 0x96614E, List.of(class_2246.field_22109))
    );

    public float r() { return ((color >> 16) & 0xFF) / 255f; }
    public float g() { return ((color >> 8)  & 0xFF) / 255f; }
    public float b() { return  (color        & 0xFF) / 255f; }
}
