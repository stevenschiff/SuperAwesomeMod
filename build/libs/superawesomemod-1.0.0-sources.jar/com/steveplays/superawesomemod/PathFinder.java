package com.steveplays.superawesomemod;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3610;

/**
 * A bounded A* over standable positions, used to walk to a block worth mining.
 *
 * <p>Deliberately walk-only: it never counts a solid block as passable, so it will not
 * dig a tunnel to reach anything. That was the explicit choice — the path has to reach a
 * standing spot near the target, and only the target itself gets broken. Exposed ore in a
 * cave is reachable; ore sealed inside stone is not, and that reads as "no route".
 *
 * <p>Bounded in two directions: a search box around the player, and a ceiling on nodes
 * expanded. Minecraft worlds are large enough that an unbounded search would happily
 * stall the client for seconds looking for a route that does not exist.
 */
public final class PathFinder {

    /** How far from the player, in blocks, the search box extends. */
    private static final int RANGE = 48;
    /** Ceiling on expanded nodes, so a hopeless search fails fast instead of hanging. */
    private static final int MAX_NODES = 6000;
    /** Longest drop the path will take voluntarily. */
    private static final int MAX_DROP = 3;

    private PathFinder() {}

    /** Can a player stand with their feet at this position? */
    public static boolean standable(class_1922 level, class_2338 pos) {
        return passable(level, pos)
            && passable(level, pos.method_10084())
            && solidTop(level, pos.method_10074());
    }

    private static boolean passable(class_1922 level, class_2338 pos) {
        class_2680 state = level.method_8320(pos);
        if (!state.method_26220(level, pos).method_1110()) return false;
        // Fluids are walkable in principle but swimming and lava are both ways to end a
        // run badly, so the path avoids them entirely.
        class_3610 fluid = state.method_26227();
        return fluid.method_15769();
    }

    private static boolean solidTop(class_1922 level, class_2338 pos) {
        return !level.method_8320(pos).method_26220(level, pos).method_1110();
    }

    /**
     * Finds a walking route from {@code start} to any standable position within
     * {@code reach} of {@code target}. Returns an empty list when there is no route.
     */
    public static List<class_2338> findPath(class_1922 level, class_2338 start, class_2338 target,
                                          double reach) {
        if (!standable(level, start)) {
            // Feet may be a block off after a jump or on a slab; try directly below.
            class_2338 below = start.method_10074();
            if (standable(level, below)) start = below;
            else return List.of();
        }

        double reachSqr = reach * reach;
        Map<class_2338, class_2338> cameFrom = new HashMap<>();
        Map<class_2338, Integer> gScore = new HashMap<>();
        Set<class_2338> closed = new HashSet<>();
        PriorityQueue<class_2338> open =
            new PriorityQueue<>(Comparator.comparingDouble(p -> gScore.getOrDefault(p, Integer.MAX_VALUE)
                                                              + heuristic(p, target)));

        gScore.put(start, 0);
        open.add(start);
        int expanded = 0;

        while (!open.isEmpty() && expanded++ < MAX_NODES) {
            class_2338 current = open.poll();
            if (!closed.add(current)) continue;

            if (current.method_10262(target) <= reachSqr) {
                return reconstruct(cameFrom, current);
            }

            for (class_2338 next : neighbours(level, current)) {
                if (closed.contains(next)) continue;
                if (Math.abs(next.method_10263() - start.method_10263()) > RANGE
                    || Math.abs(next.method_10260() - start.method_10260()) > RANGE
                    || Math.abs(next.method_10264() - start.method_10264()) > RANGE) continue;

                int tentative = gScore.getOrDefault(current, Integer.MAX_VALUE) + stepCost(current, next);
                if (tentative < gScore.getOrDefault(next, Integer.MAX_VALUE)) {
                    cameFrom.put(next, current);
                    gScore.put(next, tentative);
                    open.add(next);
                }
            }
        }
        return List.of();
    }

    private static int stepCost(class_2338 from, class_2338 to) {
        // Climbing is slower than walking, and falling is slightly discouraged so the
        // path prefers a gentle route to a cliff when both exist.
        if (to.method_10264() > from.method_10264()) return 14;
        if (to.method_10264() < from.method_10264()) return 12;
        return 10;
    }

    private static double heuristic(class_2338 a, class_2338 b) {
        return Math.sqrt(a.method_10262(b)) * 10.0;
    }

    private static List<class_2338> neighbours(class_1922 level, class_2338 pos) {
        List<class_2338> out = new ArrayList<>(8);
        class_2338[] flat = {
            pos.method_10095(), pos.method_10072(), pos.method_10078(), pos.method_10067()
        };

        for (class_2338 side : flat) {
            if (standable(level, side)) {
                out.add(side);
                continue;
            }
            // Step up one block.
            class_2338 up = side.method_10084();
            if (standable(level, up) && passable(level, pos.method_10086(2))) {
                out.add(up);
                continue;
            }
            // Drop down, but only a survivable distance.
            for (int d = 1; d <= MAX_DROP; d++) {
                class_2338 down = side.method_10087(d);
                if (standable(level, down)) {
                    out.add(down);
                    break;
                }
                if (!passable(level, down)) break;
            }
        }
        return out;
    }

    private static List<class_2338> reconstruct(Map<class_2338, class_2338> cameFrom, class_2338 end) {
        ArrayDeque<class_2338> path = new ArrayDeque<>();
        class_2338 cur = end;
        while (cur != null) {
            path.addFirst(cur);
            cur = cameFrom.get(cur);
        }
        List<class_2338> list = new ArrayList<>(path);
        if (!list.isEmpty()) list.remove(0); // we are already standing on the first node
        return Collections.unmodifiableList(list);
    }
}
