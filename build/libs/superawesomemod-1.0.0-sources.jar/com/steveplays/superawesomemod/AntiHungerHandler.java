package com.steveplays.superawesomemod;

import net.minecraft.class_1657;
import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Owns what the server believes about our sprinting.
 *
 * <p>The server charges hunger for distance only when it thinks we are sprinting —
 * {@code ServerPlayer.checkMovementStatistics} bills {@code 0.1F} per metre sprinting
 * and nothing at all walking — and the sprint flag is something the client reports
 * rather than something the server observes. Reporting a walk while actually
 * sprinting therefore makes overland travel free, on any server.
 *
 * <p>Rather than filtering vanilla's sprint packets and hoping its bookkeeping stays
 * consistent, this takes the state over completely: the mixin drops every sprint
 * packet the client generates, and this class sends exactly the ones it wants. Vanilla
 * only transmits on a change, so a dropped packet would otherwise leave the server
 * permanently out of step with no way to correct it — including when we deliberately
 * want to tell the truth again.
 */
public final class AntiHungerHandler {

    /** Open while we send our own sprint packet, so the mixin lets that one through. */
    private static boolean sendingOwn = false;

    /** What we believe the server currently thinks. */
    private static boolean serverThinksSprinting = false;
    private static boolean tracking = false;

    private AntiHungerHandler() {}

    public static boolean isSendingOwn() {
        return sendingOwn;
    }

    public static void tick(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null || client.method_1562() == null) {
            tracking = false;
            return;
        }

        boolean spoof = AntiHungerData.isWalkReportActive() && !nearAnyPlayer(client, player);

        if (!AntiHungerData.isWalkReportActive()) {
            // Feature just went off: hand the truth back once, then stop managing it.
            if (tracking) {
                send(client, player, player.method_5624());
                tracking = false;
            }
            return;
        }

        boolean desired = spoof ? false : player.method_5624();

        if (!tracking) {
            tracking = true;
            serverThinksSprinting = !desired; // force one send to establish the state
        }

        if (desired != serverThinksSprinting) {
            send(client, player, desired);
        }
    }

    private static void send(class_310 client, class_746 player, boolean sprinting) {
        if (client.method_1562() == null) return;

        sendingOwn = true;
        try {
            client.method_1562().method_52787(new class_2848(player,
                sprinting
                    ? class_2848.class_2849.field_12981
                    : class_2848.class_2849.field_12985));
        } finally {
            sendingOwn = false;
        }
        serverThinksSprinting = sprinting;
    }

    private static boolean nearAnyPlayer(class_310 client, class_746 self) {
        if (!AntiHungerData.isPauseNearPlayers() || client.field_1687 == null) return false;

        double radius = AntiHungerData.getPauseRadius();
        double radiusSqr = radius * radius;
        for (class_1657 other : client.field_1687.method_18456()) {
            if (other == self || other.method_7325()) continue;
            if (other.method_5858(self) <= radiusSqr) return true;
        }
        return false;
    }
}
