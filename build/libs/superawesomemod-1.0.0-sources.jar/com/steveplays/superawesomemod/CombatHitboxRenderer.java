package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_5134;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.joml.Matrix4f;

public final class CombatHitboxRenderer {

    private CombatHitboxRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(CombatHitboxRenderer::onAfterEntities);
    }

    private static void onAfterEntities(WorldRenderContext ctx) {
        if (!CombatHitboxData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        class_746 self = mc.field_1724;
        class_638 level = mc.field_1687;
        if (self == null || level == null) return;

        class_4597 consumers = ctx.consumers();
        if (consumers == null) return;

        class_4184 camera = ctx.gameRenderer().method_19418();
        class_243 camPos = camera.method_71156();
        class_243 eye = self.method_33571();
        double reach = getAttackReach(self);
        double reachSqr = reach * reach;
        float partialTick = mc.method_61966().method_60637(true);

        class_4587.class_4665 pose = ctx.matrices().method_23760();
        Matrix4f matrix = pose.method_23761();

        boolean seeThroughWalls = CombatHitboxData.isSeeThroughWalls();

        // Two passes — never cache both buffers at once. The world's MultiBufferSource routes
        // unknown render types through one shared BufferBuilder and ends the previous batch when
        // a new shared type is requested, which would invalidate a held VertexConsumer.
        // Normal pass: draws solid (depth-tested) outlines for entities the player can see directly.
        // XRay pass: draws outlines through walls. Without "see through walls" it's limited to
        // invisible entities; with it on, every attackable entity is drawn through walls too.
        drawPass(consumers.method_73477(class_12249.method_76015()),         level, self, eye, reachSqr, matrix, pose, camPos, partialTick, false, false);
        drawPass(consumers.method_73477(XrayLineRenderType.LINES_XRAY), level, self, eye, reachSqr, matrix, pose, camPos, partialTick, true,  seeThroughWalls);
    }

    private static void drawPass(class_4588 buffer, class_638 level, class_746 self,
                                 class_243 eye, double reachSqr, Matrix4f matrix, class_4587.class_4665 pose,
                                 class_243 camPos, float partialTick, boolean invisOnly, boolean includeAll) {
        boolean playersOnly = CombatHitboxData.isPlayersOnly();
        boolean showInvisible = CombatHitboxData.isShowInvisible();
        for (class_1297 entity : level.method_18112()) {
            if (entity == self) continue;
            if (!entity.method_5732()) continue;
            if (playersOnly && !(entity instanceof class_1657)) continue;
            if (!showInvisible && entity.method_5767()) continue;
            if (!includeAll && entity.method_5767() != invisOnly) continue;

            double dx = class_3532.method_16436(partialTick, entity.field_6014, entity.method_23317()) - entity.method_23317();
            double dy = class_3532.method_16436(partialTick, entity.field_6036, entity.method_23318()) - entity.method_23318();
            double dz = class_3532.method_16436(partialTick, entity.field_5969, entity.method_23321()) - entity.method_23321();
            class_238 box = entity.method_5829().method_989(dx, dy, dz);
            boolean inReach = nearestPointDistanceSqr(eye, box) <= reachSqr;

            float r = 1.0f;
            float g = inReach ? 0.0f : 1.0f;
            float b = inReach ? 0.0f : 1.0f;

            renderBoxLines(buffer, matrix, pose, box, camPos, r, g, b, 1.0f);
        }
    }

    private static double getAttackReach(class_1657 player) {
        class_1324 attr = player.method_5996(class_5134.field_47759);
        if (attr != null) return attr.method_6194();
        return class_1657.field_47820;
    }

    private static double nearestPointDistanceSqr(class_243 point, class_238 box) {
        double dx = Math.max(0.0, Math.max(box.field_1323 - point.field_1352, point.field_1352 - box.field_1320));
        double dy = Math.max(0.0, Math.max(box.field_1322 - point.field_1351, point.field_1351 - box.field_1325));
        double dz = Math.max(0.0, Math.max(box.field_1321 - point.field_1350, point.field_1350 - box.field_1324));
        return dx * dx + dy * dy + dz * dz;
    }

    private static void renderBoxLines(class_4588 buf, Matrix4f mat, class_4587.class_4665 pose,
                                       class_238 box, class_243 cam,
                                       float r, float g, float b, float a) {
        float x0 = (float) (box.field_1323 - cam.field_1352);
        float y0 = (float) (box.field_1322 - cam.field_1351);
        float z0 = (float) (box.field_1321 - cam.field_1350);
        float x1 = (float) (box.field_1320 - cam.field_1352);
        float y1 = (float) (box.field_1325 - cam.field_1351);
        float z1 = (float) (box.field_1324 - cam.field_1350);

        // Bottom rectangle
        edge(buf, mat, pose, x0, y0, z0, x1, y0, z0, r, g, b, a, 1, 0, 0);
        edge(buf, mat, pose, x1, y0, z0, x1, y0, z1, r, g, b, a, 0, 0, 1);
        edge(buf, mat, pose, x1, y0, z1, x0, y0, z1, r, g, b, a, -1, 0, 0);
        edge(buf, mat, pose, x0, y0, z1, x0, y0, z0, r, g, b, a, 0, 0, -1);
        // Top rectangle
        edge(buf, mat, pose, x0, y1, z0, x1, y1, z0, r, g, b, a, 1, 0, 0);
        edge(buf, mat, pose, x1, y1, z0, x1, y1, z1, r, g, b, a, 0, 0, 1);
        edge(buf, mat, pose, x1, y1, z1, x0, y1, z1, r, g, b, a, -1, 0, 0);
        edge(buf, mat, pose, x0, y1, z1, x0, y1, z0, r, g, b, a, 0, 0, -1);
        // Vertical edges
        edge(buf, mat, pose, x0, y0, z0, x0, y1, z0, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x1, y0, z0, x1, y1, z0, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x1, y0, z1, x1, y1, z1, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x0, y0, z1, x0, y1, z1, r, g, b, a, 0, 1, 0);
    }

    private static void edge(class_4588 buf, Matrix4f mat, class_4587.class_4665 pose,
                             float x1, float y1, float z1,
                             float x2, float y2, float z2,
                             float r, float g, float b, float a,
                             float nx, float ny, float nz) {
        buf.method_22918(mat, x1, y1, z1).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz).method_75298(2.0f);
        buf.method_22918(mat, x2, y2, z2).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz).method_75298(2.0f);
    }
}
