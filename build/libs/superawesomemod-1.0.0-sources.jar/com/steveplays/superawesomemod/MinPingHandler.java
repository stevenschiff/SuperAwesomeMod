package com.steveplays.superawesomemod;

import io.netty.channel.ChannelDuplexHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import java.util.concurrent.TimeUnit;
import net.minecraft.class_310;
import net.minecraft.class_640;
import net.minecraft.class_746;

/**
 * Netty handler that delays outbound packets when the player's current ping
 * is below the configured minimum, effectively setting a ping floor.
 */
public class MinPingHandler extends ChannelDuplexHandler {

    @Override
    public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise)
            throws Exception {
        if (!MinPingData.isEnabled() || MinPingData.getMinPingMs() <= 0) {
            super.write(ctx, msg, promise);
            return;
        }

        int currentPing = getCurrentPing();
        int minPing = MinPingData.getMinPingMs();

        if (currentPing >= minPing || currentPing <= 0) {
            // Already above floor or unknown — pass through immediately.
            super.write(ctx, msg, promise);
            return;
        }

        // Delay the packet by half the difference (outbound only = half RTT).
        long delayMs = (long) (minPing - currentPing) / 2;
        if (delayMs <= 0) {
            super.write(ctx, msg, promise);
            return;
        }

        ctx.executor().schedule(() -> {
            ctx.write(msg, promise);
            ctx.flush();
        }, delayMs, TimeUnit.MILLISECONDS);
    }

    private static int getCurrentPing() {
        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        if (player == null || player.field_3944 == null) return -1;
        class_640 info = player.field_3944.method_2871(player.method_5667());
        return info != null ? info.method_2959() : -1;
    }
}
