package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class AutoFishScreen extends GabeOptionScreen {

    public AutoFishScreen(class_437 parent) {
        super(parent, "Auto Fishing");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", AutoFishData::isEnabled, AutoFishData::setEnabled);
        slider("Keep durability", AutoFishData.MIN_RESERVE, AutoFishData.MAX_RESERVE,
               AutoFishData::getDurabilityReserve, AutoFishData::setDurabilityReserve,
               String::valueOf);
        info("Status: " + AutoFishData.getStatus());
        info("Hold a rod and look at water");
        info("Stops before the rod breaks");
    }
}
