package com.steveplays.superawesomemod;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import net.minecraft.class_746;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class XrayRenderer {

    private XrayRenderer() {}

    private static final int SCAN_RADIUS = 64;
    private static final int SCAN_INTERVAL = 10;

    private static final List<OreHit> cachedOres = new ArrayList<>();
    private static int tickCounter = 0;
    private static class_2338 lastScanCenter = class_2338.field_10980;

    private record OreHit(class_2338 pos, XrayOreEntry entry) {}

    private static Map<class_2248, XrayOreEntry> blockToEntry;

    private static Map<class_2248, XrayOreEntry> getBlockLookup() {
        if (blockToEntry == null) {
            blockToEntry = new HashMap<>();
            for (XrayOreEntry entry : XrayOreEntry.ALL) {
                for (class_2248 block : entry.blocks()) {
                    blockToEntry.put(block, entry);
                }
            }
        }
        return blockToEntry;
    }

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(XrayRenderer::onAfterEntities);
    }

    private static void onAfterEntities(WorldRenderContext ctx) {
        if (!XrayData.isEnabled()) return;

        class_310 mc = class_310.method_1551();
        class_746 player = mc.field_1724;
        class_638 level = mc.field_1687;
        if (player == null || level == null) return;

        class_4597 consumers = ctx.consumers();
        if (consumers == null) return;

        // Tick-based re-scanning
        tickCounter++;
        class_2338 playerPos = player.method_24515();
        boolean needsRescan = tickCounter >= SCAN_INTERVAL
            || lastScanCenter.method_19455(playerPos) > 16;

        if (needsRescan) {
            tickCounter = 0;
            lastScanCenter = playerPos;
            rescan(level, playerPos);
        }

        if (cachedOres.isEmpty()) return;

        class_4184 camera = ctx.gameRenderer().method_19418();
        class_243 camPos = camera.method_71156();
        class_4587.class_4665 pose = ctx.matrices().method_23760();
        Matrix4f matrix = pose.method_23761();

        class_4588 buf = consumers.method_73477(XrayLineRenderType.LINES_XRAY);

        for (OreHit hit : cachedOres) {
            XrayOreEntry ore = hit.entry();
            if (!XrayData.isOreEnabled(ore.name())) continue;

            class_2338 pos = hit.pos();
            float x0 = (float) (pos.method_10263()     - camPos.field_1352);
            float y0 = (float) (pos.method_10264()     - camPos.field_1351);
            float z0 = (float) (pos.method_10260()     - camPos.field_1350);
            float x1 = (float) (pos.method_10263() + 1 - camPos.field_1352);
            float y1 = (float) (pos.method_10264() + 1 - camPos.field_1351);
            float z1 = (float) (pos.method_10260() + 1 - camPos.field_1350);

            renderBoxLines(buf, matrix, pose, x0, y0, z0, x1, y1, z1,
                ore.r(), ore.g(), ore.b(), 1.0f);
        }
    }

    private static void rescan(class_638 level, class_2338 center) {
        cachedOres.clear();
        Map<class_2248, XrayOreEntry> lookup = getBlockLookup();
        int cx = center.method_10263();
        int cy = center.method_10264();
        int cz = center.method_10260();

        int minY = Math.max(level.method_31607(), cy - SCAN_RADIUS);
        int maxY = Math.min(level.method_31600(), cy + SCAN_RADIUS);

        class_2338.class_2339 mutable = new class_2338.class_2339();

        for (int x = cx - SCAN_RADIUS; x <= cx + SCAN_RADIUS; x++) {
            for (int z = cz - SCAN_RADIUS; z <= cz + SCAN_RADIUS; z++) {
                for (int y = minY; y <= maxY; y++) {
                    mutable.method_10103(x, y, z);
                    class_2680 state = level.method_8320(mutable);
                    XrayOreEntry entry = lookup.get(state.method_26204());
                    if (entry != null) {
                        cachedOres.add(new OreHit(mutable.method_10062(), entry));
                    }
                }
            }
        }
    }

    private static void renderBoxLines(class_4588 buf, Matrix4f mat,
                                        class_4587.class_4665 pose,
                                        float x0, float y0, float z0,
                                        float x1, float y1, float z1,
                                        float r, float g, float b, float a) {
        // Bottom rectangle
        edge(buf, mat, pose, x0, y0, z0, x1, y0, z0, r, g, b, a, 1, 0, 0);
        edge(buf, mat, pose, x1, y0, z0, x1, y0, z1, r, g, b, a, 0, 0, 1);
        edge(buf, mat, pose, x1, y0, z1, x0, y0, z1, r, g, b, a, -1, 0, 0);
        edge(buf, mat, pose, x0, y0, z1, x0, y0, z0, r, g, b, a, 0, 0, -1);
        // Top rectangle
        edge(buf, mat, pose, x0, y1, z0, x1, y1, z0, r, g, b, a, 1, 0, 0);
        edge(buf, mat, pose, x1, y1, z0, x1, y1, z1, r, g, b, a, 0, 0, 1);
        edge(buf, mat, pose, x1, y1, z1, x0, y1, z1, r, g, b, a, -1, 0, 0);
        edge(buf, mat, pose, x0, y1, z1, x0, y1, z0, r, g, b, a, 0, 0, -1);
        // Vertical edges
        edge(buf, mat, pose, x0, y0, z0, x0, y1, z0, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x1, y0, z0, x1, y1, z0, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x1, y0, z1, x1, y1, z1, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x0, y0, z1, x0, y1, z1, r, g, b, a, 0, 1, 0);
    }

    private static void edge(class_4588 buf, Matrix4f mat, class_4587.class_4665 pose,
                              float x1, float y1, float z1,
                              float x2, float y2, float z2,
                              float r, float g, float b, float a,
                              float nx, float ny, float nz) {
        buf.method_22918(mat, x1, y1, z1).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz).method_75298(2.0f);
        buf.method_22918(mat, x2, y2, z2).method_22915(r, g, b, a).method_60831(pose, nx, ny, nz).method_75298(2.0f);
    }
}
