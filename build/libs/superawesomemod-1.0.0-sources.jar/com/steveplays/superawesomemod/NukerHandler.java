package com.steveplays.superawesomemod;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;

/**
 * Breaks everything around you, as fast as the server will actually allow.
 *
 * <p>The rule comes straight from {@code ServerPlayerGameMode.handleBlockBreakAction},
 * which vanilla labels itself:
 *
 * <pre>
 * f = blockState.getDestroyProgress(player, level, pos);
 * if (!blockState.isAir() &amp;&amp; f >= 1.0F) {
 *     this.destroyAndAck(pos, j, "insta mine");
 * } else {
 *     this.isDestroyingBlock = true;   // one block, timed by the server
 * </pre>
 *
 * <p>So a block your tool clears within a single tick dies the moment the packet
 * lands, and there is no cap on how many of those we send per tick — that is the real
 * nuker, and it covers grass, crops, torches, leaves with shears, and everything in
 * creative. Anything harder falls into the second branch, where the server tracks
 * exactly one position, so stone and ore can only ever be worked one at a time no
 * matter the radius. Running the same {@code getDestroyProgress} test here sorts the
 * two groups before anything is sent, rather than spraying packets the server drops.
 */
public final class NukerHandler {

    private NukerHandler() {}

    public static void tick(class_310 client) {
        class_746 player = client.field_1724;
        class_638 level = client.field_1687;
        if (!NukerData.isEnabled() || player == null || level == null) return;
        if (client.field_1755 != null || client.field_1761 == null) return;

        int radius = NukerData.getRadius();
        double reach = player.method_55754();
        double reachSqr = reach * reach;
        class_2338 origin = player.method_24515();

        class_2338 slowest = null;
        float slowestProgress = 0.0f;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -radius; dy <= radius; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    class_2338 pos = origin.method_10069(dx, dy, dz);

                    class_2680 state = level.method_8320(pos);
                    if (state.method_26215()) continue;

                    // The server range-checks every break, so anything past our reach
                    // would just be rejected.
                    if (pos.method_19770(player.method_33571()) > reachSqr) continue;

                    float progress = state.method_26165(player, level, pos);
                    if (progress <= 0.0f) continue; // unbreakable by hand or by rule

                    if (progress >= 1.0f) {
                        // The server will insta-mine this one; fire and forget.
                        client.field_1761.method_2910(pos, class_2350.field_11036);
                        client.field_1761.method_2925();
                    } else if (!NukerData.isInstantOnly() && progress > slowestProgress) {
                        // Remember the quickest of the slow blocks — only one can be
                        // in progress server-side, so picking the fastest finishes most.
                        slowestProgress = progress;
                        slowest = pos;
                    }
                }
            }
        }

        if (slowest != null) {
            // Continue rather than restart, so progress accumulates instead of resetting.
            client.field_1761.method_2902(slowest, class_2350.field_11036);
        }
    }
}
