package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class NametagScreen extends GabeOptionScreen {

    public NametagScreen(class_437 parent) {
        super(parent, "Nametag");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", NametagData::isEnabled, NametagData::setEnabled);
        info("Cleaner nametag rendering");
    }
}
