package com.steveplays.superawesomemod;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_10799;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Map;

/**
 * Renders LOD terrain as solid colored quads in world space.
 * Each height sample becomes a flat filled square at the correct elevation.
 */
public final class LODTerrainRenderer {

    private static final RenderPipeline PIPELINE = RenderPipeline.builder(class_10799.field_56860)
            .withLocation(class_2960.method_60655("superawesomemod", "lod_terrain"))
            .withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
            .withCull(false)
            .build();

    private static final class_1921 LOD_TERRAIN = class_1921.method_75940(
            "lod_terrain",
            class_12247.method_75927(PIPELINE).method_75938()
    );

    private LODTerrainRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(LODTerrainRenderer::onWorldRender);
    }

    private static void onWorldRender(WorldRenderContext ctx) {
        if (!RenderDistanceData.isEnabled()) return;
        if (LODChunkData.size() == 0) return;

        class_4597 consumers = ctx.consumers();
        if (consumers == null) return;

        class_4184 camera = ctx.gameRenderer().method_19418();
        class_243 camPos = camera.method_71156();

        Matrix4f matrix = ctx.matrices().method_23760().method_23761();

        int skipDist = LODChunkData.getSkipRadius();
        int pcx = LODChunkData.getPlayerChunkX();
        int pcz = LODChunkData.getPlayerChunkZ();
        int lodRadius = LODChunkData.getLodRadius();

        class_4588 buf = consumers.method_73477(LOD_TERRAIN);

        // Collect entries to avoid concurrent modification.
        var entries = new ArrayList<Map.Entry<Long, int[]>>();
        LODChunkData.forEach((key, heights) -> entries.add(Map.entry(key, heights)));

        for (var entry : entries) {
            int cx = LODChunkData.unpackX(entry.getKey());
            int cz = LODChunkData.unpackZ(entry.getKey());

            int dx = cx - pcx;
            int dz = cz - pcz;
            // Skip chunks within real chunk range.
            if (Math.abs(dx) <= skipDist && Math.abs(dz) <= skipDist) continue;

            int[] heights = entry.getValue();
            int baseBlockX = cx * 16;
            int baseBlockZ = cz * 16;

            float chunkDist = (float) Math.sqrt(dx * dx + dz * dz);
            float alpha = Math.max(0.3f, 1.0f - (chunkDist / lodRadius) * 0.7f);

            for (int sx = 0; sx < LODChunkData.SAMPLES_PER_AXIS; sx++) {
                for (int sz = 0; sz < LODChunkData.SAMPLES_PER_AXIS; sz++) {
                    int height = heights[sx * LODChunkData.SAMPLES_PER_AXIS + sz];

                    float x0 = (float) (baseBlockX + sx * LODChunkData.SAMPLE_SPACING - camPos.field_1352);
                    float z0 = (float) (baseBlockZ + sz * LODChunkData.SAMPLE_SPACING - camPos.field_1350);
                    float y  = (float) (height - camPos.field_1351);
                    float x1 = x0 + LODChunkData.SAMPLE_SPACING;
                    float z1 = z0 + LODChunkData.SAMPLE_SPACING;

                    int color = getColorForHeight(height);
                    float r = ((color >> 16) & 0xFF) / 255f;
                    float g = ((color >> 8) & 0xFF) / 255f;
                    float b = (color & 0xFF) / 255f;

                    // Filled quad (counter-clockwise winding for upward face).
                    buf.method_22918(matrix, x0, y, z0).method_22915(r, g, b, alpha);
                    buf.method_22918(matrix, x0, y, z1).method_22915(r, g, b, alpha);
                    buf.method_22918(matrix, x1, y, z1).method_22915(r, g, b, alpha);
                    buf.method_22918(matrix, x1, y, z0).method_22915(r, g, b, alpha);
                }
            }
        }
    }

    private static int getColorForHeight(int height) {
        if (height < 63)  return 0x4488AA; // water blue
        if (height < 80)  return 0x55AA55; // plains green
        if (height < 120) return 0x667744; // hills
        if (height < 180) return 0x888888; // mountains gray
        return 0xDDDDDD; // peaks white
    }
}
