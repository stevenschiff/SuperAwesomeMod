package com.steveplays.superawesomemod;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_2960;

/**
 * Depth-ignoring lines, used only to draw your own map waypoints so a marker stays
 * visible behind terrain.
 *
 * <p>This was previously shared with the X-ray renderer and the hitbox see-through
 * pass. Both are gone, and it is kept deliberately narrow: waypoints are markers you
 * placed yourself, so drawing them through a wall reveals nothing the game was hiding
 * from you.
 */
public final class WaypointLineRenderType {

    private static final RenderPipeline PIPELINE = RenderPipeline.builder(class_10799.field_56859)
        .withLocation(class_2960.method_60655("superawesomemod", "lines_waypoint"))
        .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
        .build();

    public static final class_1921 LINES_WAYPOINT = class_1921.method_75940(
        "lines_waypoint",
        class_12247.method_75927(PIPELINE)
            .method_75930(class_12245.field_63976)
            .method_75931(class_12246.field_63983)
            .method_75938()
    );

    private WaypointLineRenderType() {}

    public static void touch() {}
}
