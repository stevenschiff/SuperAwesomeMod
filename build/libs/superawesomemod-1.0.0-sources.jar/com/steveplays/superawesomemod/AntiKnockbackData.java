package com.steveplays.superawesomemod;

import net.minecraft.class_243;

public final class AntiKnockbackData {

    /** Percent of incoming knockback actually applied. 0 = immune, 100 = vanilla. */
    public static final int MIN_PERCENT = 0;
    public static final int MAX_PERCENT = 100;

    private static boolean enabled = false;
    private static int percent = 0;

    private AntiKnockbackData() {}

    public static boolean isEnabled()           { return enabled; }
    public static void    setEnabled(boolean e) { enabled = e; }

    public static int  getPercent()      { return percent; }
    public static void setPercent(int p) { percent = Math.clamp(p, MIN_PERCENT, MAX_PERCENT); }

    /** Scales a knockback vector down to the configured share. */
    public static class_243 scale(class_243 knockback) {
        if (!enabled) return knockback;
        if (percent == 0) return class_243.field_1353;
        return knockback.method_1021(percent / 100.0);
    }
}
