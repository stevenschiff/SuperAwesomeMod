package com.steveplays.superawesomemod;

import net.minecraft.class_1802;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Keeps the server's fall distance alive so a mace smash lands from standing.
 *
 * <p>The mace's bonus is computed entirely from the <em>server's</em>
 * {@code fallDistance} for us, inside {@code MaceItem.getAttackDamageBonus}. The
 * server builds that number from the positions and the onGround flag we report, and
 * it throws it away in exactly two places: when a movement packet says onGround, and
 * when the reported Y rises above the last accepted one.
 *
 * <p>So this holds onGround false while a mace is in hand. Fall distance earned from
 * any real drop then survives walking around instead of being wiped on landing, and
 * every mace hit smashes with it. What it cannot do is invent height — resting on a
 * block and reporting a descent is rejected by the server's own collision check, so
 * the number still has to be earned by falling once.
 *
 * <p>Turning it off has to be careful: the server has been holding a live fall
 * distance the whole time, and the first honest onGround would cash it in as fall
 * damage. So disabling first sends the upward nudge that makes the server drop it,
 * the same trick {@code FlightFallResetMixin} uses.
 */
public final class MaceDamageHandler {

    /** Our running estimate of the server's fall distance. Display only. */
    private static double estimate = 0.0;
    private static double lastY = Double.NaN;
    private static boolean wasActive = false;

    private MaceDamageHandler() {}

    /** True while we are suppressing onGround for the mace. */
    public static boolean isActive(class_310 client) {
        if (!MaceDamageData.isEnabled()) return false;
        class_746 player = client.field_1724;
        return player != null && player.method_6047().method_31574(class_1802.field_49814);
    }

    public static double getEstimate() {
        return estimate;
    }

    public static void tick(class_310 client) {
        class_746 player = client.field_1724;
        if (player == null) {
            estimate = 0.0;
            lastY = Double.NaN;
            wasActive = false;
            return;
        }

        boolean active = isActive(client);

        if (wasActive && !active) {
            // Hand the held fall distance back before an honest onGround arrives and
            // charges us for all of it at once.
            clearServerFallDistance(client, player);
            estimate = 0.0;
        }
        wasActive = active;

        double y = player.method_23318();
        double previous = lastY;
        lastY = y;

        if (!active) {
            estimate = 0.0;
            return;
        }

        if (Double.isNaN(previous)) return;

        if (y < previous) {
            // Descending: the server accumulates the same delta we report.
            estimate += previous - y;
        } else if (y > previous) {
            // Rising past the last accepted Y is one of the two things that makes the
            // server drop the distance, so our estimate has to drop with it.
            estimate = 0.0;
        }
    }

    private static void clearServerFallDistance(class_310 client, class_746 player) {
        if (client.method_1562() == null) return;
        client.method_1562().method_52787(new class_2828.class_2829(
            player.method_23317(), player.method_23318() + 0.001, player.method_23321(),
            false, player.field_5976));
    }
}
