package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class MiniMapWaypointScreen extends class_437 {

    private final class_437 parent;
    private class_342 nameField;
    private class_342 xField;
    private class_342 zField;

    private int colorR = 255;
    private int colorG = 0;
    private int colorB = 0;

    private static final int BTN_W = 200;
    private static final int BTN_H = 20;

    public MiniMapWaypointScreen(class_437 parent) {
        super(class_2561.method_43470("Create Waypoint"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 80;

        // Name field
        nameField = new class_342(this.field_22793, cx - BTN_W / 2, topY, BTN_W, BTN_H,
            class_2561.method_43470("Name"));
        nameField.method_47404(class_2561.method_43470("Waypoint name..."));
        nameField.method_1880(32);
        this.method_37063(nameField);

        // X coordinate field
        xField = new class_342(this.field_22793, cx - BTN_W / 2, topY + 28, 95, BTN_H,
            class_2561.method_43470("X"));
        xField.method_47404(class_2561.method_43470("X coordinate"));
        // Pre-fill with player position
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            xField.method_1852(String.valueOf((int) mc.field_1724.method_23317()));
            zField = new class_342(this.field_22793, cx - BTN_W / 2 + 105, topY + 28, 95, BTN_H,
                class_2561.method_43470("Z"));
            zField.method_47404(class_2561.method_43470("Z coordinate"));
            zField.method_1852(String.valueOf((int) mc.field_1724.method_23321()));
        } else {
            zField = new class_342(this.field_22793, cx - BTN_W / 2 + 105, topY + 28, 95, BTN_H,
                class_2561.method_43470("Z"));
            zField.method_47404(class_2561.method_43470("Z coordinate"));
            zField.method_1852("0");
            xField.method_1852("0");
        }
        this.method_37063(xField);
        this.method_37063(zField);

        // Color buttons (R/G/B increment/decrement)
        int colorY = topY + 60;

        // Red
        this.method_37063(class_4185.method_46430(class_2561.method_43470("R-"),
            btn -> { colorR = Math.max(0, colorR - 32); })
            .method_46434(cx - BTN_W / 2, colorY, 40, BTN_H).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("R+"),
            btn -> { colorR = Math.min(255, colorR + 32); })
            .method_46434(cx - BTN_W / 2 + 44, colorY, 40, BTN_H).method_46431());

        // Green
        this.method_37063(class_4185.method_46430(class_2561.method_43470("G-"),
            btn -> { colorG = Math.max(0, colorG - 32); })
            .method_46434(cx - BTN_W / 2 + 90, colorY, 40, BTN_H).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("G+"),
            btn -> { colorG = Math.min(255, colorG + 32); })
            .method_46434(cx - BTN_W / 2 + 134, colorY, 40, BTN_H).method_46431());

        // Blue
        this.method_37063(class_4185.method_46430(class_2561.method_43470("B-"),
            btn -> { colorB = Math.max(0, colorB - 32); })
            .method_46434(cx - BTN_W / 2 + 180, colorY, 40, BTN_H).method_46431());
        this.method_37063(class_4185.method_46430(class_2561.method_43470("B+"),
            btn -> { colorB = Math.min(255, colorB + 32); })
            .method_46434(cx - BTN_W / 2 + 224, colorY, 40, BTN_H).method_46431());

        // Save button
        int btnY = topY + 110;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Save"),
            btn -> {
                saveWaypoint();
                this.field_22787.method_1507(this.parent);
            }).method_46434(cx - BTN_W / 2, btnY, 95, BTN_H).method_46431());

        // Cancel button
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Cancel"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - BTN_W / 2 + 105, btnY, 95, BTN_H).method_46431());
    }

    private void saveWaypoint() {
        String name = nameField.method_1882().trim();
        if (name.isEmpty()) name = "Waypoint";

        int x, z;
        try {
            x = Integer.parseInt(xField.method_1882().trim());
        } catch (NumberFormatException e) {
            x = 0;
        }
        try {
            z = Integer.parseInt(zField.method_1882().trim());
        } catch (NumberFormatException e) {
            z = 0;
        }

        int color = (colorR << 16) | (colorG << 8) | colorB;
        String dimension = MiniMapData.getCurrentDimension();
        MiniMapData.addWaypoint(new MiniMapWaypoint(name, x, z, color, true, dimension));
        MiniMapPersistence.markDirty();
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {

        int cx = this.field_22789 / 2;
        int topY = this.field_22790 / 2 - 80;

        // Title
        graphics.method_27534(this.field_22793, this.field_22785, cx, topY - 16, 0xFFFFFF);

        // Labels
        graphics.method_51433(this.field_22793, "Name:", cx - BTN_W / 2 - 35, topY + 6, 0xAAAAAA, false);
        graphics.method_51433(this.field_22793, "Pos:", cx - BTN_W / 2 - 30, topY + 34, 0xAAAAAA, false);

        // Color preview
        int colorY = topY + 60;
        int previewColor = 0xFF000000 | (colorR << 16) | (colorG << 8) | colorB;
        graphics.method_51433(this.field_22793, "Color:", cx - BTN_W / 2 - 35, colorY + 6, 0xAAAAAA, false);

        // Color swatch below the buttons
        int swatchY = colorY + 24;
        graphics.method_25294(cx - 20, swatchY, cx + 20, swatchY + 16, previewColor);
        // Border
        graphics.method_25294(cx - 20, swatchY, cx + 20, swatchY + 1, 0xFF888888);
        graphics.method_25294(cx - 20, swatchY + 15, cx + 20, swatchY + 16, 0xFF888888);
        graphics.method_25294(cx - 20, swatchY, cx - 19, swatchY + 16, 0xFF888888);
        graphics.method_25294(cx + 19, swatchY, cx + 20, swatchY + 16, 0xFF888888);

        // RGB values text
        String rgbText = String.format("R:%d G:%d B:%d", colorR, colorG, colorB);
        graphics.method_25300(this.field_22793, rgbText, cx, swatchY + 20, 0xCCCCCC);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
