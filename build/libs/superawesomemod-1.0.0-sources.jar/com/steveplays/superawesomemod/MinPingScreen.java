package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class MinPingScreen extends class_437 {

    private final class_437 parent;

    public MinPingScreen(class_437 parent) {
        super(class_2561.method_43470("Min Ping"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        // Toggle on/off
        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                MinPingData.setEnabled(!MinPingData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        // Min ping slider 0..500
        this.method_37063(new PingSlider(
            cx - btnW / 2, cy - 14, btnW, btnH,
            MinPingData.getMinPingMs()
        ));

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(MinPingData.isEnabled()
            ? "Min Ping: Enabled"
            : "Min Ping: Disabled");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 60, 0xFFFFFF);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    private static final class PingSlider extends class_357 {
        PingSlider(int x, int y, int w, int h, int initialPing) {
            super(x, y, w, h, class_2561.method_43473(),
                normalize(initialPing));
            this.method_25346();
        }

        private static double normalize(int ping) {
            return (double) (ping - MinPingData.MIN_PING)
                 / (double) (MinPingData.MAX_PING - MinPingData.MIN_PING);
        }

        @Override
        protected void method_25346() {
            int ms = (int) Math.round(this.field_22753
                * (MinPingData.MAX_PING - MinPingData.MIN_PING)
                + MinPingData.MIN_PING);
            this.method_25355(class_2561.method_43470("Min Ping: " + ms + " ms"));
        }

        @Override
        protected void method_25344() {
            int ms = (int) Math.round(this.field_22753
                * (MinPingData.MAX_PING - MinPingData.MIN_PING)
                + MinPingData.MIN_PING);
            MinPingData.setMinPingMs(ms);
        }
    }
}
