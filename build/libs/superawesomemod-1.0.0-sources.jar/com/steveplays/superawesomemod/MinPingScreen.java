package com.steveplays.superawesomemod;

import net.minecraft.class_437;

public class MinPingScreen extends GabeOptionScreen {

    public MinPingScreen(class_437 parent) {
        super(parent, "Min Ping");
    }

    @Override
    protected void buildOptions() {
        toggle("Enabled", MinPingData::isEnabled, MinPingData::setEnabled);
        slider("Minimum", MinPingData.MIN_PING, MinPingData.MAX_PING,
               MinPingData::getMinPingMs, MinPingData::setMinPingMs, v -> v + " ms");
        info("Holds packets to a floor latency");
    }
}
