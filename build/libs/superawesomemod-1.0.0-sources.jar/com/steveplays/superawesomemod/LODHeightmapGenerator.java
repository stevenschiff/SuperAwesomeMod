package com.steveplays.superawesomemod;

import java.util.Optional;
import net.minecraft.class_2378;
import net.minecraft.class_2794;
import net.minecraft.class_2902;
import net.minecraft.class_3754;
import net.minecraft.class_5284;
import net.minecraft.class_5317;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_5455;
import net.minecraft.class_5539;
import net.minecraft.class_6880;
import net.minecraft.class_7138;
import net.minecraft.class_7145;
import net.minecraft.class_7924;

/**
 * Runs on a background daemon thread. Creates a ChunkGenerator from a seed
 * and samples terrain heights for LOD rendering.
 */
public final class LODHeightmapGenerator {

    private static volatile Thread workerThread;
    private static volatile boolean running;

    private static final class_5539 OVERWORLD_HEIGHT = new class_5539() {
        @Override public int method_31605() { return 384; }
        @Override public int method_31607() { return -64; }
    };

    private LODHeightmapGenerator() {}

    public static void start(long seed, class_5455 registries) {
        stop();
        running = true;
        workerThread = new Thread(() -> runLoop(seed, registries), "LOD-HeightGen");
        workerThread.setDaemon(true);
        workerThread.start();
    }

    public static void stop() {
        running = false;
        if (workerThread != null) {
            workerThread.interrupt();
            workerThread = null;
        }
        LODChunkData.clear();
    }

    public static boolean isRunning() {
        return running && workerThread != null && workerThread.isAlive();
    }

    private static void runLoop(long seed, class_5455 registries) {
        class_2794 generator;
        class_7138 randomState;
        try {
            // Look up the overworld generator from the NORMAL world preset.
            class_2378<class_7145> presetRegistry = registries.method_30530(class_7924.field_41250);
            Optional<class_6880.class_6883<class_7145>> presetOpt = presetRegistry.method_46746(class_5317.field_25050);
            if (presetOpt.isEmpty()) {
                SuperAwesomeMod.LOGGER.error("[LOD] Could not find NORMAL world preset");
                return;
            }
            class_7145 preset = presetOpt.get().comp_349();

            // Get the overworld LevelStem from the preset.
            Optional<class_5363> stemOpt = preset.method_41584();
            if (stemOpt.isEmpty()) {
                SuperAwesomeMod.LOGGER.error("[LOD] Could not find overworld stem in preset");
                return;
            }
            generator = stemOpt.get().comp_1013();

            // Create RandomState from the noise settings used by the generator.
            if (generator instanceof class_3754 noiseGen) {
                class_6880<class_5284> settingsHolder = noiseGen.method_41541();
                class_5321<class_5284> settingsKey = settingsHolder.method_40230()
                    .orElse(class_5284.field_26355);
                randomState = class_7138.method_41557(registries, settingsKey, seed);
            } else {
                SuperAwesomeMod.LOGGER.error("[LOD] Generator is not noise-based, cannot sample heights");
                return;
            }
        } catch (Exception e) {
            SuperAwesomeMod.LOGGER.error("[LOD] Failed to initialize generator", e);
            return;
        }

        SuperAwesomeMod.LOGGER.info("[LOD] Height generator started (seed: {})", seed);

        int lastPcx = Integer.MIN_VALUE;
        int lastPcz = Integer.MIN_VALUE;

        while (running && !Thread.currentThread().isInterrupted()) {
            try {
                int pcx = LODChunkData.getPlayerChunkX();
                int pcz = LODChunkData.getPlayerChunkZ();
                int radius = LODChunkData.getLodRadius();
                int skipRadius = Math.min(radius, 12); // don't generate where server sends real chunks

                // Only regenerate ring if player moved significantly.
                boolean moved = Math.abs(pcx - lastPcx) > 2 || Math.abs(pcz - lastPcz) > 2;
                if (moved) {
                    lastPcx = pcx;
                    lastPcz = pcz;
                    LODChunkData.evict(pcx, pcz, radius);
                }

                int generated = 0;
                for (int r = skipRadius; r <= radius && generated < 32 && running; r++) {
                    for (int dx = -r; dx <= r && generated < 32 && running; dx++) {
                        for (int dz = -r; dz <= r && generated < 32 && running; dz++) {
                            // Only process the ring edge at distance r.
                            if (Math.abs(dx) != r && Math.abs(dz) != r) continue;

                            int cx = pcx + dx;
                            int cz = pcz + dz;
                            if (LODChunkData.get(cx, cz) != null) continue;

                            int[] heights = sampleChunk(generator, randomState, cx, cz);
                            LODChunkData.put(cx, cz, heights);
                            generated++;
                        }
                    }
                }

                Thread.sleep(50);
            } catch (InterruptedException e) {
                break;
            } catch (Exception e) {
                SuperAwesomeMod.LOGGER.error("[LOD] Error in generation loop", e);
                try { Thread.sleep(1000); } catch (InterruptedException ie) { break; }
            }
        }

        SuperAwesomeMod.LOGGER.info("[LOD] Height generator stopped");
    }

    private static int[] sampleChunk(class_2794 generator, class_7138 randomState, int chunkX, int chunkZ) {
        int[] heights = new int[LODChunkData.SAMPLES_PER_CHUNK];
        int baseX = chunkX * 16;
        int baseZ = chunkZ * 16;

        for (int sx = 0; sx < LODChunkData.SAMPLES_PER_AXIS; sx++) {
            for (int sz = 0; sz < LODChunkData.SAMPLES_PER_AXIS; sz++) {
                int blockX = baseX + sx * LODChunkData.SAMPLE_SPACING + 2; // center of 4x4 area
                int blockZ = baseZ + sz * LODChunkData.SAMPLE_SPACING + 2;
                int height = generator.method_16397(
                    blockX, blockZ,
                    class_2902.class_2903.field_13202,
                    OVERWORLD_HEIGHT,
                    randomState
                );
                heights[sx * LODChunkData.SAMPLES_PER_AXIS + sz] = height;
            }
        }
        return heights;
    }
}
