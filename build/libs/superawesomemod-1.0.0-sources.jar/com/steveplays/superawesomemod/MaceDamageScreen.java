package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class MaceDamageScreen extends class_437 {

    private final class_437 parent;

    public MaceDamageScreen(class_437 parent) {
        super(class_2561.method_43470("Mace Damage"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                MaceDamageData.setEnabled(!MaceDamageData.isEnabled());
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(MaceDamageData.isEnabled()
            ? "Disable Mace Damage" : "Enable Mace Damage");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 82, 0xFFFFFF);

        boolean on = MaceDamageData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 70, on ? 0x55FF55 : 0xFF5555);

        // The charge readout is the useful part: it says what your next hit does.
        double held = MaceDamageHandler.getEstimate();
        double bonus = MaceDamageData.bonusDamageAt(held);
        boolean armed = held > MaceDamageData.SMASH_THRESHOLD;

        graphics.method_27534(this.field_22793,
            class_2561.method_43470(String.format("Held fall distance: %.1f blocks", held)),
            cx, cy - 10, armed ? 0x55FF55 : 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470(armed
                ? String.format("Next smash: +%.0f bonus damage", bonus)
                : "Not armed - fall 2+ blocks once to charge it"),
            cx, cy + 2, armed ? 0x55FF55 : 0xFFAA00);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Keeps the fall distance instead of losing it on landing"),
            cx, cy + 46, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Only while holding a mace  |  works on any server"),
            cx, cy + 58, 0xAAAAAA);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("No multiplier exists - the server sets damage from the fall"),
            cx, cy + 70, 0xFFAA00);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
