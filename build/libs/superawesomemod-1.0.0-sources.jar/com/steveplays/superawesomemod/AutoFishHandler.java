package com.steveplays.superawesomemod;

import com.steveplays.superawesomemod.mixin.FishingHookAccessor;
import com.steveplays.superawesomemod.mixin.MinecraftUseInvoker;
import net.minecraft.class_1536;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

/**
 * Casts, reels on a bite, and casts again.
 *
 * <p>The bite is read from the hook's synced flag rather than guessed from the splash
 * sound or the bobber dipping, so the reel lands on the actual catch window instead of a
 * lookalike — rain and nearby splashes both fool the audio approach.
 *
 * <p>Every wait is randomised. A reel that happens exactly N ticks after every bite, for
 * hours, is a clearer signal than any single action.
 */
public final class AutoFishHandler {

    private enum State { IDLE, CAST_WAIT, FISHING, REEL_WAIT }

    private static State state = State.IDLE;
    private static int delay = 0;

    private AutoFishHandler() {}

    public static void tick(class_310 client) {
        class_746 player = client.field_1724;
        if (!AutoFishData.isEnabled() || player == null || client.field_1755 != null) {
            state = State.IDLE;
            return;
        }

        class_1799 held = player.method_6047();
        if (!held.method_31574(class_1802.field_8378)) {
            AutoFishData.setStatus("No rod in hand");
            state = State.IDLE;
            return;
        }

        // Don't fish a good rod to death; Mending and Luck of the Sea are worth more
        // than the fish.
        int left = held.method_7936() - held.method_7919();
        if (held.method_7963() && left <= AutoFishData.getDurabilityReserve()) {
            AutoFishData.setStatus("Stopped: rod nearly broken");
            state = State.IDLE;
            return;
        }

        if (delay > 0) {
            delay--;
            return;
        }

        class_1536 hook = player.field_7513;

        switch (state) {
            case IDLE, CAST_WAIT -> {
                if (hook == null) {
                    AutoFishData.setStatus("Casting");
                    use(client);
                    delay = RotationHelper.jitterTicks(8, 8);
                    state = State.CAST_WAIT;
                } else {
                    AutoFishData.setStatus("Fishing");
                    state = State.FISHING;
                }
            }
            case FISHING -> {
                if (hook == null) {
                    state = State.IDLE;
                    return;
                }
                if (isBiting(hook)) {
                    AutoFishData.setStatus("Reeling in");
                    // A person does not react instantly to the splash.
                    delay = RotationHelper.jitterTicks(3, 5);
                    state = State.REEL_WAIT;
                }
            }
            case REEL_WAIT -> {
                use(client);
                AutoFishData.setStatus("Recasting");
                delay = RotationHelper.jitterTicks(12, 12);
                state = State.IDLE;
            }
        }
    }

    private static boolean isBiting(class_1536 hook) {
        return hook.method_5841().method_12789(FishingHookAccessor.superawesomemod$dataBiting());
    }

    private static void use(class_310 client) {
        ((MinecraftUseInvoker) (Object) client).superawesomemod$startUseItem();
    }
}
