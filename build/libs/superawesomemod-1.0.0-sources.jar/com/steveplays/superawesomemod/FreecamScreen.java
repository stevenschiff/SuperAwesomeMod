package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_746;

public class FreecamScreen extends class_437 {

    private final class_437 parent;

    private static final String[] SPEED_LABELS = { "Slow", "Normal", "Fast", "Very Fast" };
    private static final float[]  SPEED_VALUES = {
        FreecamData.SLOW, FreecamData.NORMAL, FreecamData.FAST, FreecamData.VERY_FAST
    };

    public FreecamScreen(class_437 parent) {
        super(class_2561.method_43470("Freecam"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789  / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;

        // Toggle on/off
        this.method_37063(class_4185.method_46430(
            toggleLabel(),
            btn -> {
                boolean newState = !FreecamData.isEnabled();
                if (newState) {
                    class_746 p = class_310.method_1551().field_1724;
                    if (p != null) {
                        FreecamData.setPos(p.method_23317(), p.method_23320(), p.method_23321());
                        FreecamData.setRot(p.method_36454(), p.method_36455());
                    }
                }
                FreecamData.setEnabled(newState);
                btn.method_25355(toggleLabel());
            }
        ).method_46434(cx - btnW / 2, cy - 40, btnW, btnH).method_46431());

        // Speed preset buttons
        int totalW = SPEED_LABELS.length * 48 + (SPEED_LABELS.length - 1) * 4;
        int startX = cx - totalW / 2;
        for (int i = 0; i < SPEED_LABELS.length; i++) {
            final float speed = SPEED_VALUES[i];
            this.method_37063(class_4185.method_46430(
                class_2561.method_43470(SPEED_LABELS[i]),
                btn -> FreecamData.setSpeed(speed)
            ).method_46434(startX + i * 52, cy - 10, 48, btnH).method_46431());
        }

        // Back
        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, cy + 20, 100, btnH).method_46431());
    }

    private class_2561 toggleLabel() {
        return class_2561.method_43470(FreecamData.isEnabled() ? "Disable Freecam" : "Enable Freecam");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);

        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;

        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 70, 0xFFFFFF);

        boolean on = FreecamData.isEnabled();
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Status: " + (on ? "Enabled" : "Disabled")),
            cx, cy - 58, on ? 0x55FF55 : 0xFF5555);

        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Speed:"), cx, cy - 24, 0xAAAAAA);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("WASD/Space/Shift to fly  |  Body stays in place"),
            cx, cy + 46, 0xAAAAAA);

        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
