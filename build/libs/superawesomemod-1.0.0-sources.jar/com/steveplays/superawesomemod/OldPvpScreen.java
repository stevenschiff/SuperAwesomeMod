package com.steveplays.superawesomemod;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class OldPvpScreen extends class_437 {

    private final class_437 parent;

    public OldPvpScreen(class_437 parent) {
        super(class_2561.method_43470("1.7 PvP Animations"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int cx   = this.field_22789 / 2;
        int cy   = this.field_22790 / 2;
        int btnW = 200;
        int btnH = 20;
        int gap  = 24;

        int row0 = cy - 30;

        this.method_37063(class_4185.method_46430(
            blockingLabel(),
            btn -> {
                OldPvpData.setBlockingEnabled(!OldPvpData.isBlockingEnabled());
                btn.method_25355(blockingLabel());
            }
        ).method_46434(cx - btnW / 2, row0, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            swingLabel(),
            btn -> {
                OldPvpData.setSwingWhileUsingEnabled(!OldPvpData.isSwingWhileUsingEnabled());
                btn.method_25355(swingLabel());
            }
        ).method_46434(cx - btnW / 2, row0 + gap, btnW, btnH).method_46431());

        this.method_37063(class_4185.method_46430(
            class_2561.method_43470("Back"),
            btn -> this.field_22787.method_1507(this.parent)
        ).method_46434(cx - 50, row0 + gap * 2 + 10, 100, btnH).method_46431());
    }

    private class_2561 blockingLabel() {
        return class_2561.method_43470(OldPvpData.isBlockingEnabled()
            ? "Sword Blocking: Enabled" : "Sword Blocking: Disabled");
    }

    private class_2561 swingLabel() {
        return class_2561.method_43470(OldPvpData.isSwingWhileUsingEnabled()
            ? "Swing While Using: Enabled" : "Swing While Using: Disabled");
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        this.method_25420(graphics, mouseX, mouseY, delta);
        int cx = this.field_22789 / 2;
        int cy = this.field_22790 / 2;
        graphics.method_27534(this.field_22793, this.field_22785, cx, cy - 66, 0xFFFFFF);
        graphics.method_27534(this.field_22793,
            class_2561.method_43470("Classic 1.7 sword blocking & swing animations"),
            cx, cy - 52, 0xAAAAAA);
        super.method_25394(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
