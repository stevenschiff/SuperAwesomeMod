/*
 * Satin
 * Copyright (C) 2019-2024 Ladysnake
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; If not, see <https://www.gnu.org/licenses>.
 */
package org.ladysnake.satin.mixin.client.render;

import org.jetbrains.annotations.Nullable;
import org.ladysnake.satin.impl.RenderLayerDuplicator;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import class_4688;
import java.util.function.Consumer;
import net.minecraft.class_293;
import net.minecraft.client.renderer.rendertype.RenderType;

@Mixin(RenderType.class_4687.class)
public abstract class RenderLayerMultiPhaseMixin extends RenderType implements RenderLayerDuplicator.SatinRenderLayer {
    @Shadow
    @Final
    private class_4688 phases;

    public RenderLayerMultiPhaseMixin(String name, class_293 vertexFormat, class_293.class_5596 drawMode, int expectedBufferSize, boolean hasCrumbling, boolean translucent, Runnable startAction, Runnable endAction) {
        super(name, vertexFormat, drawMode, expectedBufferSize, hasCrumbling, translucent, startAction, endAction);
    }

    @Override
    public RenderType satin$copy(String newName, @Nullable class_293 vertexFormat, Consumer<class_4688.class_4689> op) {
        return RenderLayerAccessor.satin$of(
                newName,
                vertexFormat == null ? this.format() : vertexFormat,
                this.mode(),
                this.bufferSize(),
                this.affectsCrumbling(),
                ((RenderLayerAccessor) this).isTranslucent(),
                this.satin$copyPhaseParameters(op)
        );
    }

    @Override
    public class_4688 satin$copyPhaseParameters(Consumer<class_4688.class_4689> op) {
        // Yes we can cast to accessor
        @SuppressWarnings("ConstantConditions") RenderLayerMixin.MultiPhaseParametersAccessor access = ((RenderLayerMixin.MultiPhaseParametersAccessor) (Object) this.phases);
        class_4688.class_4689 builder = class_4688.method_23598()
                .method_34577(access.getTexture())
                .method_34578(access.getProgram())
                .method_23615(access.getTransparency())
                .method_23604(access.getDepthTest())
                .method_23603(access.getCull())
                .method_23608(access.getLightmap())
                .method_23611(access.getOverlay())
                .method_23607(access.getLayering())
                .method_23610(access.getTarget())
                .method_23614(access.getTexturing())
                .method_23616(access.getWriteMaskState())
                .method_23609(access.getLineWidth());
        op.accept(builder);
        return builder.method_24297(access.getOutlineMode());
    }
}
