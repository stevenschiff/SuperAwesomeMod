package com.steveplays.superawesomemod;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class KeystrokesScreen extends Screen {

    private final Screen parent;

    public KeystrokesScreen(Screen parent) {
        super(Component.literal("Keystrokes"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int cx   = this.width / 2;
        int cy   = this.height / 2;
        int btnW = 200;
        int btnH = 20;
        int gap  = 26;

        int topY = cy - 50;

        // Toggle
        this.addRenderableWidget(Button.builder(
            toggleLabel(),
            btn -> {
                KeystrokesData.setEnabled(!KeystrokesData.isEnabled());
                btn.setMessage(toggleLabel());
            }
        ).bounds(cx - btnW / 2, topY, btnW, btnH).build());

        // Size slider (1-10)
        this.addRenderableWidget(new ScaleSlider(
            cx - btnW / 2, topY + gap, btnW, btnH,
            KeystrokesData.getScale()
        ));

        // Corner cycle button
        this.addRenderableWidget(Button.builder(
            cornerLabel(),
            btn -> {
                KeystrokesData.setCorner((KeystrokesData.getCorner() + 1) % 4);
                btn.setMessage(cornerLabel());
            }
        ).bounds(cx - btnW / 2, topY + gap * 2, btnW, btnH).build());

        // Back
        this.addRenderableWidget(Button.builder(
            Component.literal("Back"),
            btn -> this.minecraft.setScreen(this.parent)
        ).bounds(cx - 50, topY + gap * 3, 100, btnH).build());
    }

    private Component toggleLabel() {
        return Component.literal(KeystrokesData.isEnabled()
            ? "Keystrokes: Enabled" : "Keystrokes: Disabled");
    }

    private Component cornerLabel() {
        return Component.literal("Corner: " + KeystrokesData.getCornerName());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        int cx = this.width / 2;
        int cy = this.height / 2;
        graphics.drawCenteredString(this.font, this.title, cx, cy - 76, 0xFFFFFF);
        graphics.drawCenteredString(this.font,
            Component.literal("Shows WASD + Space key presses on screen"),
            cx, cy - 64, 0xAAAAAA);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static final class ScaleSlider extends AbstractSliderButton {
        ScaleSlider(int x, int y, int w, int h, int initialScale) {
            super(x, y, w, h, Component.empty(), normalize(initialScale));
            this.updateMessage();
        }

        private static double normalize(int scale) {
            return (double) (scale - 1) / 9.0;
        }

        @Override
        protected void updateMessage() {
            int s = (int) Math.round(this.value * 9.0 + 1.0);
            this.setMessage(Component.literal("Size: " + s));
        }

        @Override
        protected void applyValue() {
            int s = (int) Math.round(this.value * 9.0 + 1.0);
            KeystrokesData.setScale(s);
        }
    }
}
