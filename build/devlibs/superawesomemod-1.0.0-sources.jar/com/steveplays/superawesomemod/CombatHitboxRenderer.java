package com.steveplays.superawesomemod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

public final class CombatHitboxRenderer {

    private CombatHitboxRenderer() {}

    public static void register() {
        WorldRenderEvents.AFTER_ENTITIES.register(CombatHitboxRenderer::onAfterEntities);
    }

    private static void onAfterEntities(WorldRenderContext ctx) {
        if (!CombatHitboxData.isEnabled()) return;

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer self = mc.player;
        ClientLevel level = mc.level;
        if (self == null || level == null) return;

        MultiBufferSource consumers = ctx.consumers();
        if (consumers == null) return;

        Camera camera = ctx.gameRenderer().getMainCamera();
        Vec3 camPos = camera.position();
        Vec3 eye = self.getEyePosition();
        double reach = getAttackReach(self);
        double reachSqr = reach * reach;
        float partialTick = mc.getDeltaTracker().getGameTimeDeltaPartialTick(true);

        PoseStack.Pose pose = ctx.matrices().last();
        Matrix4f matrix = pose.pose();


        // One pass only, depth-tested. The through-wall pass is gone: outlines now
        // obey line of sight, so an entity behind a wall is hidden exactly as it is
        // without the mod, and invisible entities stay invisible.
        drawPass(consumers.getBuffer(RenderTypes.lines()), level, self, eye, reachSqr,
                 matrix, pose, camPos, partialTick);
    }

    private static void drawPass(VertexConsumer buffer, ClientLevel level, LocalPlayer self,
                                 Vec3 eye, double reachSqr, Matrix4f matrix, PoseStack.Pose pose,
                                 Vec3 camPos, float partialTick) {
        boolean playersOnly = CombatHitboxData.isPlayersOnly();
        for (Entity entity : level.entitiesForRendering()) {
            if (entity == self) continue;
            if (!entity.isAttackable()) continue;
            // Invisible means invisible — outlining these would be the giveaway the
            // see-through option used to be.
            if (entity.isInvisible()) continue;
            if (playersOnly && !(entity instanceof Player)) continue;

            double dx = Mth.lerp(partialTick, entity.xo, entity.getX()) - entity.getX();
            double dy = Mth.lerp(partialTick, entity.yo, entity.getY()) - entity.getY();
            double dz = Mth.lerp(partialTick, entity.zo, entity.getZ()) - entity.getZ();
            AABB box = entity.getBoundingBox().move(dx, dy, dz);
            boolean inReach = nearestPointDistanceSqr(eye, box) <= reachSqr;

            float[] color = inReach ? CombatHitboxData.getInRangeRGB() : CombatHitboxData.getOutOfRangeRGB();

            renderBoxLines(buffer, matrix, pose, box, camPos, color[0], color[1], color[2], 1.0f);
        }
    }

    private static double getAttackReach(Player player) {
        AttributeInstance attr = player.getAttribute(Attributes.ENTITY_INTERACTION_RANGE);
        if (attr != null) return attr.getValue();
        return Player.DEFAULT_ENTITY_INTERACTION_RANGE;
    }

    private static double nearestPointDistanceSqr(Vec3 point, AABB box) {
        double dx = Math.max(0.0, Math.max(box.minX - point.x, point.x - box.maxX));
        double dy = Math.max(0.0, Math.max(box.minY - point.y, point.y - box.maxY));
        double dz = Math.max(0.0, Math.max(box.minZ - point.z, point.z - box.maxZ));
        return dx * dx + dy * dy + dz * dz;
    }

    private static void renderBoxLines(VertexConsumer buf, Matrix4f mat, PoseStack.Pose pose,
                                       AABB box, Vec3 cam,
                                       float r, float g, float b, float a) {
        float x0 = (float) (box.minX - cam.x);
        float y0 = (float) (box.minY - cam.y);
        float z0 = (float) (box.minZ - cam.z);
        float x1 = (float) (box.maxX - cam.x);
        float y1 = (float) (box.maxY - cam.y);
        float z1 = (float) (box.maxZ - cam.z);

        // Bottom rectangle
        edge(buf, mat, pose, x0, y0, z0, x1, y0, z0, r, g, b, a, 1, 0, 0);
        edge(buf, mat, pose, x1, y0, z0, x1, y0, z1, r, g, b, a, 0, 0, 1);
        edge(buf, mat, pose, x1, y0, z1, x0, y0, z1, r, g, b, a, -1, 0, 0);
        edge(buf, mat, pose, x0, y0, z1, x0, y0, z0, r, g, b, a, 0, 0, -1);
        // Top rectangle
        edge(buf, mat, pose, x0, y1, z0, x1, y1, z0, r, g, b, a, 1, 0, 0);
        edge(buf, mat, pose, x1, y1, z0, x1, y1, z1, r, g, b, a, 0, 0, 1);
        edge(buf, mat, pose, x1, y1, z1, x0, y1, z1, r, g, b, a, -1, 0, 0);
        edge(buf, mat, pose, x0, y1, z1, x0, y1, z0, r, g, b, a, 0, 0, -1);
        // Vertical edges
        edge(buf, mat, pose, x0, y0, z0, x0, y1, z0, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x1, y0, z0, x1, y1, z0, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x1, y0, z1, x1, y1, z1, r, g, b, a, 0, 1, 0);
        edge(buf, mat, pose, x0, y0, z1, x0, y1, z1, r, g, b, a, 0, 1, 0);
    }

    private static void edge(VertexConsumer buf, Matrix4f mat, PoseStack.Pose pose,
                             float x1, float y1, float z1,
                             float x2, float y2, float z2,
                             float r, float g, float b, float a,
                             float nx, float ny, float nz) {
        buf.addVertex(mat, x1, y1, z1).setColor(r, g, b, a).setNormal(pose, nx, ny, nz).setLineWidth(2.0f);
        buf.addVertex(mat, x2, y2, z2).setColor(r, g, b, a).setNormal(pose, nx, ny, nz).setLineWidth(2.0f);
    }
}
